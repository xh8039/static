<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-21 16:42:35
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址引导系统
 * @Description   : 一款极其优雅的易航网址引导系统
 * @Read me       : 感谢您使用易航网址引导系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 use system\library\Json; goto ev3bz; aHK1R: if (is_string($egObu)) { goto nveef; } goto Taw_r; Taw_r: Json::echo($egObu); goto Y2YRs; oFf_K: system\admin\Api::init(); goto Xrh1l; RJTyB: nveef: goto NHcdo; NHcdo: echo $egObu; goto iI0bT; Y2YRs: goto QL_Z5; goto RJTyB; xppQj: $XNhdG = isset($_GET["\x61\143\x74\151\157\156"]) ? $_GET["\141\x63\x74\151\x6f\156"] : "\151\156\144\145\x78"; goto oFf_K; ev3bz: require_once $_SERVER["\104\117\x43\125\115\x45\116\x54\137\x52\x4f\117\x54"] . "\x2f\160\x75\x62\x6c\151\x63\x2f\x63\157\x6d\x6d\157\x6e\x2e\160\150\x70"; goto xppQj; Xrh1l: $egObu = system\admin\Api::$XNhdG(); goto aHK1R; iI0bT: QL_Z5:
