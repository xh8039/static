<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-21 16:42:35
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址引导系统
 * @Description   : 一款极其优雅的易航网址引导系统
 * @Read me       : 感谢您使用易航网址引导系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 $OxUWT = isset($_GET["\155\x6f\x64"]) ? $_GET["\x6d\x6f\144"] : "\151\x6e\x64\145\x78"; require "\167\x69\x64\147\x65\x74\163\57\x70\154\x75\147\151\156\163\x2f" . $OxUWT . "\56\160\x68\x70";
