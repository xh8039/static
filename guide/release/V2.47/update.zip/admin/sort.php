<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-21 16:42:35
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址引导系统
 * @Description   : 一款极其优雅的易航网址引导系统
 * @Read me       : 感谢您使用易航网址引导系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 $OxUWT = isset($_GET["\155\157\x64"]) ? $_GET["\155\x6f\x64"] : "\x69\156\144\145\x78"; require "\x77\x69\x64\147\x65\164\x73\57\x73\157\x72\x74\57" . $OxUWT . "\x2e\160\x68\x70";
