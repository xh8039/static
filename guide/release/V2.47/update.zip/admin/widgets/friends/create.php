<?php

use system\admin\Form;

$title = '新增友情链接';
include 'modules/iframe.php';
$form = [
	Form::text('站点标题', 'title', null, null, ['required' => true]),
	Form::input('站点链接', 'url', null, 'url', null, ['required' => true]),
	Form::textarea('站点简介', 'description'),
	Form::input('站点关键词', 'keywords'),
	Form::input('站点Favicon', 'favicon', null, 'url', '站点Favicon图标链接'),
	Form::input('rel属性', 'rel', 'friend', 'text', '例如：nofollow（注释：不传递搜索引擎权重）'),
	Form::hidden('status', 1)
];
$form = implode(PHP_EOL, $form);
echo Form::form('insertTable', ['table' => 'friends'], $form, '新增友链');
include 'modules/footer.php';
