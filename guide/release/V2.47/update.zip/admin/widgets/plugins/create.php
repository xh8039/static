<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-21 16:42:35
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址引导系统
 * @Description   : 一款极其优雅的易航网址引导系统
 * @Read me       : 感谢您使用易航网址引导系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 use system\admin\View; goto vpw6N; N2zEB: echo View::card($title, "\xe5\217\252\xe8\x83\xbd\xe6\211\213\345\212\250\346\xb7\xbb\xe5\212\240\xe6\x8f\x92\344\xbb\266\345\223\246"); goto No35L; hXxuL: include "\155\157\144\x75\154\145\163\x2f\x68\x65\x61\x64\145\162\56\x70\150\160"; goto N2zEB; vpw6N: $title = "\346\226\xb0\345\xa2\236\346\217\x92\xe4\273\266"; goto hXxuL; No35L: include "\x6d\x6f\144\x75\x6c\x65\163\x2f\146\x6f\157\x74\x65\162\56\x70\150\160";
