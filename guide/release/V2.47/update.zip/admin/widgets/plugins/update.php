<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-21 16:42:35
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址引导系统
 * @Description   : 一款极其优雅的易航网址引导系统
 * @Read me       : 感谢您使用易航网址引导系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 use system\admin\Form; use system\plugin\Manager; goto bF72f; P_zSj: $vScIY = Manager::getInfo($_GET["\156\x61\155\x65"], true); goto HJCIC; Sck_o: include_once ROOT . "\163\171\x73\x74\x65\155\57\x70\x6c\x75\147\x69\156\57\x46\x72\157\x6d\x2e\160\150\160"; goto AP05u; t7mrY: echo "\346\217\222\344\273\xb6\x20" . $vScIY["\164\x69\164\x6c\x65"] . "\x20\xe6\x9a\x82\346\227\240\350\x87\xaa\345\xae\232\xe4\xb9\211\350\xae\xbe\347\xbd\xae"; goto Vv0C8; bF72f: $title = "\xe6\x8f\222\344\273\xb6\350\xae\xbe\347\275\256"; goto GwMur; Vv0C8: GrD_0: goto u1fA6; AP05u: $JmZme = "\x70\154\x75\147\x69\156\123\145\x74"; goto P_zSj; spzI_: goto GrD_0; goto PgvPn; trSxN: $srWmU = implode(PHP_EOL, $srWmU); goto sJ8IP; U_z3q: $title = $vScIY["\164\151\164\154\x65"] . $title; goto YtD9m; YtD9m: if (empty($srWmU)) { goto Lhv1j; } goto trSxN; sJ8IP: echo Form::form("\160\x6c\x75\147\151\156\123\x65\x74", ["\160\154\165\x67\151\x6e" => $_GET["\x6e\141\x6d\145"]], $srWmU); goto spzI_; GwMur: include "\x6d\x6f\144\165\x6c\x65\x73\57\151\x66\x72\141\155\x65\56\x70\x68\x70"; goto Sck_o; HJCIC: $srWmU = (function () use($vScIY) { goto HlkPz; SXNtZ: if (!is_file($Kn33c)) { goto gB5KV; } goto ZOgIk; MujJA: $Kn33c = PLUGINS_ROOT . $vScIY["\156\141\155\x65"] . DIR_SEP . "\x50\154\165\x67\151\156\56\160\150\160"; goto SXNtZ; LYxwO: $srWmU = $vScIY["\143\x6c\x61\163\x73"]::config(new system\plugin\Form($vScIY["\x6e\x61\155\x65"])); goto Jp5Oc; cnFwX: meCfS: goto miXiK; miXiK: gB5KV: goto uxwAb; Jp5Oc: $srWmU = empty($srWmU->html) ? [] : $srWmU->html; goto cnFwX; ZOgIk: include_once $Kn33c; goto kj3W1; uxwAb: return $srWmU; goto bn6zT; HlkPz: $srWmU = []; goto MujJA; kj3W1: if (!method_exists($vScIY["\x63\154\x61\163\163"], "\x63\157\x6e\x66\x69\147")) { goto meCfS; } goto LYxwO; bn6zT: })(); goto U_z3q; PgvPn: Lhv1j: goto t7mrY; u1fA6: include "\155\x6f\x64\x75\x6c\x65\x73\57\146\157\157\x74\x65\162\56\160\x68\x70";
