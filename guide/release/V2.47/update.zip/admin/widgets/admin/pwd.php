<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-21 16:42:35
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址引导系统
 * @Description   : 一款极其优雅的易航网址引导系统
 * @Read me       : 感谢您使用易航网址引导系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 use system\admin\Form; use system\admin\View; goto pw4bY; pMAdX: include "\155\x6f\x64\165\x6c\x65\163\x2f\150\145\x61\x64\145\162\x2e\160\x68\x70"; goto E21IC; XbdVX: View::form($title, "\145\x64\151\164\x50\x57\x44", null, $srWmU); goto JylfK; E21IC: $srWmU = [Form::input("\346\x97\247\345\xaf\206\347\240\x81", "\x6f\154\x64\160\167\144", null, "\x70\141\163\x73\x77\157\x72\144", null, ["\x72\x65\161\165\x69\162\x65\x64" => true, "\x63\154\x61\x73\x73" => "\x66\157\162\155\x2d\143\x6f\x6e\x74\162\157\x6c"]), Form::input("\346\226\260\345\xaf\x86\xe7\xa0\201", "\156\x65\x77\x70\x77\x64", null, "\160\141\x73\163\x77\157\x72\144", null, ["\162\145\161\165\x69\x72\x65\144" => true, "\143\154\141\163\x73" => "\x66\x6f\162\x6d\55\x63\x6f\156\x74\x72\x6f\x6c"]), Form::input("\347\241\xae\xe8\xae\xa4\346\226\xb0\xe5\257\206\347\xa0\x81", "\x63\x6f\156\x66\151\x72\x6d\x70\167\x64", null, "\x70\x61\163\163\x77\x6f\x72\144", null, ["\162\145\161\x75\x69\162\x65\144" => true, "\143\x6c\141\163\163" => "\x66\x6f\162\155\55\x63\157\156\164\162\157\154"])]; goto XbdVX; pw4bY: $title = "\xe4\xbf\256\xe6\x94\271\345\xaf\x86\347\xa0\201"; goto pMAdX; JylfK: include "\155\x6f\144\165\x6c\145\163\57\146\157\x6f\164\145\x72\56\160\x68\x70";
