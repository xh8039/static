<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-21 16:42:35
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址引导系统
 * @Description   : 一款极其优雅的易航网址引导系统
 * @Read me       : 感谢您使用易航网址引导系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 use system\admin\Form; use system\admin\View; goto e51FJ; HH5ys: include "\155\x6f\144\x75\154\145\x73\57\150\145\141\144\145\162\x2e\x70\150\x70"; goto tIBof; n80gq: View::form($title, "\x75\160\144\x61\x74\x65\124\141\142\154\x65", ["\164\141\142\154\145" => $JmZme], $srWmU); goto eTitE; zRJHi: $srWmU = [Form::hidden("\x69\x64", $S31Wt["\x69\144"]), Form::input("\xe7\224\xa8\xe6\210\xb7\xe5\220\215", "\165\163\x65\x72", $S31Wt["\x75\163\145\162"], "\x74\145\170\164", null, ["\162\x65\161\165\x69\x72\145\x64" => true]), Form::input("\xe6\x98\xb5\xe7\247\xb0", "\x6e\141\x6d\x65", $S31Wt["\x6e\141\x6d\145"]), Form::input("\xe9\x82\xae\347\xae\261", "\x65\x6d\141\151\154", $S31Wt["\145\155\x61\151\154"]), Form::input("\x51\x51\345\217\267", "\x71\x71", $S31Wt["\x71\161"])]; goto n80gq; e51FJ: $title = "\346\233\xb4\xe6\226\xb0\350\xb4\246\345\217\267\344\xbf\241\xe6\x81\xaf"; goto HH5ys; BYn_d: $S31Wt = \system\admin\Admin::info(); goto zRJHi; tIBof: $JmZme = "\141\144\x6d\x69\x6e"; goto BYn_d; eTitE: include "\155\157\144\x75\154\x65\x73\x2f\146\x6f\157\164\145\x72\x2e\x70\150\x70";
