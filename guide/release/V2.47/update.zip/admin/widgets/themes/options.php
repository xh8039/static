<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-21 16:42:35
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址引导系统
 * @Description   : 一款极其优雅的易航网址引导系统
 * @Read me       : 感谢您使用易航网址引导系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 use system\admin\View; use system\theme\Manager; goto HtVDL; HtVDL: $title = "\344\xb8\273\351\xa2\x98\xe8\256\xbe\xe7\275\xae"; goto IvdDK; IvdDK: include "\x6d\x6f\144\x75\154\x65\163\x2f\x68\145\x61\144\145\x72\x2e\160\150\x70"; goto aV_Bq; J1xvX: include "\155\157\144\165\x6c\x65\163\57\146\157\x6f\x74\145\x72\56\160\x68\160"; goto oFVd5; qRdir: View::card($dWYJI["\x74\151\164\x6c\x65"] . $title, function () { goto kJ7vU; o6dRi: themeConfig(new \system\theme\Form()); goto iLp5y; TvUqy: vAP3O: goto yCuiE; dOTcb: H3IO3: goto dT1D1; WIu51: echo "\346\x9c\254\344\xb8\273\xe9\242\230\xe6\232\x82\346\227\xa0\xe8\x87\xaa\345\xae\x9a\xe4\271\211\xe8\256\xbe\xe7\xbd\256"; goto o9k02; dT1D1: define("\124\110\x45\115\x45\137\x53\105\124", true); goto B3bsY; B3bsY: echo "\x9\11\x3c\146\157\162\155\x20\141\x63\164\x69\x6f\156\75\x22\141\x70\x69\x2e\160\x68\x70\77\141\x63\164\151\157\x6e\75\164\x68\145\155\x65\x53\x65\164\42\40\155\145\x74\x68\x6f\144\75\42\x70\x6f\x73\x74\42\x20\143\154\x61\163\x73\x3d\x22\164\x68\145\155\x65\x53\145\164\x22\76\xd\xa\11\x9\11"; goto o6dRi; iLp5y: echo "\x9\x9\11\74\x64\151\166\x20\143\x6c\x61\x73\x73\x3d\x22\x64\55\x67\x72\151\144\x22\x3e\xd\xa\11\11\11\11\x3c\142\165\164\164\x6f\x6e\40\164\171\160\x65\x3d\x22\x73\x75\x62\x6d\x69\x74\x22\x20\x63\x6c\x61\163\163\x3d\42\142\164\156\40\142\x74\x6e\55\x70\162\151\x6d\x61\162\x79\x22\76\xe4\xbf\235\345\255\230\xe4\270\273\xe9\242\230\xe8\xae\276\xe7\xbd\xae\x3c\x2f\x62\x75\164\x74\157\156\x3e\15\12\11\x9\x9\74\x2f\x64\151\x76\x3e\15\xa\x9\11\x3c\57\x66\x6f\x72\x6d\x3e\xd\12"; goto TvUqy; kJ7vU: if (Manager::needFile("\x74\x68\x65\155\145\x2f\146\165\x6e\143\164\151\157\156\163") && function_exists("\x74\150\x65\x6d\x65\103\x6f\156\146\151\x67")) { goto H3IO3; } goto WIu51; o9k02: goto vAP3O; goto dOTcb; yCuiE: }); goto J1xvX; aV_Bq: $dWYJI = Manager::getInfo(); goto qRdir; oFVd5: echo system\admin\Form::script("\164\150\x65\x6d\145\x53\145\164", "\344\277\x9d\345\xad\230\xe4\270\273\xe9\242\x98\350\xae\276\347\275\xae");
