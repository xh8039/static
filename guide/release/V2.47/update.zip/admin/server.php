<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-21 16:42:35
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址引导系统
 * @Description   : 一款极其优雅的易航网址引导系统
 * @Read me       : 感谢您使用易航网址引导系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 use system\library\Json; goto y_6AI; FmDop: $XNhdG = trim($_GET["\141\x63\164\151\157\x6e"] ?? "\151\156\144\145\x78"); goto mhmCt; P4Qur: if (!(is_array($egObu) || is_object($egObu))) { goto s8WQW; } goto j53vJ; Ko5Qs: VntUu: goto mNwlL; XnCz2: http_response_code(404); goto el_bQ; j53vJ: $egObu = Json::encode($egObu); goto c1eXe; mhmCt: $egObu = system\admin\Server::$XNhdG(); goto P4Qur; U_UVP: if (!empty($egObu)) { goto VntUu; } goto XnCz2; c1eXe: s8WQW: goto U_UVP; mNwlL: echo $egObu; goto k0Pr3; el_bQ: goto PPnhz; goto Ko5Qs; y_6AI: require $_SERVER["\x44\x4f\103\x55\115\x45\116\x54\137\122\117\117\x54"] . "\57\x70\x75\142\154\151\x63\57\143\x6f\x6d\155\157\x6e\x2e\160\x68\x70"; goto FmDop; k0Pr3: PPnhz:
