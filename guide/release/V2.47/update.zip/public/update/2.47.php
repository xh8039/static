<?php

// 删除旧背景壁纸
$background = CONTENT_ROOT . 'static' . DIR_SEP . 'images' . DIR_SEP . 'background' . DIR_SEP;
unlink($background . 'pc' . DIR_SEP . '05.jpg');
unlink($background . 'pc' . DIR_SEP . '06.jpg');
unlink($background . 'mobile' . DIR_SEP . '08.jpg');

// 删除旧JsonDb出厂数据存放路径
delete_directory(ROOT . 'admin' . DIR_SEP . 'widgets' . DIR_SEP . 'set' . DIR_SEP . 'JsonDb');

// 删除雪花背景飘落特效插件
delete_directory(PLUGINS_ROOT . 'FloatSnow');

// 更新2024年的灯笼开始时间
\system\plugin\Manager::saveSet('NewYearLantern', [
    'start' => '01-26',
    'end' => '02-01'
]);
