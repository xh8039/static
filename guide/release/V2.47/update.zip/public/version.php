<?php
define('VERSION', 2.47);