<?php
if (!defined('ROOT')) exit;

function themeConfig(\system\theme\Form $form)
{
	$CustomBackground = $form->switch('自定义背景壁纸', 'CustomBackground', 0, '默认使用主题自带壁纸，开启后则调用系统壁纸接口');
	$form->create($CustomBackground);
}