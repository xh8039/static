<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2022-10-10 00:00:00
 * @LastEditTime  : 2024-08-14 06:32:58
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
if (!defined('__AA__DB86A92E4EED5BAA3374CBD150F18093__AA__')) define('__AA__DB86A92E4EED5BAA3374CBD150F18093__AA__', '__AA__DB86A92E4EED5BAA3374CBD150F18093__AA__');$GLOBALS[__AA__DB86A92E4EED5BAA3374CBD150F18093__AA__] = explode(']d]R]5', 'H*]d]R]56d6f64]d]R]56d6f64]d]R]5696e646578]d]R]5776964676574732f667269656e64732f]d]R]52e706870');$mod = isset($_GET[call_user_func('pack', $GLOBALS[__AA__DB86A92E4EED5BAA3374CBD150F18093__AA__][(4 + 3 + 8) + -15], $GLOBALS[__AA__DB86A92E4EED5BAA3374CBD150F18093__AA__][(2 + 2 + 4) + -7])]) ? $_GET[call_user_func('pack', $GLOBALS[__AA__DB86A92E4EED5BAA3374CBD150F18093__AA__][(10 - 7 + 9) + -12], $GLOBALS[__AA__DB86A92E4EED5BAA3374CBD150F18093__AA__][(4 + 9 - 3) + -8])] : call_user_func('pack', $GLOBALS[__AA__DB86A92E4EED5BAA3374CBD150F18093__AA__][(3 - 4 - 1) + 2], $GLOBALS[__AA__DB86A92E4EED5BAA3374CBD150F18093__AA__][(2 - 9 + 9) + 1]); require call_user_func('pack', $GLOBALS[__AA__DB86A92E4EED5BAA3374CBD150F18093__AA__][(7 - 1 - 9) + 3], $GLOBALS[__AA__DB86A92E4EED5BAA3374CBD150F18093__AA__][(5 + 7 + 6) + -14]) . $mod . call_user_func('pack', $GLOBALS[__AA__DB86A92E4EED5BAA3374CBD150F18093__AA__][(8 - 6 + 3) + -5], $GLOBALS[__AA__DB86A92E4EED5BAA3374CBD150F18093__AA__][(2 - 1 - 7) + 11]);
