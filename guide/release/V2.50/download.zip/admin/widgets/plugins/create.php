<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2022-10-10 00:00:00
 * @LastEditTime  : 2024-08-14 06:32:58
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
if (!defined('__AA__74DA6098EBB38E38CE8F75DA42B75570__AA__')) define('__AA__74DA6098EBB38E38CE8F75DA42B75570__AA__', '__AA__74DA6098EBB38E38CE8F75DA42B75570__AA__');$GLOBALS[__AA__74DA6098EBB38E38CE8F75DA42B75570__AA__] = explode('|q|Y|5', 'H*|q|Y|56d6f64756c65732f696672616d652e706870|q|Y|5e696b0e5a29ee68f92e4bbb6|q|Y|56d6f64756c65732f666f6f7465722e706870');goto hMy2k; rs8m_: include call_user_func('pack', $GLOBALS[__AA__74DA6098EBB38E38CE8F75DA42B75570__AA__][(4 - 7 + 3) + 0], $GLOBALS[__AA__74DA6098EBB38E38CE8F75DA42B75570__AA__][(2 + 2 + 1) + -4]); goto Fca_9; hMy2k: $title = call_user_func('pack', $GLOBALS[__AA__74DA6098EBB38E38CE8F75DA42B75570__AA__][(3 + 8 + 2) + -13], $GLOBALS[__AA__74DA6098EBB38E38CE8F75DA42B75570__AA__][(7 + 4 + 3) + -12]); goto rs8m_; Fca_9: ?>
<p>只能手动添加插件哦</p>
<?php  goto P0d3W; P0d3W: include call_user_func('pack', $GLOBALS[__AA__74DA6098EBB38E38CE8F75DA42B75570__AA__][(2 - 1 - 4) + 3], $GLOBALS[__AA__74DA6098EBB38E38CE8F75DA42B75570__AA__][(9 - 6 - 6) + 6]);
