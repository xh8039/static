<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2022-10-10 00:00:00
 * @LastEditTime  : 2024-08-14 06:32:58
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
if (!defined('__AA__D219E2ADAFD6191AE7600405038B7376__AA__')) define('__AA__D219E2ADAFD6191AE7600405038B7376__AA__', '__AA__D219E2ADAFD6191AE7600405038B7376__AA__');$GLOBALS[__AA__D219E2ADAFD6191AE7600405038B7376__AA__] = explode(';i;T;2', 'H*;i;T;26d6f64756c65732f6865616465722e706870;i;T;2e58f8be993bee7aea1e79086');goto NjCvf; ayHP8: system\admin\View::table(); goto P_XSm; zi1iU: include call_user_func('pack', $GLOBALS[__AA__D219E2ADAFD6191AE7600405038B7376__AA__][(7 + 8 + 1) + -16], $GLOBALS[__AA__D219E2ADAFD6191AE7600405038B7376__AA__][(6 + 3 - 3) + -5]); goto ayHP8; NjCvf: $title = call_user_func('pack', $GLOBALS[__AA__D219E2ADAFD6191AE7600405038B7376__AA__][(8 - 3 + 4) + -9], $GLOBALS[__AA__D219E2ADAFD6191AE7600405038B7376__AA__][(6 + 10 - 3) + -11]); goto zi1iU; P_XSm: ?>
<script>
	BootstrapTable.options.table = 'friends';
	BootstrapTable.table_options.sortName = 'create_time';
	BootstrapTable.table_options.sortOrder = 'desc';
	BootstrapTable.columns = [{
			field: 'title',
			align: 'center',
			title: '站点标题',
			sortable: true
		},
		{
			field: 'description',
			align: 'center',
			title: '站点简介',
			visible: false,
			width: '5',
			widthUnit: 'rem',
		},
		{
			field: 'keywords',
			align: 'center',
			title: '站点关键词',
			sortable: true,
			visible: false
		},
		{
			field: 'url',
			align: 'center',
			title: '链接',
			sortable: true,
			formatter: function(value) {
				return `<a href="${value}" target="_blank">${value}</a>`;
			}
		},
		{
			field: 'create_time',
			align: 'center',
			title: '创建时间',
			sortable: true
		}
	]
	BootstrapTable.init();
</script>
