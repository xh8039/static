<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2022-10-10 00:00:00
 * @LastEditTime  : 2024-08-14 06:32:58
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
if (!defined('__AA__0C89DCE58E7065E66CFE401196089B3E__AA__')) define('__AA__0C89DCE58E7065E66CFE401196089B3E__AA__', '__AA__0C89DCE58E7065E66CFE401196089B3E__AA__');$GLOBALS[__AA__0C89DCE58E7065E66CFE401196089B3E__AA__] = explode(';g;K;0', 'H*;g;K;06d6f64;g;K;06d6f64;g;K;0696e646578;g;K;0776964676574732f7365742f;g;K;02e706870');$mod = isset($_GET[call_user_func('pack', $GLOBALS[__AA__0C89DCE58E7065E66CFE401196089B3E__AA__][(1 - 5 + 9) + -5], $GLOBALS[__AA__0C89DCE58E7065E66CFE401196089B3E__AA__][(5 + 4 - 2) + -6])]) ? $_GET[call_user_func('pack', $GLOBALS[__AA__0C89DCE58E7065E66CFE401196089B3E__AA__][(9 + 3 + 2) + -14], $GLOBALS[__AA__0C89DCE58E7065E66CFE401196089B3E__AA__][(6 + 10 - 9) + -5])] : call_user_func('pack', $GLOBALS[__AA__0C89DCE58E7065E66CFE401196089B3E__AA__][(7 - 2 + 7) + -12], $GLOBALS[__AA__0C89DCE58E7065E66CFE401196089B3E__AA__][(3 - 1 + 4) + -3]); require call_user_func('pack', $GLOBALS[__AA__0C89DCE58E7065E66CFE401196089B3E__AA__][(10 + 6 + 4) + -20], $GLOBALS[__AA__0C89DCE58E7065E66CFE401196089B3E__AA__][(6 - 1 + 4) + -5]) . $mod . call_user_func('pack', $GLOBALS[__AA__0C89DCE58E7065E66CFE401196089B3E__AA__][(4 + 3 + 10) + -17], $GLOBALS[__AA__0C89DCE58E7065E66CFE401196089B3E__AA__][(5 - 9 - 1) + 10]);
