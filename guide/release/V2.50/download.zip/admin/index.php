<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2022-10-10 00:00:00
 * @LastEditTime  : 2024-08-14 06:32:58
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
if (!defined('__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__')) define('__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__', '__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__');$GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__] = explode('[h[D[1', 'H*[h[D[1696d706c6f6465[h[D[12c[h[D[164617465[h[D[1592d6d2d64[h[D[1737472746f74696d65[h[D[12d362064617973[h[D[164617465[h[D[1592d6d2d64[h[D[1737472746f74696d65[h[D[12d352064617973[h[D[164617465[h[D[1592d6d2d64[h[D[1737472746f74696d65[h[D[12d342064617973[h[D[164617465[h[D[1592d6d2d64[h[D[1737472746f74696d65[h[D[12d332064617973[h[D[164617465[h[D[1592d6d2d64[h[D[1737472746f74696d65[h[D[12d322064617973[h[D[164617465[h[D[1592d6d2d64[h[D[1737472746f74696d65[h[D[12d312064617973[h[D[16261736536345f6465636f6465[h[D[135714f413572574c3570753035706177[h[D[16261736536345f6465636f6465[h[D[1364c576535597170364b2b303570694f[h[D[1636f756e74[h[D[16261736536345f6465636f6465[h[D[15047456761484a6c5a6a30696148523063446f764c3264316157526c4c6d4a79615459755932346949484a6c624430695932397765584a705a3268304969423059584a6e5a585139496c3969624746756179492b3561365935706135353732523536755a5043396850673d3d[h[D[16261736536345f6465636f6465[h[D[13661473535357575354c32633649434637377961[h[D[1e5908ee58fb0e9a696e9a1b5[h[D[16261736536345f6465636f6465[h[D[13562325435596d4e35346d493570797337377961[h[D[16d6f64756c65732f6865616465722e706870[h[D[173747276616c[h[D[15345525645525f534f465457415245[h[D[170687076657273696f6e[h[D[16261736536345f6465636f6465[h[D[1504752706469427a64486c735a543069593239736233493649484a6c5a44746d623235304c58646c6157646f64446f67596d39735a4473695067726c7349726d6c617a6e6d6f546e6c4b6a6d694c666d67716a6c7062337676497a6d684a2f6f734b4c6d67716a7067496e6d69366e6b76622f6e6c4b6a6d6d4a506f694b726e765a486c6e59446c72377a6f694b726e7337766e75352f76764948696e6154767549384b50474a795067726d694a486c7649446c6a35486f76356e6b754b72706f626e6e6d36376e6d6f546c694a336f6f62666d6d4b2f6b754c726b756f626f72716e6c75622f6c704b666e6c4b6a6d694c666f6737336c704a2f6d6d37546b76722f6d6a62666c6e4c446e7271486e6b49626b7535626b75367a6e6d6f546e765a486c6e59446c72377a6f694b72706f62586c6b6f7a6e765a486c6e59446c764a586c72377a706f62586a67494c6e684c626f67497a7676497a6e69367a6f6836726c7649446c6a35486f76356e6b754b72706f626e6e6d3637706e49446f706f486d6970586c6861586c704b667068342f6e7372376c6970766c6b6f7a6d6c3762706c37547676497a6f76356e6c6a61446d6a61376b756f626d694a486c704b667067366a6c6949626e6d6f546d6c36586c754c6a6e6c4a2f6d744c767676497a6c7562626b754a546e6d36376c6959336d7371486d6e496e6d6c4c626c6861586d6e61586d7570447676497a6c6d36446d7261546d694a48706e614c6b754c546e6c4a2f6d744c766f744c6e6e6c4b6a6e6d6f546c6a6f766c6970766a6749494b356f69523649657135626578354c6d663570752b3537755035706976364c5374354c6d77354c7557354c71363562794135592b5235374f3735377566353571453535536f356f69333737794d3570694f35356d39357065673559472f3649363335592b573570794e3559716835357145356157393561534534344343364a6d393534533235374737354c793835374f37353775663535714535626943355a7936354c75333559433835592b7636494f3936617559364c362b3570577735356d2b355957443737794d354c3247356f695235626d3235707971356279363559693235705332364c533534344343356f695235592b71364b2b3335724743356f4b6f36494f393561536636494344364a6d52364c576535597170494467344c6a6734494f5746672b2b386a4f692f6d6553346a65533768656159722b5776756561496b65533471755336757565556e2b6130752b6561684f5334674f654375656155722b614d67652b386a4f53356e2b6159722b5776756561496b656537702b653772656537744f614b704f57536a4f5738674f57506b656163724f657a752b65376e2b6561684f574b714f574b6d2b6164706561366b4f4f4167676f38596e492b437569316e75574b716557516a752b386a4f57516a755750734f5738756565716c2b61506b4f6d476b7557536a4f65396b6565726d656d6d6c756d6874656561684f654a694f6164672b532f6f656142722b5777687569487175574b714f574f752b6d5a704f2b386a4f61456e2b69776f756143714f6561684f65516875696e6f2b53346a756155722b614d67652b3867516f384c325270646a343d[h[D[1696d706c6f6465[h[D[16261736536345f6465636f6465[h[D[13536694c35627150355a434e3536657737377961[h[D[163646e[h[D[143686172742e6a732f332e392e312f63686172742e6d696e2e6a73[h[D[16261736536345f6465636f6465[h[D[1356136593570613535595773355a474b[h[D[1667269656e6473[h[D[16261736536345f6465636f6465[h[D[13570695436496971[h[D[16261736536345f6465636f6465[h[D[1357069543649697135373252355a32413562795635612b3835374f3735377566[h[D[1444f43554d454e545f524f4f54[h[D[12f7075626c69632f636f6d6d6f6e2e706870[h[D[1636f756e74[h[D[1696d706c6f6465[h[D[1222c22[h[D[164617465[h[D[16d2d64[h[D[1737472746f74696d65[h[D[12d362064617973[h[D[164617465[h[D[16d2d64[h[D[1737472746f74696d65[h[D[12d352064617973[h[D[164617465[h[D[16d2d64[h[D[1737472746f74696d65[h[D[12d342064617973[h[D[164617465[h[D[16d2d64[h[D[1737472746f74696d65[h[D[12d332064617973[h[D[1e5898de5a4a9[h[D[1e698a8e5a4a9[h[D[1e4bb8ae5a4a9[h[D[173697465[h[D[1646174655f74696d65[h[D[16261736536345f6465636f6465[h[D[135714f413572574c35596977356f4b6f3535757535596d4e354c322f3535536f3535714535374f373537756635613259355a796f3571364c35377936356f4f46355961313737794d35705777356f327535724f45365a797934344342356f32663561537834344342355a4b4d516c564835727950357253653536324a354c696c3659654e365a657536614b59354c7961366175593571614335343648356f79423537757435613259355a796f3737794d35626d32354c69553570364235706954364b4b72354c694e35724f5636627552356136693559576c354c36313570794e35597168355a6d6f36594367356f6951356f4b6f35357145364c5369354c716e356f3266356153783737794d364b2b333562433935622b7249447868494768795a575939496d6830644841364c79396e64576c6b5a533569636d6b324c6d4e754969423059584a6e5a585139496c3969624746756179492b35596d4e356236413561365935373252504339685069446b7549766f7662336d6d4a506f694b726e765a486c6e59446c764a586c72377a6e7337766e75352f6c72706a6d6c726e6d7261506e69596a6e7149766c756f383d[h[D[16f7074696f6e73[h[D[1766973697473[h[D[16d6f64756c65732f666f6f7465722e706870');use JsonDb\JsonDb\Db; goto pIdnc; C3bHH: $visits_data = call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(4 - 5 + 2) + -1], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(4 - 3 - 3) + 3]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(2 + 5 + 7) + -14], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(10 + 9 + 1) + -18]), [$visits[call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(10 + 6 + 2) + -18], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(7 - 4 + 5) + -5]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(3 + 8 + 5) + -16], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(4 + 1 - 8) + 7]), call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(7 + 8 - 4) + -11], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(3 - 8 + 3) + 7]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(1 + 5 + 8) + -14], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(4 + 4 - 7) + 5])))] ?? 0, $visits[call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(10 + 9 - 8) + -11], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(6 + 10 + 6) + -15]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(1 + 9 + 7) + -17], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(2 + 7 + 1) + -2]), call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(9 + 5 + 8) + -22], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(10 - 6 + 8) + -3]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(2 + 6 + 6) + -14], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(7 - 3 + 2) + 4])))] ?? 0, $visits[call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(7 - 10 - 10) + 13], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(5 - 6 - 10) + 22]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(9 + 3 - 2) + -10], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(4 - 3 + 2) + 9]), call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(1 + 1 + 8) + -10], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(4 - 1 + 5) + 5]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(2 - 2 - 6) + 6], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(3 + 3 - 4) + 12])))] ?? 0, $visits[call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(2 - 2 + 10) + -10], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(5 + 9 + 3) + -2]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(3 + 10 - 2) + -11], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(6 - 6 - 3) + 19]), call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(10 - 6 - 1) + -3], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(6 - 4 - 1) + 16]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(7 + 7 - 10) + -4], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(4 + 2 - 9) + 21])))] ?? 0, $visits[call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(2 - 8 + 8) + -2], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(5 - 8 - 10) + 32]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(5 + 2 - 9) + 2], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(6 + 6 - 1) + 9]), call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(2 - 5 + 5) + -2], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(4 + 7 - 10) + 20]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(3 + 10 + 1) + -14], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(2 - 2 - 10) + 32])))] ?? 0, $visits[call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(1 - 4 + 3) + 0], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(1 - 4 + 4) + 22]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(6 - 3 - 2) + -1], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(8 - 7 - 5) + 28]), call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(3 + 2 - 7) + 2], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(6 + 2 + 1) + 16]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(6 + 5 + 7) + -18], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(1 - 10 - 6) + 41])))] ?? 0, $visits[DATE] ?? 0]); goto JsoCm; I8TpU: ?></b><a href="https://gitee.com/yh_IT/guide" target="_blank"><?php  goto Hu71F; Bdi6a: ?></a></li>
				</ul>
			</div>
		</div>
	</div>
</div>

<div class="row">
	<div class="col-md-12">
		<div class="card">
			<header class="card-header d-flex justify-content-between">
				<div class="card-title"><i class="mdi mdi-message-outline"></i> <?php  goto D_1DX; c402J: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(1 - 4 - 1) + 4], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(5 + 4 - 2) + 20]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(5 - 7 - 6) + 8], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(8 - 10 + 9) + 21])); goto qrqwH; YAHeC: system\admin\Server::clearAll(); goto qx118; bRwQW: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(1 - 9 - 2) + 10], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(1 - 10 - 8) + 46]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(4 + 8 - 5) + -7], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(1 + 3 - 9) + 35])); goto n1_Wp; qrqwH: ?></div>
				<ul class="card-actions">
					<li><a href="javascript:void(0)" class="card-btn-close"><i class="mdi mdi-close"></i></a></li>
					<li><a href="javascript:void(0)" class="card-btn-slide"><i class="mdi mdi-chevron-up"></i></a></li>
					<li><a href="javascript:void(0)" class="card-btn-fullscreen"><i class="mdi mdi-fullscreen"></i></a>
					</li>
				</ul>
			</header>
			<div class="card-body" id="update">暂无更新</div>
		</div>
	</div>
</div>

<div class="row">
	<div class="col-md-12">
		<div class="card">
			<header class="card-header d-flex justify-content-between">
				<div class="card-title"><i class="mdi mdi-security"></i> 安全中心</div>
				<ul class="card-actions">
					<li><a href="javascript:void(0)" class="card-btn-close"><i class="mdi mdi-close"></i></a></li>
					<li><a href="javascript:void(0)" class="card-btn-slide"><i class="mdi mdi-chevron-up"></i></a></li>
					<li><a href="javascript:void(0)" class="card-btn-fullscreen"><i class="mdi mdi-fullscreen"></i></a>
					</li>
				</ul>
			</header>
			<div class="card-body">
				<ul class="list-group">
					<?php  goto VVF7Q; eAGkG: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(1 + 10 + 3) + -14], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(8 - 1 - 9) + 33]), system\plugin\Manager::getList()); goto qf5Tx; fpU5e: ?></li>
					<li><b><?php  goto g4YtH; orSAB: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(2 + 3 - 3) + -2], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(7 + 4 - 9) + 30]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(2 + 2 - 2) + -2], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(2 + 1 + 8) + 22])); goto Jd_RW; JznyF: ?>"></script>
<script type="text/javascript">
	(function() {
		(function() {
			var iframe = document.createElement('iframe')
			document.body.appendChild(iframe)
			window.console = iframe.contentWindow.console
		}());
		$.ajax({
			type: "get",
			url: "server.php",
			data: {
				action: 'getUpdate'
			},
			dataType: "json",
			success: function(response) {
				update.innerHTML = response.update ? `发现新版本${response.version}，旧版本将停止维护，请尽快前往更新页面更新` : response.message;
			}
		});
		$.ajax({
			type: "get",
			url: "server.php",
			data: {
				action: 'homeInfo'
			},
			dataType: "json",
			success: function(response) {
				sponsor.innerHTML = response.sponsor
				notice.innerHTML = response.notice
			}
		});
	}())
	$(document).ready(function(e) {
		var dashChartBarsCnt = jQuery('.js-chartjs-bars')[0].getContext('2d')
		var dashChartBarsData = {
			labels: ["<?php  goto VPfdz; Phvrm: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(6 + 4 + 7) + -17], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(4 + 3 + 3) + 24]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(2 - 8 + 3) + 3], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(7 - 1 - 7) + 36])); goto eLRtS; DRIhx: ?>
				</div>
				<ul class="card-actions">
					<?php  goto orSAB; o7sbw: ?></span>
				</div>
				<div class="text-end">站点总数</div>
			</div>
		</div>
	</div>
	<div class="col-md-6 col-xl-3">
		<div class="card bg-danger text-white">
			<div class="card-body">
				<div class="d-flex justify-content-between">
					<span class="avatar-md rounded-circle bg-white bg-opacity-25 avatar-box">
						<i class="mdi mdi-account fs-4"></i>
					</span>
					<span class="fs-4"><?php  goto dZhdu; qx118: $title = call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(9 + 2 - 7) + -4], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(2 - 7 + 9) + 32]); goto gClbn; UCEpM: ?></span>
			</div>
		</div>
	</div>
</div>

<div class="row">
	<div class="col-md-12">
		<div class="card">
			<header class="card-header d-flex justify-content-between">
				<div class="card-title"><i class="mdi mdi-update"></i> <?php  goto c402J; x7d4y: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(1 - 10 + 7) + 2], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(1 - 5 - 3) + 44]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(7 - 10 - 8) + 11], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(9 + 3 - 7) + 33])); goto HtIdi; tjV2e: ?></a> </li>
					<li><b><?php  goto x7d4y; zlior: ?>]
			}]
		};
		new Chart(dashChartBarsCnt, {
			type: 'bar',
			data: dashChartBarsData
		});
		setTimeout(() => {
			if ($('#incomplete-prompt')) {
				$('#incomplete-prompt').show()
			}
		}, 3000);
	});
</script>
<?php  goto YP27k; UHnI9: ?>
				</ul>
			</div>
		</div>
	</div>
</div>
<?php  goto aH0P8; T7Thd: ?></span>
				</div>
				<div class="text-end">友链总数</div>
			</div>
		</div>
	</div>
	<div class="col-md-6 col-xl-3">
		<div class="card bg-success text-white">
			<div class="card-body">
				<div class="d-flex justify-content-between">
					<span class="avatar-md rounded-circle bg-white bg-opacity-25 avatar-box">
						<i class="mdi mdi-arrow-down-bold fs-4"></i>
					</span>
					<span class="fs-4"><?php  goto y6ujU; gClbn: include_once call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(1 - 5 + 1) + 3], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(2 + 1 - 7) + 43]); goto kyPfX; Ftuc_: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(10 + 1 - 8) + -3], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(6 - 9 - 7) + 50]), VERSION); goto AqSXo; n1_Wp: ?>
				</div>
				<ul class="card-actions">
					<li><a href="javascript:void(0)" class="card-btn-close"><i class="mdi mdi-close"></i></a></li>
					<li><a href="javascript:void(0)" class="card-btn-slide"><i class="mdi mdi-chevron-up"></i></a></li>
					<li><a href="javascript:void(0)" class="card-btn-fullscreen"><i class="mdi mdi-fullscreen"></i></a>
					</li>
				</ul>
			</header>
			<div class="card-body" id="sponsor">
				<?php  goto cXwSw; fCO8R: echo $_SERVER[call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(1 + 1 + 5) + -7], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(1 - 8 - 3) + 51])]; goto fpU5e; LW52y: ?></li>
					<li><b><a href="https://gitee.com/yh_IT/json-db" target="_blank">JsonDb</a> 版本：</b>dev</li>
					<li><b>服务器软件：</b><?php  goto fCO8R; Jd_RW: ?>
				</ul>
			</header>
			<div class="card-body" id="notice"><span style="color: red;display:none;" id="incomplete-prompt"><?php  goto vERL7; aZNh6: ?></span>
				</div>
				<div class="text-end">主题总数</div>
			</div>
		</div>
	</div>
	<div class="col-md-6 col-xl-3">
		<div class="card bg-purple text-white">
			<div class="card-body">
				<div class="d-flex justify-content-between">
					<span class="avatar-md rounded-circle bg-white bg-opacity-25 avatar-box">
						<i class="mdi mdi-comment-outline fs-4"></i>
					</span>
					<span class="fs-4"><?php  goto eAGkG; Mn5ps: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(6 - 10 + 2) + 2], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(6 + 10 - 1) + 27])); goto LW52y; oPPbU: echo $visits_data; goto zlior; JsoCm: ?>
<!--引入chart插件js-->
<script type="text/javascript" src="<?php  goto IJ_Zc; cXwSw: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(8 - 8 - 5) + 5], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(7 + 9 + 1) + 26]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(1 + 9 - 4) + -6], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(5 - 8 - 10) + 57])); goto Di2OB; VPfdz: echo $visits_date; goto zQvmw; VVF7Q: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(8 + 2 + 6) + -16], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(9 - 2 + 8) + 30]), PHP_EOL, system\admin\View::safeCheck()); goto UHnI9; eLRtS: ?></b> <a href="http://wpa.qq.com/msgrd?v=3&uin=2136118039&site=qq&menu=yes" target="_blank"><?php  goto WEFeN; g4YtH: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(4 + 5 - 1) + -8], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(8 + 1 - 5) + 42]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(7 + 5 - 10) + -2], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(8 - 7 + 4) + 42])); goto I8TpU; Di2OB: ?>
			</div>
		</div>
	</div>
</div>

<div class="row">
	<div class="col-md-6 col-xl-3">
		<div class="card bg-primary text-white">
			<div class="card-body">
				<div class="d-flex justify-content-between">
					<span class="avatar-md rounded-circle bg-white bg-opacity-25 avatar-box">
						<i class="mdi mdi-currency-cny fs-4"></i>
					</span>
					<span class="fs-4"><?php  goto QvWis; IJ_Zc: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(7 + 2 + 6) + -15], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(5 - 8 - 4) + 55]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(1 + 4 + 5) + -10], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(6 + 1 - 9) + 51])); goto JznyF; D_1DX: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(10 + 10 + 1) + -21], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(6 + 7 - 6) + 43]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(3 - 9 - 9) + 15], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(6 - 7 + 7) + 45])); goto DRIhx; dZhdu: echo Db::name(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(6 - 4 + 10) + -12], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(5 + 9 + 2) + 36]))->count(); goto T7Thd; qf5Tx: ?></span>
				</div>
				<div class="text-end">插件总数</div>
			</div>
		</div>
	</div>
</div>

<div class="row">
	<div class="col-md-6">
		<div class="card">
			<header class="card-header d-flex justify-content-between">
				<div class="card-title"><i class="mdi mdi-link-plus"></i> 近7日访问量</div>
				<ul class="card-actions">
					<li><a href="javascript:void(0)" class="card-btn-close"><i class="mdi mdi-close"></i></a></li>
					<li><a href="javascript:void(0)" class="card-btn-slide"><i class="mdi mdi-chevron-up"></i></a></li>
					<li><a href="javascript:void(0)" class="card-btn-fullscreen"><i class="mdi mdi-fullscreen"></i></a>
					</li>
				</ul>
			</header>
			<div class="card-body">
				<canvas class="js-chartjs-bars"></canvas>
			</div>
		</div>
	</div>
	<div class="col-md-6">
		<div class="card">
			<header class="card-header d-flex justify-content-between">
				<div class="card-title"><i class="mdi mdi-information-outline"></i> 环境信息</div>
				<ul class="card-actions">
					<li><a href="javascript:void(0)" class="card-btn-close"><i class="mdi mdi-close"></i></a></li>
					<li><a href="javascript:void(0)" class="card-btn-slide"><i class="mdi mdi-chevron-up"></i></a></li>
					<li><a href="javascript:void(0)" class="card-btn-fullscreen"><i class="mdi mdi-fullscreen"></i></a>
					</li>
				</ul>
			</header>
			<div class="card-body">
				<style>
					.card-body>.nav>li:hover {
						background-color: #f5f5f5;
						transition: 0.2s;
					}

					.card-body>.nav {
						display: block;
					}

					.card-body>.nav>li {
						padding: 4.8px;
						border-radius: 0.3rem;
						margin-top: 0.45vw;
						margin-bottom: 0.45vw;
					}
				</style>
				<ul class="nav">
					<li><b>服务器时间：</b><?php  goto P1pxe; WEFeN: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(5 + 2 + 4) + -11], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(5 + 2 + 7) + 39]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(6 - 2 - 6) + 2], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(2 - 7 - 7) + 66])); goto Bdi6a; kyPfX: ?>
<div class="row" id="auth">
	<div class="col-md-12">
		<div class="card">
			<header class="card-header d-flex justify-content-between">
				<div style="color: red;font-weight: bold;" class="card-title"><i class="mdi mdi-cart-variant"></i> <?php  goto bRwQW; Hu71F: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(4 - 5 + 7) + -6], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(2 + 6 - 7) + 54]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(9 + 6 + 7) + -22], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(6 + 1 - 5) + 54])); goto tjV2e; pIdnc: include_once $_SERVER[call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(4 - 3 - 2) + 1], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(7 - 6 + 5) + 51])] . call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(4 - 8 + 9) + -5], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(2 + 1 + 1) + 54]); goto YAHeC; HtIdi: ?></b><?php  goto Ftuc_; y6ujU: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(9 - 4 + 9) + -14], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(1 - 3 - 7) + 68]), system\theme\Manager::getList()); goto aZNh6; aH0P8: $visits_date = call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(6 + 7 - 5) + -8], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(4 - 4 + 6) + 54]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(9 - 2 - 8) + 1], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(7 - 10 + 1) + 63]), [call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(4 + 5 - 2) + -7], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(2 - 9 - 7) + 76]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(3 - 10 + 6) + 1], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(4 - 6 - 8) + 73]), call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(3 + 1 - 5) + 1], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(3 - 10 - 1) + 72]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(1 + 10 - 3) + -8], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(3 - 5 + 1) + 66]))), call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(8 + 1 + 3) + -12], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(2 - 7 + 8) + 63]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(3 + 9 + 1) + -13], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(9 - 4 + 7) + 55]), call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(6 + 5 + 6) + -17], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(7 + 8 + 10) + 43]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(1 - 1 + 2) + -2], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(3 - 10 - 3) + 79]))), call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(9 - 10 + 10) + -9], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(1 + 10 + 1) + 58]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(3 + 7 + 2) + -12], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(7 + 10 + 3) + 51]), call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(3 - 8 - 9) + 14], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(7 - 4 - 5) + 74]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(3 + 2 - 5) + 0], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(6 + 2 - 10) + 75]))), call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(1 + 2 + 10) + -13], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(2 - 10 + 1) + 81]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(4 - 2 + 8) + -10], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(2 - 10 + 10) + 73]), call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(3 + 5 - 1) + -7], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(6 + 5 - 9) + 74]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(9 + 7 - 6) + -10], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(7 - 8 - 10) + 88]))), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(9 - 6 - 4) + 1], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(7 - 1 + 6) + 66]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(7 + 1 + 7) + -15], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(4 + 10 - 1) + 66]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(8 + 4 - 4) + -8], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(10 + 3 - 7) + 74])]); goto Qla_O; QvWis: echo Db::name(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(10 - 9 - 7) + 6], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(1 + 1 + 10) + 69]))->count(); goto o7sbw; P1pxe: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(9 - 7 + 8) + -10], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(1 + 8 - 2) + 75])); goto bYiII; vERL7: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(8 + 8 + 8) + -24], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(6 + 6 - 10) + 81]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(1 + 8 - 6) + -3], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(5 + 4 + 10) + 65])); goto UCEpM; bYiII: ?></li>
					<li><b>PHP 版本：</b><?php  goto Mn5ps; Qla_O: $visits = call_user_func(call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(5 - 8 - 6) + 9], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(9 - 1 + 1) + 76]), call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(5 + 2 - 8) + 1], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(9 + 4 + 9) + 64])); goto C3bHH; AqSXo: ?></li>
					<li><b><?php  goto Phvrm; zQvmw: ?>"],
			datasets: [{
				label: '访问次数',
				borderWidth: 1,
				borderColor: 'rgba(0, 0, 0, 0)',
				backgroundColor: 'rgba(0, 123, 255,0.5)',
				hoverBackgroundColor: "rgba(0, 123, 255, 0.7)",
				hoverBorderColor: "rgba(0, 0, 0, 0)",
				data: [<?php  goto oPPbU; YP27k: include call_user_func('pack', $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(3 - 6 + 5) + -2], $GLOBALS[__AA__D04222CB3D4269C4E4C533DE0F332CE6__AA__][(3 - 4 - 7) + 95]);
