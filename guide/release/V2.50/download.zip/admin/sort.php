<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2022-10-10 00:00:00
 * @LastEditTime  : 2024-08-14 06:32:58
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
if (!defined('__AA__5ACCDDDD2DCD3260A7DF8D7B874084A4__AA__')) define('__AA__5ACCDDDD2DCD3260A7DF8D7B874084A4__AA__', '__AA__5ACCDDDD2DCD3260A7DF8D7B874084A4__AA__');$GLOBALS[__AA__5ACCDDDD2DCD3260A7DF8D7B874084A4__AA__] = explode('?l?W?8', 'H*?l?W?86d6f64?l?W?86d6f64?l?W?8696e646578?l?W?8776964676574732f736f72742f?l?W?82e706870');$mod = isset($_GET[call_user_func('pack', $GLOBALS[__AA__5ACCDDDD2DCD3260A7DF8D7B874084A4__AA__][(4 + 10 + 7) + -21], $GLOBALS[__AA__5ACCDDDD2DCD3260A7DF8D7B874084A4__AA__][(1 + 1 - 10) + 9])]) ? $_GET[call_user_func('pack', $GLOBALS[__AA__5ACCDDDD2DCD3260A7DF8D7B874084A4__AA__][(7 + 9 + 8) + -24], $GLOBALS[__AA__5ACCDDDD2DCD3260A7DF8D7B874084A4__AA__][(9 + 5 - 10) + -2])] : call_user_func('pack', $GLOBALS[__AA__5ACCDDDD2DCD3260A7DF8D7B874084A4__AA__][(5 + 9 + 3) + -17], $GLOBALS[__AA__5ACCDDDD2DCD3260A7DF8D7B874084A4__AA__][(10 + 3 - 6) + -4]); require call_user_func('pack', $GLOBALS[__AA__5ACCDDDD2DCD3260A7DF8D7B874084A4__AA__][(10 + 10 + 6) + -26], $GLOBALS[__AA__5ACCDDDD2DCD3260A7DF8D7B874084A4__AA__][(3 + 8 + 10) + -17]) . $mod . call_user_func('pack', $GLOBALS[__AA__5ACCDDDD2DCD3260A7DF8D7B874084A4__AA__][(5 + 3 - 4) + -4], $GLOBALS[__AA__5ACCDDDD2DCD3260A7DF8D7B874084A4__AA__][(6 - 10 - 10) + 19]);
