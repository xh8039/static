<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2022-10-10 00:00:00
 * @LastEditTime  : 2024-08-14 06:32:58
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
if (!defined('__AA__809864B00517E452CF6FF877C80FB3E7__AA__')) define('__AA__809864B00517E452CF6FF877C80FB3E7__AA__', '__AA__809864B00517E452CF6FF877C80FB3E7__AA__');$GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__] = explode(';d;A;5', 'H*;d;A;563646e;d;A;5747769747465722d626f6f7473747261702f352e312e332f6373732f626f6f7473747261702e6d696e2e637373;d;A;56261736536345f6465636f6465;d;A;53570797335374f3735377566353553784944786849485268636d646c6444306958324a7359573572496942795a577739496d4e7663486c796157646f644342686458526f6233496759324675623235705932467349475a79615756755a43496761484a6c5a6a30696148523063446f764c3264316157526c4c6d4a796154597559323469507561596b2b6949717565396b655764674f57386c655776764f657a752b65376e7a777659543467356279363559716236616d783559716f4c43446e69596a6d6e4b7767;d;A;56f7074696f6e73;d;A;573697465;d;A;563646e;d;A;5747769747465722d626f6f7473747261702f352e312e332f6a732f626f6f7473747261702e6d696e2e6a73;d;A;56c6f676f7574;d;A;561646d696e;d;A;5686561646572;d;A;5436f6e74656e742d547970653a20746578742f68746d6c3b20636861727365743d5554462d38;d;A;53c736372697074206c616e67756167653d276a617661736372697074273e616c6572742827e682a8e5b7b2e68890e58a9fe6b3a8e99480e69cace6aca1e799bbe99986efbc8127293b77696e646f772e6c6f636174696f6e2e687265663d272e2f6c6f67696e2e706870273b3c2f7363726970743e;d;A;569735f696d616765;d;A;563646e;d;A;5616e696d6174652e6373732f342e312e312f616e696d6174652e6d696e2e637373;d;A;56b6579776f726473;d;A;54c69676874596561725635;d;A;56373732f7374796c652e6d696e2e637373;d;A;575736572;d;A;5707764;d;A;569735f696d616765;d;A;563617074636861;d;A;56d657373616765;d;A;5e9aa8ce8af81e7a081e4b88de883bde4b8bae7a9ba;d;A;5737472746f6c6f776572;d;A;5616464736c6173686573;d;A;57472696d;d;A;563617074636861;d;A;561646d696e5f63617074636861;d;A;56d657373616765;d;A;5e9aa8ce8af81e7a081e8bf87e69c9fefbc8ce8afb7e9878de696b0e88eb7e58f96e9aa8ce8af81e7a081;d;A;561646d696e5f63617074636861;d;A;561646d696e5f63617074636861;d;A;56d657373616765;d;A;5e9aa8ce8af81e7a081e99499e8afaf;d;A;561646d696e5f63617074636861;d;A;5616464736c6173686573;d;A;57472696d;d;A;575736572;d;A;5616464736c6173686573;d;A;57472696d;d;A;5707764;d;A;575736572;d;A;5707764;d;A;5737461747573;d;A;561646d696e;d;A;56d657373616765;d;A;5e8b4a6e58fb7e68896e5af86e7a081e99499e8afaf;d;A;561646d696e;d;A;5636f6465;d;A;57265666572726572;d;A;5696e6465782e706870;d;A;57265666572726572;d;A;5444f43554d454e545f524f4f54;d;A;52f7075626c69632f636f6d6d6f6e2e706870;d;A;57469746c65;d;A;57469746c65;d;A;56261736536345f6465636f6465;d;A;5504745676333523562475539496d4e76624739794f69416a4f546b354f79496761484a6c5a6a30696148523063446f764c32527659793569636d6b324c6d4e754c30426e64576c6b5a534967644746795a32563050534a66596d7868626d736949484a6c62443069626d3976634756755a584967626d39795a575a6c636e4a6c6369492b3562697535597170357061483571476a5043396850694469674b494b43516b4a4354786849484e306557786c50534a6a62327876636a6f67497a6b354f547369494768795a575939496d6830644841364c7939696247396e4c6d4a79615459755932346949485268636d646c6444306958324a7359573572496942795a577739496d35766233426c626d567949473576636d566d5a584a795a58496950756155722b614d67656975757557646d7a777659543467346f436943676b4a43516b385953427a64486c735a543069593239736233493649434d354f546b374969426f636d566d50534a6f64485277637a6f764c3264706447566c4c6d4e76625339356146394a5643396e64576c6b5a53397063334e315a584d6949485268636d646c6444306958324a7359573572496942795a577739496d35766233426c626d567949473576636d566d5a584a795a5849695075614b7065575269756d556d656976727a777659543467346f436943676b4a43516b385953427a64486c735a543069593239736233493649434d354f546b374969426f636d566d50534a6f64485277637a6f764c3264706447566c4c6d4e76625339356146394a5643396e64576c6b5a534967644746795a32563050534a66596d7868626d736949484a6c62443069626d3976634756755a584967626d39795a575a6c636e4a6c6369492b364c574535727151354c694c364c32395043396850673d3d;d;A;54c69676874596561725635;d;A;56a732f626f6f7473747261702d6e6f746966792e6d696e2e6a73;d;A;56f7074696f6e73;d;A;57468656d652e6261636b67726f756e64;d;A;56f7074696f6e73;d;A;57468656d652e6261636b67726f756e64;d;A;563646e;d;A;5706f707065722e6a732f322e31312e322f756d642f706f707065722e6d696e2e6a73;d;A;54c69676874596561725635;d;A;56373732f6d6174657269616c64657369676e69636f6e732e6d696e2e637373;d;A;54c69676874596561725635;d;A;56a732f6c796561722d6c6f6164696e672e6a73;d;A;56465736372697074696f6e;d;A;563646e;d;A;56a71756572792f332e362e312f6a71756572792e6d696e2e6a73;d;A;569735f7063');use JsonDb\JsonDb\Db; use system\library\Json; use system\library\Statics; goto mIrga; qblpy: ?>"></script>
	<script type="text/javascript" src="<?php  goto AMG6w; i78AP: ?>">
	<link rel="stylesheet" type="text/css" href="<?php  goto J3ULN; QGgAT: ?> mb-0 mr-2 ml-2">
		<div class="text-center mb-3">
			<a target="_blank" href="http://<?php  goto Kf8UJ; eCJxl: ?>">
<body class="center-vh" style="background-image: url(<?php  goto OqH28; fY7OO: ?>"></script>
	<style>
		.signin-form .has-feedback {
			position: relative;
		}

		.signin-form .has-feedback .form-control {
			padding-left: 36px;
		}

		.signin-form .has-feedback .mdi {
			position: absolute;
			top: 0;
			left: 0;
			right: auto;
			width: 36px;
			height: 36px;
			line-height: 36px;
			z-index: 4;
			color: #dcdcdc;
			display: block;
			text-align: center;
			pointer-events: none;
		}

		.signin-form .has-feedback.row .mdi {
			left: 15px;
		}
	</style>
</head>
<?php  goto pDqYf; SE2xr: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(7 + 8 - 5) + -10], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(2 + 7 + 10) + -18]), call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(4 + 6 + 3) + -13], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(1 + 4 + 8) + -11])); goto sFtq9; IG1gC: ?></title>
	<link rel="shortcut icon" type="image/x-icon" href="favicon.ico">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-touch-fullscreen" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="default">
	<link rel="stylesheet" type="text/css" href="<?php  goto fy0Fu; NWH0e: echo VERSION; goto FCdl2; MQaum: ?>">
	<meta name="author" content="易航">
	<title>后台登录 - <?php  goto AurkZ; ZhfEr: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(5 + 7 - 2) + -10], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(8 - 4 + 2) + -3]), call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(4 - 3 + 3) + -4], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(1 - 8 - 2) + 13])); goto NWH0e; NWhq5: $site = call_user_func(call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(4 + 8 - 4) + -8], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(9 + 6 + 3) + -13]), call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(6 + 1 + 2) + -9], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(2 + 9 - 3) + -2])); goto iBUwW; yU3Bf: ?>" src="/content/static/images/logo-banner.png"> </a>
		</div>

		<form action="" method="post" class="signin-form needs-validation" novalidate>
			<div class="mb-3 has-feedback">
				<span class="mdi mdi-account" aria-hidden="true"></span>
				<input type="text" class="form-control" name="user" placeholder="用户名" required>
			</div>

			<div class="mb-3 has-feedback">
				<span class="mdi mdi-lock" aria-hidden="true"></span>
				<input type="password" class="form-control" name="pwd" placeholder="密码" required>
			</div>

			<?php  goto cWWzl; sw9hr: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(1 + 9 - 1) + -9], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(3 - 1 - 6) + 11]), call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(7 - 9 + 6) + -4], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(4 + 9 - 7) + 2])); goto olYOx; HApjt: if (isset($_GET[call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(6 - 9 + 4) + -1], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(6 - 4 - 10) + 17])])) { unset($_SESSION[call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(9 - 6 - 3) + 0], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(10 + 5 - 7) + 2])]); call_user_func(call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(1 - 8 + 5) + 2], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(4 + 5 + 1) + 1]), call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(7 + 10 - 10) + -7], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(5 - 6 - 10) + 23])); exit(call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(9 - 4 + 9) + -14], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(2 - 8 + 10) + 9])); } goto ImJyc; cWWzl: if (call_user_func(call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(4 + 10 + 5) + -19], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(2 - 2 + 5) + 9]))) { ?>
				<div class="mb-3 has-feedback row">
					<div class="col-7">
						<span class="mdi mdi-check-all form-control-feedback" aria-hidden="true"></span>
						<input type="text" name="captcha" class="form-control" placeholder="验证码" required>
					</div>
					<div class="col-5 text-right">
						<img src="modules/captcha.php" class="pull-right" id="captcha" style="cursor: pointer;max-height: 38px;" onclick="this.src=this.src+'?d='+Math.random();" title="点击刷新" alt="captcha">
					</div>
				</div>
			<?php  } goto hJGYq; h4oTm: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(4 - 4 + 8) + -8], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(3 - 7 - 4) + 23]), call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(9 + 10 + 10) + -29], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(8 + 2 + 1) + 5])); goto i78AP; abaY6: echo $site[call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(6 - 5 + 7) + -8], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(9 + 2 - 5) + 11])]; goto G6Jrb; YIwVS: ?>
<img referrer="no-referrer" style="display: none;" src="<?php  goto r9xb8; BDsDt: ?>
			</div>
		</div>
	</div>
	<script type="text/javascript">
		var loader;
		$(document).ajaxStart(function() {
			$("button:submit").html('登录中...').attr("disabled", true);
			loader = $('button:submit').lyearloading({
				opacity: 0.2,
				spinnerSize: 'nm'
			});
		}).ajaxStop(function() {
			loader.destroy();
			$("button:submit").html('立即登录').attr("disabled", false);
		});
		$('.signin-form').on('submit', function(event) {
			if ($(this)[0].checkValidity() === false) {
				event.preventDefault();
				event.stopPropagation();
				$(this).addClass('was-validated');
				return false;
			}
			var $data = $(this).serialize();
			$.post($(this).attr('action'), $data, function(res) {
				if (res.code == 200) {
					$.notify({
						message: '登录成功，页面即将跳转~',
					}, {
						type: 'success',
						placement: {
							from: 'top',
							align: 'content'
						},
						z_index: 10800,
						delay: 1500,
						animate: {
							enter: 'animate__animated animate__fadeInUp',
							exit: 'animate__animated animate__fadeOutDown'
						}
					});
					setTimeout(function() {
						location.href = '<?php  goto BSPij; OqH28: echo $background; goto dnJ8b; rb1bH: ?>"></script>
	<script type="text/javascript" src="<?php  goto GMfuo; J3ULN: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(10 - 1 - 5) + -4], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(5 + 1 + 2) + 10]), call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(3 - 8 + 4) + 1], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(6 + 3 + 7) + 3])); goto qtprV; SsXCm: ?>"></script>
	<script type="text/javascript" src="<?php  goto sw9hr; ImJyc: if (isset($_POST[call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(6 - 10 - 4) + 8], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(6 - 8 - 10) + 32])]) && isset($_POST[call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(7 + 3 - 9) + -1], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(6 + 9 + 3) + 3])])) { if (call_user_func(call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(10 + 7 - 6) + -11], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(2 + 3 + 1) + 16]))) { if (empty($_POST[call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(10 - 9 - 7) + 6], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(10 - 6 - 2) + 21])])) { Json::echo([call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(8 - 6 - 2) + 0], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(4 - 7 + 10) + 17]) => call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(1 - 6 - 4) + 9], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(2 + 3 + 2) + 18])]); } $captcha = call_user_func(call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(9 - 9 - 5) + 5], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(10 - 7 + 4) + 19]), call_user_func(call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(3 - 1 - 7) + 5], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(7 - 8 + 7) + 21]), call_user_func(call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(10 - 10 + 6) + -6], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(7 + 8 - 2) + 15]), $_POST[call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(3 - 4 - 2) + 3], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(3 - 4 - 4) + 34])]))); if (empty($_SESSION[call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(3 - 7 + 2) + 2], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(2 + 5 - 7) + 30])])) { Json::echo([call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(10 - 3 + 10) + -17], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(7 + 1 + 9) + 14]) => call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(10 - 7 - 8) + 5], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(8 - 1 + 3) + 22])]); } if ($_SESSION[call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(9 + 9 + 10) + -28], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(6 + 4 + 9) + 14])] != $captcha) { unset($_SESSION[call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(7 + 7 + 3) + -17], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(9 - 1 + 2) + 24])]); Json::echo([call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(10 + 3 + 4) + -17], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(1 - 5 + 9) + 30]) => call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(4 - 6 + 6) + -4], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(5 + 1 + 10) + 20])]); } unset($_SESSION[call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(6 - 10 + 3) + 1], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(2 - 4 + 6) + 33])]); } $user = call_user_func(call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(3 + 1 - 3) + -1], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(8 + 10 + 5) + 15]), call_user_func(call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(6 + 7 + 4) + -17], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(9 + 6 - 2) + 26]), $_POST[call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(6 + 4 - 7) + -3], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(5 + 10 + 2) + 23])])); $pwd = call_user_func(call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(7 - 8 + 10) + -9], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(9 - 5 + 10) + 27]), call_user_func(call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(3 - 7 + 5) + -1], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(10 - 8 - 9) + 49]), $_POST[call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(3 + 9 + 4) + -16], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(7 - 3 + 8) + 31])])); $find_array = [call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(8 + 4 + 6) + -18], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(5 - 8 + 7) + 40]) => $user, call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(9 - 1 - 4) + -4], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(5 - 8 - 10) + 58]) => $pwd, call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(2 - 1 - 3) + 2], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(9 - 3 - 1) + 41]) => 1]; $find = Db::name(call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(5 + 7 + 9) + -21], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(9 - 4 - 5) + 47]))->where($find_array)->find(); if (empty($find)) { Json::echo([call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(8 + 2 - 1) + -9], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(3 - 10 + 10) + 45]) => call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(2 + 2 + 10) + -14], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(10 - 4 - 7) + 50])]); } $_SESSION[call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(1 - 5 + 8) + -4], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(2 + 1 - 9) + 56])] = $find; Json::echo([call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(1 - 8 + 9) + -2], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(8 + 8 - 2) + 37]) => 200]); } else { $location = empty($_GET[call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(9 - 9 - 1) + 1], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(1 - 1 - 6) + 58])]) ? call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(1 - 5 + 1) + 3], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(7 + 8 - 5) + 43]) : $_GET[call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(4 + 10 + 2) + -16], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(1 - 3 + 8) + 48])]; } goto NWhq5; Kf8UJ: echo DOMAIN; goto Nbu2k; FCdl2: ?></span>
			<div class="resource" style="color: #CCC;">
				<?php  goto AQiw5; qtprV: ?>">
	<script type="text/javascript" src="<?php  goto HXMT9; mIrga: include $_SERVER[call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(3 - 6 - 8) + 11], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(2 + 3 + 4) + 46])] . call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(10 + 6 + 2) + -18], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(2 + 6 - 9) + 57]); goto HApjt; AurkZ: echo $site[call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(3 - 3 - 3) + 3], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(2 - 4 - 5) + 64])]; goto IG1gC; dnJ8b: ?>); background-size: cover;">
	<div class="card card-shadowed p-<?php  goto CXt0Q; NiKgU: echo $site[call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(10 - 9 - 1) + 0], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(7 + 10 + 9) + 32])]; goto yU3Bf; iBUwW: ?>
<!DOCTYPE html>
<html lang="zh">

<head>
	<meta name="referrer" content="no-referrer" />
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
	<meta name="keywords" content="<?php  goto abaY6; AQiw5: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(8 - 1 - 4) + -3], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(10 - 8 + 8) + 49]), call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(6 - 8 - 9) + 11], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(6 + 8 + 9) + 37])); goto BDsDt; GMfuo: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(6 - 3 + 3) + -6], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(1 + 1 + 1) + 58]), call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(5 + 4 - 7) + -2], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(6 - 10 - 10) + 76])); goto fY7OO; pDqYf: $background = empty(call_user_func(call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(10 - 2 - 9) + 1], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(9 - 6 - 5) + 65]), call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(7 + 3 + 3) + -13], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(7 + 1 - 6) + 62]))) ? Statics::background_image() : call_user_func(call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(8 + 1 - 7) + -2], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(1 - 7 + 9) + 62]), call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(1 - 1 - 2) + 2], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(10 - 4 + 3) + 57])); goto YIwVS; AMG6w: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(3 + 2 - 7) + 2], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(9 + 8 + 8) + 42]), call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(3 + 2 + 7) + -12], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(6 + 5 + 5) + 52])); goto SsXCm; hJGYq: ?>

			<div class="mb-3">
				<div class="form-check">
					<input type="checkbox" class="form-check-input" id="rememberme">
					<label class="form-check-label not-user-select" for="rememberme">5天内自动登录</label>
				</div>
			</div>

			<div class="mb-3 d-grid">
				<button class="btn btn-primary" type="submit">立即登录</button>
			</div>
		</form>

		<div style="color: #999;line-height: 1.8;text-align: center;" role="contentinfo">
			<span class="copyright"><?php  goto ZhfEr; sFtq9: ?>">
	<link rel="stylesheet" type="text/css" href="<?php  goto h4oTm; fy0Fu: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(10 + 10 - 8) + -12], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(3 + 6 + 4) + 56]), call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(6 + 5 + 9) + -20], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(9 + 6 - 3) + 58])); goto Zmr9v; lsk7r: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(9 - 9 + 1) + -1], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(1 - 6 + 1) + 75]), call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(7 - 3 + 2) + -6], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(3 + 10 - 10) + 69])); goto rb1bH; r9xb8: echo $background; goto eCJxl; BSPij: echo $location; goto Uj0Xv; G6Jrb: ?>">
	<meta name="description" content="<?php  goto f5DDx; f5DDx: echo $site[call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(10 - 9 + 8) + -9], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(5 + 10 + 7) + 51])]; goto MQaum; HXMT9: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(9 + 9 + 2) + -20], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(8 - 8 - 9) + 83]), call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(2 + 6 - 6) + -2], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(10 - 10 + 2) + 73])); goto qblpy; Zmr9v: ?>">
	<link rel="stylesheet" type="text/css" href="<?php  goto SE2xr; Nbu2k: ?>"> <img width="210px" alt="<?php  goto NiKgU; CXt0Q: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(4 + 8 - 7) + -5], $GLOBALS[__AA__809864B00517E452CF6FF877C80FB3E7__AA__][(6 + 5 + 9) + 56])) ? 5 : 4; goto QGgAT; olYOx: ?>"></script>
	<script type="text/javascript" src="<?php  goto lsk7r; Uj0Xv: ?>';
					}, 1500);
				} else {
					if (res.message == '验证码错误') {
						$('input[name=captcha]').val('');
					}
					$.notify({
						message: '登录失败：' + res.message,
					}, {
						type: 'danger',
						placement: {
							from: 'top',
							align: 'content'
						},
						z_index: 10800,
						delay: 1500,
						animate: {
							enter: 'animate__animated animate__shakeX',
							exit: 'animate__animated animate__fadeOutDown'
						}
					});
					$('#password').val('');
					$("#captcha").click();
				}
			}).fail(function() {
				$.notify({
					message: '服务器错误',
				}, {
					type: 'danger',
					placement: {
						from: 'top',
						align: 'content'
					},
					z_index: 10800,
					delay: 1500,
					animate: {
						enter: 'animate__animated animate__shakeX',
						exit: 'animate__animated animate__fadeOutDown'
					}
				});
			});
			return false;
		});
	</script>
</body>

</html>
