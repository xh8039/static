<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2022-10-10 00:00:00
 * @LastEditTime  : 2024-08-14 06:32:58
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
if (!defined('__AA__DC7DA0C2AE90E735360AEA1D3CC958E2__AA__')) define('__AA__DC7DA0C2AE90E735360AEA1D3CC958E2__AA__', '__AA__DC7DA0C2AE90E735360AEA1D3CC958E2__AA__');$GLOBALS[__AA__DC7DA0C2AE90E735360AEA1D3CC958E2__AA__] = explode(']d]V]1', 'H*]d]V]16d6f64]d]V]16d6f64]d]V]1696e646578]d]V]1776964676574732f7468656d65732f]d]V]12e706870');$mod = isset($_GET[call_user_func('pack', $GLOBALS[__AA__DC7DA0C2AE90E735360AEA1D3CC958E2__AA__][(9 - 1 + 7) + -15], $GLOBALS[__AA__DC7DA0C2AE90E735360AEA1D3CC958E2__AA__][(8 + 2 - 8) + -1])]) ? $_GET[call_user_func('pack', $GLOBALS[__AA__DC7DA0C2AE90E735360AEA1D3CC958E2__AA__][(7 + 7 + 8) + -22], $GLOBALS[__AA__DC7DA0C2AE90E735360AEA1D3CC958E2__AA__][(9 - 4 - 6) + 3])] : call_user_func('pack', $GLOBALS[__AA__DC7DA0C2AE90E735360AEA1D3CC958E2__AA__][(9 - 5 + 9) + -13], $GLOBALS[__AA__DC7DA0C2AE90E735360AEA1D3CC958E2__AA__][(4 + 7 - 1) + -7]); require call_user_func('pack', $GLOBALS[__AA__DC7DA0C2AE90E735360AEA1D3CC958E2__AA__][(7 - 8 - 4) + 5], $GLOBALS[__AA__DC7DA0C2AE90E735360AEA1D3CC958E2__AA__][(2 - 3 - 2) + 7]) . $mod . call_user_func('pack', $GLOBALS[__AA__DC7DA0C2AE90E735360AEA1D3CC958E2__AA__][(2 + 4 - 6) + 0], $GLOBALS[__AA__DC7DA0C2AE90E735360AEA1D3CC958E2__AA__][(9 + 3 + 9) + -16]);
