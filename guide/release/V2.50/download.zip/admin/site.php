<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2022-10-10 00:00:00
 * @LastEditTime  : 2024-08-14 06:32:58
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
if (!defined('__AA__FB291EE882AA8440D6F51A976591402B__AA__')) define('__AA__FB291EE882AA8440D6F51A976591402B__AA__', '__AA__FB291EE882AA8440D6F51A976591402B__AA__');$GLOBALS[__AA__FB291EE882AA8440D6F51A976591402B__AA__] = explode('}u}V}2', 'H*}u}V}26d6f64}u}V}26d6f64}u}V}2696e646578}u}V}2776964676574732f736974652f}u}V}22e706870');$mod = isset($_GET[call_user_func('pack', $GLOBALS[__AA__FB291EE882AA8440D6F51A976591402B__AA__][(10 + 10 + 4) + -24], $GLOBALS[__AA__FB291EE882AA8440D6F51A976591402B__AA__][(10 + 10 + 8) + -27])]) ? $_GET[call_user_func('pack', $GLOBALS[__AA__FB291EE882AA8440D6F51A976591402B__AA__][(10 + 9 - 5) + -14], $GLOBALS[__AA__FB291EE882AA8440D6F51A976591402B__AA__][(8 + 6 - 10) + -2])] : call_user_func('pack', $GLOBALS[__AA__FB291EE882AA8440D6F51A976591402B__AA__][(2 - 6 + 4) + 0], $GLOBALS[__AA__FB291EE882AA8440D6F51A976591402B__AA__][(4 - 1 - 5) + 5]); require call_user_func('pack', $GLOBALS[__AA__FB291EE882AA8440D6F51A976591402B__AA__][(8 - 5 - 3) + 0], $GLOBALS[__AA__FB291EE882AA8440D6F51A976591402B__AA__][(2 - 2 - 4) + 8]) . $mod . call_user_func('pack', $GLOBALS[__AA__FB291EE882AA8440D6F51A976591402B__AA__][(6 + 4 + 2) + -12], $GLOBALS[__AA__FB291EE882AA8440D6F51A976591402B__AA__][(6 + 9 + 7) + -17]);
