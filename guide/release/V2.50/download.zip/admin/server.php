<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2022-10-10 00:00:00
 * @LastEditTime  : 2024-08-14 06:32:58
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
if (!defined('__AA__087B608D04EA5B8B4CD380B858C29BE7__AA__')) define('__AA__087B608D04EA5B8B4CD380B858C29BE7__AA__', '__AA__087B608D04EA5B8B4CD380B858C29BE7__AA__');$GLOBALS[__AA__087B608D04EA5B8B4CD380B858C29BE7__AA__] = explode('|a|Z|8', 'H*|a|Z|869735f6172726179|a|Z|869735f6f626a656374|a|Z|8444f43554d454e545f524f4f54|a|Z|82f7075626c69632f636f6d6d6f6e2e706870|a|Z|87472696d|a|Z|8616374696f6e|a|Z|8696e646578|a|Z|8687474705f726573706f6e73655f636f6465');use system\library\Json; goto A9SPM; QLrEi: if (call_user_func(call_user_func('pack', $GLOBALS[__AA__087B608D04EA5B8B4CD380B858C29BE7__AA__][(1 - 7 - 4) + 10], $GLOBALS[__AA__087B608D04EA5B8B4CD380B858C29BE7__AA__][(9 - 8 + 9) + -9]), $return) || call_user_func(call_user_func('pack', $GLOBALS[__AA__087B608D04EA5B8B4CD380B858C29BE7__AA__][(6 + 2 + 9) + -17], $GLOBALS[__AA__087B608D04EA5B8B4CD380B858C29BE7__AA__][(6 - 6 - 9) + 11]), $return)) { $return = Json::encode($return); } goto uAqhD; CjDV1: $return = system\admin\Server::$action(); goto QLrEi; A9SPM: require $_SERVER[call_user_func('pack', $GLOBALS[__AA__087B608D04EA5B8B4CD380B858C29BE7__AA__][(1 - 1 + 4) + -4], $GLOBALS[__AA__087B608D04EA5B8B4CD380B858C29BE7__AA__][(8 + 9 - 3) + -11])] . call_user_func('pack', $GLOBALS[__AA__087B608D04EA5B8B4CD380B858C29BE7__AA__][(2 + 1 + 3) + -6], $GLOBALS[__AA__087B608D04EA5B8B4CD380B858C29BE7__AA__][(6 + 5 - 9) + 2]); goto IfFUt; IfFUt: $action = call_user_func(call_user_func('pack', $GLOBALS[__AA__087B608D04EA5B8B4CD380B858C29BE7__AA__][(1 - 4 + 9) + -6], $GLOBALS[__AA__087B608D04EA5B8B4CD380B858C29BE7__AA__][(6 - 4 + 8) + -5]), $_GET[call_user_func('pack', $GLOBALS[__AA__087B608D04EA5B8B4CD380B858C29BE7__AA__][(5 - 1 + 7) + -11], $GLOBALS[__AA__087B608D04EA5B8B4CD380B858C29BE7__AA__][(1 + 1 - 10) + 14])] ?? call_user_func('pack', $GLOBALS[__AA__087B608D04EA5B8B4CD380B858C29BE7__AA__][(4 - 1 - 1) + -2], $GLOBALS[__AA__087B608D04EA5B8B4CD380B858C29BE7__AA__][(8 - 4 - 9) + 12])); goto CjDV1; uAqhD: if (!empty($return)) { echo $return; } else { call_user_func(call_user_func('pack', $GLOBALS[__AA__087B608D04EA5B8B4CD380B858C29BE7__AA__][(10 + 7 - 3) + -14], $GLOBALS[__AA__087B608D04EA5B8B4CD380B858C29BE7__AA__][(8 - 3 - 8) + 11]), 404); }
