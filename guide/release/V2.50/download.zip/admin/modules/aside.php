<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2022-10-10 00:00:00
 * @LastEditTime  : 2024-08-14 06:32:58
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
if (!defined('__AA__940FBBA98BC26891986F5B8340705908__AA__')) define('__AA__940FBBA98BC26891986F5B8340705908__AA__', '__AA__940FBBA98BC26891986F5B8340705908__AA__');$GLOBALS[__AA__940FBBA98BC26891986F5B8340705908__AA__] = explode('?i?R?6', 'H*?i?R?66f7074696f6e73?i?R?63c6c6920636c6173733d226e61762d6974656d223e3c6120687265663d227468656d65732e7068703f6d6f643d6f7074696f6e73223ee4b8bbe9a298e8aebee7bdae3c2f613e3c2f6c693e?i?R?66261736536345f6465636f6465?i?R?6353553784944786849485268636d646c6444306958324a73595735724969426f636d566d50534a6f644852774f6938765a3356705a475575596e4a704e69356a6269492b357069543649697135373252355a32413562795635612b3835374f3735377566504339685069446c764c726c697076707162486c6971673d?i?R?66261736536345f6465636f6465?i?R?65047456761484a6c5a6a30696148523063484d364c7939355a5842355a485a74634868764c6d73756447397764476870626d7375593239744c30426e64576c6b5a53386949485268636d646c6444306958324a7359573572496a376c754b376c69716e6d6c6f666d6f614d384c32452b494f4b416f6941385953426f636d566d50534a6f644852774f693876596e4a704e69356a62693968636d4e6f61585a6c6379387a4d7a55756148527462434967644746795a32563050534a66596d7868626d736950756155722b614d67656975757557646d7a77765954344b50474a794943382b436a7868494768795a575939496d68306448427a4f6938765a326c305a575575593239744c336c6f58306c554c3264316157526c4c326c7a6333566c63794967644746795a32563050534a66596d7868626d73695075614b7065575269756d556d656976727a777659543467346f436949447868494768795a575939496d68306448427a4f6938765a326c305a575575593239744c336c6f58306c554c3264316157526c4969423059584a6e5a585139496c3969624746756179492b364c574535727151354c694c364c32395043396850673d3d');use system\theme\Manager; goto qZmPl; wgcMX: ?>
					</ul>
				</li>
				<li class="nav-item">
					<a href="plugins.php">
						<svg class="icon" aria-hidden="true">
							<use xlink:href="#icon-chajian"></use>
						</svg>
						<span>插件管理</span>
					</a>
				</li>
				<li class="nav-item">
					<a href="update.php">
						<svg class="icon" aria-hidden="true">
							<use xlink:href="#icon-xitonggengxin"></use>
						</svg>
						<span>检查更新</span>
					</a>
				</li>
			</ul>
			<script>
				(function() {
					var pathname = window.location.pathname;
					var search = window.location.search;
					var path = search ? pathname + search : pathname;
					$('.nav-drawer').find('a').each(function() {
						temp_path = '/admin/' + $(this).attr('href');
						if (path == temp_path) {
							$('.nav-drawer').find('.nav-item').removeClass('active').removeClass('open');
							$('.nav-drawer').find('.nav-subnav:visible').slideUp(500);
							$(this).parent('li').addClass('active');
							$(this).parents('.nav-subnav').slideDown(500);
							$(this).parents('.nav-item').addClass('open');
							$(this).parents('.nav-item').last().addClass('active');
						}
					});
				}())
			</script>
		</nav>
		<div class="sidebar-footer">
			<div class="copyright">
				<span role="contentinfo"><?php  goto kO1Q3; FlS8M: echo Manager::getInfo(THEME, false, true)[call_user_func('pack', $GLOBALS[__AA__940FBBA98BC26891986F5B8340705908__AA__][(9 - 9 - 2) + 2], $GLOBALS[__AA__940FBBA98BC26891986F5B8340705908__AA__][(10 - 10 - 8) + 9])] ? call_user_func('pack', $GLOBALS[__AA__940FBBA98BC26891986F5B8340705908__AA__][(1 - 7 - 8) + 14], $GLOBALS[__AA__940FBBA98BC26891986F5B8340705908__AA__][(4 + 2 - 5) + 1]) : null; goto wgcMX; LFko1: ?></span>
				<div class="resource">
					<?php  goto Exom5; qZmPl: ?>
<aside class="lyear-layout-sidebar">
	<!-- logo -->
	<div id="logo" class="sidebar-header">
		<a style="display: flex;align-items: center;justify-content: center;" href="http://guide.bri6.cn" target="_blank"><img style="width: 80%;" src="/content/static/images/logo-banner.png" title="易导航系统" alt="易导航系统" /></a>
	</div>
	<div class="lyear-layout-sidebar-info lyear-scroll">
		<nav class="sidebar-main">
			<ul class="nav-drawer">
				<li class="nav-item">
					<a href="index.php">
						<svg class="icon" aria-hidden="true">
							<use xlink:href="#icon--"></use>
						</svg>
						<span>后台首页</span>
					</a>
				</li>
				<li class="nav-item nav-item-has-subnav">
					<a href="javascript:void(0)">
						<svg class="icon" aria-hidden="true">
							<use xlink:href="#icon-peizhi"></use>
						</svg>
						<span>系统管理</span>
					</a>
					<ul class="nav nav-subnav">
						<li class="nav-item"><a href="set.php?mod=options">系统配置</a></li>
						<li class="nav-item"><a href="set.php?mod=tool">自助工具</a></li>
					</ul>
				</li>
				<li class="nav-item nav-item-has-subnav">
					<a href="javascript:void(0)">
						<svg class="icon" aria-hidden="true">
							<use xlink:href="#icon-daohang1"></use>
						</svg>
						<span>分类管理</span>
					</a>
					<ul class="nav nav-subnav">
						<li class="nav-item"><a href="sort.php">分类列表</a></li>
						<li class="nav-item"><a data-url="sort.php?mod=create" class="layer_iframe">新增分类</a></li>
					</ul>
				</li>
				<li class="nav-item nav-item-has-subnav">
					<a href="javascript:void(0)">
						<svg class="icon" aria-hidden="true">
							<use xlink:href="#icon-daohang2"></use>
						</svg>
						<span>站点管理</span>
					</a>
					<ul class="nav nav-subnav">
						<li class="nav-item"><a href="site.php">站点列表</a></li>
						<li class="nav-item"><a data-url="site.php?mod=create" class="layer_iframe">新增站点</a></li>
					</ul>
				</li>
				<li class="nav-item nav-item-has-subnav">
					<a href="javascript:void(0)">
						<svg class="icon" aria-hidden="true">
							<use xlink:href="#icon-changyonglianjie"></use>
						</svg>
						<span>友链管理</span>
					</a>
					<ul class="nav nav-subnav">
						<li class="nav-item"><a href="friends.php">友链列表</a></li>
						<li class="nav-item"><a data-url="friends.php?mod=create" class="layer_iframe">新增友链</a></li>
					</ul>
				</li>
				<li class="nav-item nav-item-has-subnav">
					<a href="javascript:void(0)">
						<svg class="icon" aria-hidden="true">
							<use xlink:href="#icon-43_zhuti"></use>
						</svg>
						<span>主题管理</span>
					</a>
					<ul class="nav nav-subnav">
						<li class="nav-item"><a href="themes.php">选择主题</a></li>
						<?php  goto FlS8M; kO1Q3: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__940FBBA98BC26891986F5B8340705908__AA__][(8 + 1 + 6) + -15], $GLOBALS[__AA__940FBBA98BC26891986F5B8340705908__AA__][(6 + 10 - 2) + -11]), call_user_func('pack', $GLOBALS[__AA__940FBBA98BC26891986F5B8340705908__AA__][(6 + 8 + 2) + -16], $GLOBALS[__AA__940FBBA98BC26891986F5B8340705908__AA__][(9 - 10 + 5) + 0])); goto LFko1; Exom5: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__940FBBA98BC26891986F5B8340705908__AA__][(5 - 7 + 2) + 0], $GLOBALS[__AA__940FBBA98BC26891986F5B8340705908__AA__][(3 - 3 + 4) + 1]), call_user_func('pack', $GLOBALS[__AA__940FBBA98BC26891986F5B8340705908__AA__][(10 + 4 - 3) + -11], $GLOBALS[__AA__940FBBA98BC26891986F5B8340705908__AA__][(3 + 10 + 8) + -15])); goto pZWN9; pZWN9: ?>
				</div>
			</div>
		</div>
	</div>
</aside>
