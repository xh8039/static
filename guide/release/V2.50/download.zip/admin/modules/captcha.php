<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2022-10-10 00:00:00
 * @LastEditTime  : 2024-08-14 06:32:58
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
if (!defined('__AA__E2990E46BE8DF5C24AF4AE44364E903A__AA__')) define('__AA__E2990E46BE8DF5C24AF4AE44364E903A__AA__', '__AA__E2990E46BE8DF5C24AF4AE44364E903A__AA__');$GLOBALS[__AA__E2990E46BE8DF5C24AF4AE44364E903A__AA__] = explode('<e<N<8', 'H*<e<N<8444f43554d454e545f524f4f54<e<N<82f73797374656d2f6c6962726172792f436170746368612e706870<e<N<873657373696f6e5f7374617274<e<N<861646d696e5f63617074636861');goto COhCh; EndOj: require $_SERVER[call_user_func('pack', $GLOBALS[__AA__E2990E46BE8DF5C24AF4AE44364E903A__AA__][(4 + 9 - 5) + -8], $GLOBALS[__AA__E2990E46BE8DF5C24AF4AE44364E903A__AA__][(4 + 6 - 3) + -6])] . call_user_func('pack', $GLOBALS[__AA__E2990E46BE8DF5C24AF4AE44364E903A__AA__][(9 + 1 - 1) + -9], $GLOBALS[__AA__E2990E46BE8DF5C24AF4AE44364E903A__AA__][(4 + 3 + 7) + -12]); goto XyBdq; COhCh: call_user_func(call_user_func('pack', $GLOBALS[__AA__E2990E46BE8DF5C24AF4AE44364E903A__AA__][(4 + 2 - 3) + -3], $GLOBALS[__AA__E2990E46BE8DF5C24AF4AE44364E903A__AA__][(3 - 2 - 5) + 7])); goto EndOj; M1Hw0: $_vc->doimg(); goto kJx_r; XyBdq: $_vc = new system\library\Captcha(); goto M1Hw0; kJx_r: $_SESSION[call_user_func('pack', $GLOBALS[__AA__E2990E46BE8DF5C24AF4AE44364E903A__AA__][(8 - 7 - 3) + 2], $GLOBALS[__AA__E2990E46BE8DF5C24AF4AE44364E903A__AA__][(3 - 1 + 3) + -1])] = $_vc->getCode();
