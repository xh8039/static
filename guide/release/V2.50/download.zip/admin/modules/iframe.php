<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2022-10-10 00:00:00
 * @LastEditTime  : 2024-08-14 06:32:58
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
if (!defined('__AA__2407D12CA56512C9F9F59DB1316522B1__AA__')) define('__AA__2407D12CA56512C9F9F59DB1316522B1__AA__', '__AA__2407D12CA56512C9F9F59DB1316522B1__AA__');$GLOBALS[__AA__2407D12CA56512C9F9F59DB1316522B1__AA__] = explode(':s:D:3', 'H*:s:D:3686561642e706870:s:D:3444f43554d454e545f524f4f54:s:D:32f7075626c69632f636f6d6d6f6e2e706870');goto LEhCu; M37sK: include_once call_user_func('pack', $GLOBALS[__AA__2407D12CA56512C9F9F59DB1316522B1__AA__][(2 - 5 + 5) + -2], $GLOBALS[__AA__2407D12CA56512C9F9F59DB1316522B1__AA__][(9 + 5 - 6) + -7]); goto Rqkf0; Rqkf0: ?>
	<script type="text/javascript" src="assets/js/server.min.js?version<?php  goto V8WOd; V8WOd: echo VERSION; goto qNSjQ; cGBrJ: ?>
<!DOCTYPE html>
<html lang="zh">

<head>
	<?php  goto M37sK; xyMUx: system\admin\Admin::check(); goto cGBrJ; LEhCu: require_once $_SERVER[call_user_func('pack', $GLOBALS[__AA__2407D12CA56512C9F9F59DB1316522B1__AA__][(8 + 1 + 6) + -15], $GLOBALS[__AA__2407D12CA56512C9F9F59DB1316522B1__AA__][(2 + 5 + 5) + -10])] . call_user_func('pack', $GLOBALS[__AA__2407D12CA56512C9F9F59DB1316522B1__AA__][(6 + 10 - 7) + -9], $GLOBALS[__AA__2407D12CA56512C9F9F59DB1316522B1__AA__][(6 - 10 - 5) + 12]); goto xyMUx; qNSjQ: ?>"></script>
</head>

<body style="background-color: #fff;height:auto">
	<div class="lyear-layout-web">
		<div class="lyear-layout-container">
			<!--页面主要内容-->
			<main>
				<div style="padding:0.5rem 1.5rem 1.5rem 1.5rem;">
