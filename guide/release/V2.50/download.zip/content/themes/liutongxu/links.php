<!DOCTYPE html>
<html lang="zh-CN">

<head>
	<base href="<?= $this->themeUrl ?>/" />
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<title>Links | 一为导航</title>
	<meta name="theme-color" content="#f9f9f9">
	<meta name="keywords" content="UI设计,UI设计素材,设计导航,网址导航,设计资源,创意导航,创意网站导航,设计师网址大全,设计素材大全,设计师导航,UI设计资源,优秀UI设计欣赏,设计师导航,设计师网址大全,设计师网址导航,产品经理网址导航,交互设计师网址导航">
	<meta name="description" content="一为忆 - 收集国内外优秀设计网站、UI设计资源网站、灵感创意网站、素材资源网站，定时更新分享优质产品设计书签。">
	<meta property="og:type" content="article">
	<meta property="og:url" content="https://nav.iowen.cn/links">
	<meta property="og:title" content="Links | 一为导航">
	<meta property="og:description" content="一为忆 - 收集国内外优秀设计网站、UI设计资源网站、灵感创意网站、素材资源网站，定时更新分享优质产品设计书签。">
	<meta property="og:image" content="https://gitee.com/iowen/ioimg/raw/master/screenshots/1.jpg">
	<meta property="og:site_name" content="一为导航">
	<link rel='stylesheet' id='wp-block-library-css' href='assets/css/dist/block-library/style.min-5.6.2.css' type='text/css' media='all'>
	<link rel='stylesheet' id='iconfont-css' href='assets/css/iconfont.css' type='text/css' media='all'>
	<link rel='stylesheet' id='iconfontd-css' href='assets/fonts/font_1620678_7g0p3h6gbl-3.03029.css' type='text/css' media='all'>
	<link rel='stylesheet' id='bootstrap-css' href='<?= $this->cdn('twitter-bootstrap/4.3.1/css/bootstrap.min.css') ?>' type='text/css' media='all'>
	<link rel='stylesheet' id='lightbox-css' href='<?= $this->cdn('fancybox/3.5.7/jquery.fancybox.min.css') ?>' type='text/css' media='all'>
	<link rel='stylesheet' id='style-css' href='assets/css/style.css' type='text/css' media='all'>
	<script type='text/javascript' src='<?= $this->cdn('jquery/3.6.1/jquery.min.js') ?>' id='jquery-js'></script>
	<link rel="canonical" href="">
	<style>
		#footer-tools [data-v-db6ccf64][data-v-41ba7e2c] {
			top: unset !important;
			bottom: 0 !important;
			right: 44px !important
		}

		.io.icon-fw,
		.iconfont.icon-fw {
			width: 1.15em;
		}

		.io.icon-lg,
		.iconfont.icon-lg {
			font-size: 1.5em;
			line-height: .75em;
			vertical-align: -.125em;
		}

		.screenshot-carousel .img_wrapper a {
			display: contents
		}

		.fancybox-slide--iframe .fancybox-content {
			max-width: 1280px;
			margin: 0
		}

		.fancybox-slide--iframe.fancybox-slide {
			padding: 44px 0
		}

		.navbar-nav .menu-item-286 a {
			background: #ff8116;
			border-radius: 50px !important;
			padding: 5px 10px !important;
			margin: 5px 0 !important;
			color: #fff !important;
		}

		.navbar-nav .menu-item-286 a i {
			position: absolute;
			top: 0;
			right: -10px;
			color: #f13522;
		}

		.io-black-mode .navbar-nav .menu-item-286 a {
			background: #ce9412;
		}

		.io-black-mode .navbar-nav .menu-item-286 a i {
			color: #fff;
		}
	</style><!-- 自定义代码 -->
	<!-- end 自定义代码 -->
</head>

<body class="io-grey-mode">
	<div id="loading">
		<style>
			.loader {
				position: absolute;
				left: 50%;
				top: 50%;
				width: 48.2842712474619px;
				height: 48.2842712474619px;
				margin-left: -24.14213562373095px;
				margin-top: -24.14213562373095px;
				border-radius: 100%;
				-webkit-animation-name: loader;
				animation-name: loader;
				-webkit-animation-iteration-count: infinite;
				animation-iteration-count: infinite;
				-webkit-animation-timing-function: linear;
				animation-timing-function: linear;
				-webkit-animation-duration: 4s;
				animation-duration: 4s
			}

			.loader .side {
				display: block;
				width: 6px;
				height: 20px;
				background-color: #f1404b;
				margin: 2px;
				position: absolute;
				border-radius: 50%;
				-webkit-animation-duration: 1.5s;
				animation-duration: 1.5s;
				-webkit-animation-iteration-count: infinite;
				animation-iteration-count: infinite;
				-webkit-animation-timing-function: ease;
				animation-timing-function: ease
			}

			.loader .side:nth-child(1),
			.loader .side:nth-child(5) {
				transform: rotate(0deg);
				-webkit-animation-name: rotate0;
				animation-name: rotate0
			}

			.loader .side:nth-child(3),
			.loader .side:nth-child(7) {
				transform: rotate(90deg);
				-webkit-animation-name: rotate90;
				animation-name: rotate90
			}

			.loader .side:nth-child(2),
			.loader .side:nth-child(6) {
				transform: rotate(45deg);
				-webkit-animation-name: rotate45;
				animation-name: rotate45
			}

			.loader .side:nth-child(4),
			.loader .side:nth-child(8) {
				transform: rotate(135deg);
				-webkit-animation-name: rotate135;
				animation-name: rotate135
			}

			.loader .side:nth-child(1) {
				top: 24.14213562373095px;
				left: 48.2842712474619px;
				margin-left: -3px;
				margin-top: -10px;
				-webkit-animation-delay: 0;
				animation-delay: 0
			}

			.loader .side:nth-child(2) {
				top: 41.21320343109277px;
				left: 41.21320343109277px;
				margin-left: -3px;
				margin-top: -10px;
				-webkit-animation-delay: 0;
				animation-delay: 0
			}

			.loader .side:nth-child(3) {
				top: 48.2842712474619px;
				left: 24.14213562373095px;
				margin-left: -3px;
				margin-top: -10px;
				-webkit-animation-delay: 0;
				animation-delay: 0
			}

			.loader .side:nth-child(4) {
				top: 41.21320343109277px;
				left: 7.07106781636913px;
				margin-left: -3px;
				margin-top: -10px;
				-webkit-animation-delay: 0;
				animation-delay: 0
			}

			.loader .side:nth-child(5) {
				top: 24.14213562373095px;
				left: 0px;
				margin-left: -3px;
				margin-top: -10px;
				-webkit-animation-delay: 0;
				animation-delay: 0
			}

			.loader .side:nth-child(6) {
				top: 7.07106781636913px;
				left: 7.07106781636913px;
				margin-left: -3px;
				margin-top: -10px;
				-webkit-animation-delay: 0;
				animation-delay: 0
			}

			.loader .side:nth-child(7) {
				top: 0px;
				left: 24.14213562373095px;
				margin-left: -3px;
				margin-top: -10px;
				-webkit-animation-delay: 0;
				animation-delay: 0
			}

			.loader .side:nth-child(8) {
				top: 7.07106781636913px;
				left: 41.21320343109277px;
				margin-left: -3px;
				margin-top: -10px;
				-webkit-animation-delay: 0;
				animation-delay: 0
			}

			@-webkit-keyframes rotate0 {
				0% {
					transform: rotate(0deg)
				}

				60% {
					transform: rotate(180deg)
				}

				100% {
					transform: rotate(180deg)
				}
			}

			@keyframes rotate0 {
				0% {
					transform: rotate(0deg)
				}

				60% {
					transform: rotate(180deg)
				}

				100% {
					transform: rotate(180deg)
				}
			}

			@-webkit-keyframes rotate90 {
				0% {
					transform: rotate(90deg)
				}

				60% {
					transform: rotate(270deg)
				}

				100% {
					transform: rotate(270deg)
				}
			}

			@keyframes rotate90 {
				0% {
					transform: rotate(90deg)
				}

				60% {
					transform: rotate(270deg)
				}

				100% {
					transform: rotate(270deg)
				}
			}

			@-webkit-keyframes rotate45 {
				0% {
					transform: rotate(45deg)
				}

				60% {
					transform: rotate(225deg)
				}

				100% {
					transform: rotate(225deg)
				}
			}

			@keyframes rotate45 {
				0% {
					transform: rotate(45deg)
				}

				60% {
					transform: rotate(225deg)
				}

				100% {
					transform: rotate(225deg)
				}
			}

			@-webkit-keyframes rotate135 {
				0% {
					transform: rotate(135deg)
				}

				60% {
					transform: rotate(315deg)
				}

				100% {
					transform: rotate(315deg)
				}
			}

			@keyframes rotate135 {
				0% {
					transform: rotate(135deg)
				}

				60% {
					transform: rotate(315deg)
				}

				100% {
					transform: rotate(315deg)
				}
			}

			@-webkit-keyframes loader {
				0% {
					transform: rotate(0deg)
				}

				100% {
					transform: rotate(360deg)
				}
			}

			@keyframes loader {
				0% {
					transform: rotate(0deg)
				}

				100% {
					transform: rotate(360deg)
				}
			}
		</style>
		<div class="loader">
			<div class="side"></div>
			<div class="side"></div>
			<div class="side"></div>
			<div class="side"></div>
			<div class="side"></div>
			<div class="side"></div>
			<div class="side"></div>
			<div class="side"></div>
		</div>
	</div>
	<div class="page-container">
		<style type="text/css">
			h3 {
				font-size: 1.1rem;
				margin-top: 20px
			}

			.contextual-callout p {
				font-size: 13px;
			}

			.contextual-callout {
				background-color: rgba(241, 64, 75, 0.12);
				color: #f1404b !important;
				padding: 15px;
				margin: 10px 0 20px;
				border: 1px solid rgba(241, 64, 75, 0.07);
				border-left-width: 4px;
				border-radius: 3px;
				font-size: 1.3rem;
				line-height: 1.5;
				border-left-color: #f1404b;
			}

			.contextual-callout>h4 {
				margin-bottom: 16px;
				text-align: center;
				font-size: 1rem;
				color: #f1404b
			}

			.link-header h1 {
				font-size: 16px;
				font-size: 1.6rem;
				line-height: 30px;
				text-align: center;
				margin: 0 0 15px 0;
			}

			.link-page {
				margin: 30px 0;
			}
		</style>
		<div id="sidebar" class="sticky sidebar-nav fade mini-sidebar" style="width: 60px;">
			<div class="modal-dialog h-100  sidebar-nav-inner">
				<div class="sidebar-logo border-bottom border-color">
					<!-- logo -->
					<div class="logo overflow-hidden">
						<a href="index.html" class="logo-expanded">
							<img src="assets/images/ywdh-logo-1.png" height="40" class="logo-light" alt="一为导航">
							<img src="assets/images/ywdh-logo.png" height="40" class="logo-dark d-none" alt="一为导航">
						</a>
						<a href="index.html" class="logo-collapsed">
							<img src="assets/images/ywdh-logo-bark-ico.png" height="40" class="logo-light" alt="一为导航">
							<img src="assets/images/ywdh-logo-ico.png" height="40" class="logo-dark d-none" alt="一为导航">
						</a>
					</div>
					<!-- logo end -->
				</div>
				<div class="sidebar-menu flex-fill">
					<div class="sidebar-scroll">
						<div class="sidebar-menu-inner">
							<ul>
								<li class="sidebar-item top-menu">
									<a href="javascript:;" class="smooth change-href">
										<i class="iconfont icon-category icon-fw icon-lg mr-2"></i>
										<span>站点推荐</span>
										<i class="iconfont icon-arrow-r-m sidebar-more text-sm"></i>
									</a>
									<ul>
										<li id="menu-item-281" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-281"><a href="blog.html">
												<i class="io io-wordpress icon-fw icon-lg mr-2"></i>
												<span>blog</span></a></li>
										<li id="menu-item-284" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-284"><a href="about.html">
												<i class="io io-gonggongku icon-fw icon-lg mr-2"></i>
												<span>关于</span></a>
											<ul class="sub-menu">
												<li id="menu-item-264" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-264"><a href="contribute.html">网站提交</a></li>
												<li id="menu-item-285" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-285"><a href="#">二级菜单样式</a></li>
											</ul>
										</li>
										<li id="menu-item-786" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-786"><a target="_blank" rel="noopener" href="javascript:;">
												<i class="io io-change icon-fw icon-lg mr-2"></i>
												<span>更新日志</span></a></li>
										<li id="menu-item-286" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-286"><a target="_blank" rel="noopener" href="javascript:;">
												<i class="io io-huangguan icon-fw icon-lg mr-2"></i>
												<span>获取主题</span></a></li>
									</ul>
								</li>
								<li class="sidebar-item">
									<a href="index.html#term-2" class="smooth">
										<i class="io io-fuwu icon-fw icon-lg mr-2"></i>
										<span>常用推荐</span>
									</a>
								</li>
								<li class="sidebar-item">
									<!--<a href="javascript:;">-->
									<a href="index.html#term-448" class="smooth change-href" data-change="https://nav.iowen.cn/#term-448">
										<i class="io io-zixun icon-fw icon-lg mr-2"></i>
										<span>社区资讯</span>
										<i class="iconfont icon-arrow-r-m sidebar-more text-sm"></i>
									</a>
									<ul>

										<li>
											<a href="index.html#term-39" class="smooth"><span>科技</span></a>
										</li>

										<li>
											<a href="index.html#term-3" class="smooth"><span>社区资讯</span></a>
										</li>
									</ul>
								</li>
								<li class="sidebar-item">
									<a href="index.html#term-98" class="smooth">
										<i class="io io-book icon-fw icon-lg mr-2"></i>
										<span>书籍期刊</span>
									</a>
								</li>
								<li class="sidebar-item">
									<a href="index.html#term-69" class="smooth">
										<i class="io io-app icon-fw icon-lg mr-2"></i>
										<span>软件游戏</span>
									</a>
								</li>
								<li class="sidebar-item">
									<a href="index.html#term-41" class="smooth">
										<i class="io io-yanshi icon-fw icon-lg mr-2"></i>
										<span>用户演示</span>
									</a>
								</li>
								<li class="sidebar-item">
									<!--<a href="javascript:;">-->
									<a href="index.html#term-18" class="smooth change-href" data-change="https://nav.iowen.cn/#term-18">
										<i class="io io-gongju icon-fw icon-lg mr-2"></i>
										<span>常用工具</span>
										<i class="iconfont icon-arrow-r-m sidebar-more text-sm"></i>
									</a>
									<ul>

										<li>
											<a href="index.html#term-22" class="smooth"><span>在线配色</span></a>
										</li>

										<li>
											<a href="index.html#term-24" class="smooth"><span>Chrome插件</span></a>
										</li>

										<li>
											<a href="index.html#term-21" class="smooth"><span>交互动效</span></a>
										</li>

										<li>
											<a href="index.html#term-19" class="smooth"><span>图形创意</span></a>
										</li>

										<li>
											<a href="index.html#term-23" class="smooth"><span>在线工具</span></a>
										</li>

										<li>
											<a href="index.html#term-20" class="smooth"><span>界面设计</span></a>
										</li>
									</ul>
								</li>
								<li class="sidebar-item">
									<!--<a href="javascript:;">-->
									<a href="index.html#term-8" class="smooth change-href" data-change="https://nav.iowen.cn/#term-8">
										<i class="io io-sucai1-copy icon-fw icon-lg mr-2"></i>
										<span>素材资源</span>
										<i class="iconfont icon-arrow-r-m sidebar-more text-sm"></i>
									</a>
									<ul>

										<li>
											<a href="index.html#term-11" class="smooth"><span>平面素材</span></a>
										</li>

										<li>
											<a href="index.html#term-10" class="smooth"><span>LOGO设计</span></a>
										</li>

										<li>
											<a href="index.html#term-15" class="smooth"><span>Mockup</span></a>
										</li>

										<li>
											<a href="index.html#term-17" class="smooth"><span>PPT资源</span></a>
										</li>

										<li>
											<a href="index.html#term-13" class="smooth"><span>Sketch资源</span></a>
										</li>

										<li>
											<a href="index.html#term-9" class="smooth"><span>图标素材</span></a>
										</li>

										<li>
											<a href="index.html#term-12" class="smooth"><span>UI资源</span></a>
										</li>

										<li>
											<a href="index.html#term-14" class="smooth"><span>字体资源</span></a>
										</li>

										<li>
											<a href="index.html#term-16" class="smooth"><span>摄影图库</span></a>
										</li>
									</ul>
								</li>
								<li class="sidebar-item">
									<a href="index.html#term-25" class="smooth">
										<i class="io io-tuandui icon-fw icon-lg mr-2"></i>
										<span>UED团队</span>
									</a>
								</li>
								<li class="sidebar-item">
									<a href="index.html#friendlink" class="smooth">
										<i class="io io-links icon-fw icon-lg mr-2"></i>
										<span>友情链接</span>
									</a>
								</li>

							</ul>
						</div>
					</div>
				</div>
				<div class="border-top py-2 border-color">
					<div class="flex-bottom">
						<ul>
							<li id="menu-item-237" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-237 sidebar-item"><a href="contribute.html">
									<i class="io io-tijiao icon-fw icon-lg mr-2"></i>
									<span>网站提交</span></a></li>
							<li id="menu-item-212" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-212 sidebar-item"><a href="sample-page.html">
									<i class="io io-caozuoshili icon-fw icon-lg mr-2"></i>
									<span>示例页面</span></a></li>
							<li id="menu-item-213" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-213 sidebar-item"><a target="_blank" rel="noopener" href="index1.html">
									<i class="io io-iowen icon-fw icon-lg mr-2"></i>
									<span>一为忆</span></a></li>

						</ul>
					</div>
				</div>
			</div>
		</div>
		<div class="main-content flex-fill">

			<div id="header" class="page-header sticky">
				<div class="navbar navbar-expand-md">
					<div class="container-fluid p-0">

						<a href="index.html" class="navbar-brand d-md-none" title="一为导航">
							<img src="assets/images/ywdh-logo-bark-ico.png" class="logo-light" alt="一为导航">
							<img src="assets/images/ywdh-logo-ico.png" class="logo-dark d-none" alt="一为导航">
						</a>

						<div class="collapse navbar-collapse order-2 order-md-1">
							<div class="header-mini-btn">
								<label>
									<input id="mini-button" type="checkbox">
									<svg viewbox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
										<path class="line--1" d="M0 40h62c18 0 18-20-17 5L31 55"></path>
										<path class="line--2" d="M0 50h80"></path>
										<path class="line--3" d="M0 60h62c18 0 18 20-17-5L31 45"></path>
									</svg>
								</label>

							</div>
							<ul class="navbar-nav site-menu mr-4">
								<li id="menu-item-281" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-281"><a href="blog.html">
										<i class="io io-wordpress icon-fw icon-lg mr-2"></i>
										<span>blog</span></a></li>
								<li id="menu-item-284" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-284"><a href="about.html">
										<i class="io io-gonggongku icon-fw icon-lg mr-2"></i>
										<span>关于</span></a>
									<ul class="sub-menu">
										<li id="menu-item-264" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-264"><a href="contribute.html">网站提交</a></li>
										<li id="menu-item-285" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-285"><a href="#">二级菜单样式</a></li>
									</ul>
								</li>
								<li id="menu-item-786" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-786"><a target="_blank" rel="noopener" href="javascript:;">
										<i class="io io-change icon-fw icon-lg mr-2"></i>
										<span>更新日志</span></a></li>
								<li id="menu-item-286" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-286"><a target="_blank" rel="noopener" href="javascript:;">
										<i class="io io-huangguan icon-fw icon-lg mr-2"></i>
										<span>获取主题</span></a></li>

							</ul>
						</div>

						<ul class="nav navbar-menu text-xs order-1 order-md-2">
							<!-- 一言 -->
							<li class="nav-item mr-3 mr-lg-0 d-none d-lg-block">
								<div class="text-sm overflowClip_1">
									<script src="https://www.iowen.cn/jitang/api/?format=js"></script>
									<a href=" jitang/index.html" target="_blank" rel="external nofollow"><span id="hitokoto">
											<script>
												hitokoto()
											</script>
										</span></a>
								</div>
							</li>
							<!-- 一言 end -->
							<li class="nav-login ml-3 ml-md-4">
								<a href="login/index.html" title="登录"><i class="iconfont icon-user icon-2x"></i></a>
							</li>
							<li class="nav-search ml-3 ml-md-4">
								<a href="javascript:" data-toggle="modal" data-target="#search-modal"><i class="iconfont icon-search icon-2x"></i></a>
							</li>
							<li class="nav-item d-md-none mobile-menu ml-3 ml-md-4">
								<a href="javascript:" id="sidebar-switch" data-toggle="modal" data-target="#sidebar"><i class="iconfont icon-classification icon-2x"></i></a>
							</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="placeholder" style="height:74px"></div>
			<div id="content" class="container my-4 my-md-5">
				<div class="content-area">
					<main class="site-main">
						<article id="post-507" class="type-post post">
							<h1 class="h2 mb-4">Links</h1>
							<div class="content page">
								<div class="single-content">
									<h3>一、申请友链可以直接在本页面留言，内容包括网站名称、链接以及相关说明，为了节约你我的时间，可先做好本站链接并此处留言，我将尽快答复</h3>
									<h3>二、欢迎申请友情链接，只要是正规站常更新即可，申请首页链接需符合以下几点要求：</h3>
									<ul>
										<li>本站优先招同类原创、内容相近的博客或网站；</li>
										<li>Baidu和Google有正常收录，百度近期快照，不含有违法国家法律内容的合法网站，TB客，垃圾站不做。</li>
										<li>如果您的站原创内容少之又少，且长期不更新，申请连接不予受理！</li>
										<li>友情链接的目的是常来常往，凡是加了友链的朋友，我都会经常访问的，也欢迎你来我的网站参观、留言等。</li>
									</ul>
									<p>长期不更新的会视情节把友链转移至内页。</p>
									<div class="contextual-callout">
										<h4>友链申请示例</h4>
										<p>本站名称：一为导航<br>
											本站链接：https://nav.iowen.cn<br>
											本站描述：设计师网址导航</p>
									</div>
									<p>PS:链接由于无法访问或您的博客没有发现本站链接等其他原因，将会暂时撤销超链接，恢复请留言通知我，望请谅解，谢谢！</p>
								</div> <!-- .single-content -->
								<article class="link-page">

									<div class="row">
										<div class="url-card col-6 col-md-3">
											<div class="card url-body default">
												<div class="card-body">
													<div class="url-content d-flex align-items-center">
														<div class="url-img rounded-circle mr-2 d-flex align-items-center justify-content-center">
															<img class="lazy" src="assets/images/favicon.png" data-src="favicon/www.iowen.cn.png" onerror="javascript:this.src='https://nav.iowen.cn/assets/images/favicon.png'">
														</div>
														<div class="url-info flex-fill">
															<div class="text-sm overflowClip_1">
																<a href="index1.html" title="一为忆" target="_blank"><strong>一为忆</strong></a>
															</div>
															<p class="overflowClip_1 m-0 text-xs">分享资源分享精品内容</p>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="url-card col-6 col-md-3">
											<div class="card url-body default">
												<div class="card-body">
													<div class="url-content d-flex align-items-center">
														<div class="url-img rounded-circle mr-2 d-flex align-items-center justify-content-center">
															<img class="lazy" src="assets/images/favicon.png" data-src="favicon/www.c575.com.png" onerror="javascript:this.src='https://nav.iowen.cn/assets/images/favicon.png'">
														</div>
														<div class="url-info flex-fill">
															<div class="text-sm overflowClip_1">
																<a href="javascript:;" title="绍兴C网" target="_blank"><strong>绍兴C网</strong></a>
															</div>
															<p class="overflowClip_1 m-0 text-xs">绿色纯净的个性网址导航便签</p>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="url-card col-6 col-md-3">
											<div class="card url-body default">
												<div class="card-body">
													<div class="url-content d-flex align-items-center">
														<div class="url-img rounded-circle mr-2 d-flex align-items-center justify-content-center">
															<img class="lazy" src="assets/images/favicon.png" data-src="favicon/www.24kdh.com.png" onerror="javascript:this.src='https://nav.iowen.cn/assets/images/favicon.png'">
														</div>
														<div class="url-info flex-fill">
															<div class="text-sm overflowClip_1">
																<a href="javascript:;" title="24k导航" target="_blank"><strong>24k导航</strong></a>
															</div>
															<p class="overflowClip_1 m-0 text-xs">专注全网优质网址、优质资源分享。</p>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="url-card col-6 col-md-3">
											<div class="card url-body default">
												<div class="card-body">
													<div class="url-content d-flex align-items-center">
														<div class="url-img rounded-circle mr-2 d-flex align-items-center justify-content-center">
															<img class="lazy" src="assets/images/favicon.png" data-src="https://api.iowen.cn/favicon/xiaok.xxem.vip.png" onerror="javascript:this.src='https://nav.iowen.cn/assets/images/favicon.png'">
														</div>
														<div class="url-info flex-fill">
															<div class="text-sm overflowClip_1">
																<a href="javascript:;" title="砖块网址导航" target="_blank"><strong>砖块网址导航</strong></a>
															</div>
															<p class="overflowClip_1 m-0 text-xs"></p>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="url-card col-6 col-md-3">
											<div class="card url-body default">
												<div class="card-body">
													<div class="url-content d-flex align-items-center">
														<div class="url-img rounded-circle mr-2 d-flex align-items-center justify-content-center">
															<img class="lazy" src="assets/images/favicon.png" data-src="favicon/chinaword.press.png" onerror="javascript:this.src='https://nav.iowen.cn/assets/images/favicon.png'">
														</div>
														<div class="url-info flex-fill">
															<div class="text-sm overflowClip_1">
																<a href="javascript:;" title="WordPress中文导航" target="_blank"><strong>WordPress中文导航</strong></a>
															</div>
															<p class="overflowClip_1 m-0 text-xs"></p>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="url-card col-6 col-md-3">
											<div class="card url-body default">
												<div class="card-body">
													<div class="url-content d-flex align-items-center">
														<div class="url-img rounded-circle mr-2 d-flex align-items-center justify-content-center">
															<img class="lazy" src="assets/images/favicon.png" data-src="favicon/n6app.com.png" onerror="javascript:this.src='https://nav.iowen.cn/assets/images/favicon.png'">
														</div>
														<div class="url-info flex-fill">
															<div class="text-sm overflowClip_1">
																<a href="javascript:;" title="牛六网" target="_blank"><strong>牛六网</strong></a>
															</div>
															<p class="overflowClip_1 m-0 text-xs">收集国内外优秀网站、UI设计资源网站、在线电影、迅雷BT磁力下载网站、素材资源网站，绿色版APP软件,定时更新分享优质网站。</p>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="url-card col-6 col-md-3">
											<div class="card url-body default">
												<div class="card-body">
													<div class="url-content d-flex align-items-center">
														<div class="url-img rounded-circle mr-2 d-flex align-items-center justify-content-center">
															<img class="lazy" src="assets/images/favicon.png" data-src="favicon/www.info35.com.png" onerror="javascript:this.src='https://nav.iowen.cn/assets/images/favicon.png'">
														</div>
														<div class="url-info flex-fill">
															<div class="text-sm overflowClip_1">
																<a href="javascript:;" title="商娱网" target="_blank"><strong>商娱网</strong></a>
															</div>
															<p class="overflowClip_1 m-0 text-xs">魅力商娱网，有你更精彩！</p>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="url-card col-6 col-md-3">
											<div class="card url-body default">
												<div class="card-body">
													<div class="url-content d-flex align-items-center">
														<div class="url-img rounded-circle mr-2 d-flex align-items-center justify-content-center">
															<img class="lazy" src="assets/images/favicon.png" data-src="favicon/bks.thefuture.top.png" onerror="javascript:this.src='https://nav.iowen.cn/assets/images/favicon.png'">
														</div>
														<div class="url-info flex-fill">
															<div class="text-sm overflowClip_1">
																<a href="javascript:;" title="印花设计导航" target="_blank"><strong>印花设计导航</strong></a>
															</div>
															<p class="overflowClip_1 m-0 text-xs">设计师网址导航</p>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="url-card col-6 col-md-3">
											<div class="card url-body default">
												<div class="card-body">
													<div class="url-content d-flex align-items-center">
														<div class="url-img rounded-circle mr-2 d-flex align-items-center justify-content-center">
															<img class="lazy" src="assets/images/favicon.png" data-src="favicon/bks.thefuture.top.png" onerror="javascript:this.src='https://nav.iowen.cn/assets/images/favicon.png'">
														</div>
														<div class="url-info flex-fill">
															<div class="text-sm overflowClip_1">
																<a href="javascript:;" title="妥妥的看剧" target="_blank"><strong>妥妥的看剧</strong></a>
															</div>
															<p class="overflowClip_1 m-0 text-xs">高清电影电视剧下载</p>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="url-card col-6 col-md-3">
											<div class="card url-body default">
												<div class="card-body">
													<div class="url-content d-flex align-items-center">
														<div class="url-img rounded-circle mr-2 d-flex align-items-center justify-content-center">
															<img class="lazy" src="assets/images/favicon.png" data-src="https://api.iowen.cn/favicon/www.onebooks.cn.png" onerror="javascript:this.src='https://nav.iowen.cn/assets/images/favicon.png'">
														</div>
														<div class="url-info flex-fill">
															<div class="text-sm overflowClip_1">
																<a href="javascript:;" title="壹书" target="_blank"><strong>壹书</strong></a>
															</div>
															<p class="overflowClip_1 m-0 text-xs">壹书壹语·感世间百态。</p>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="url-card col-6 col-md-3">
											<div class="card url-body default">
												<div class="card-body">
													<div class="url-content d-flex align-items-center">
														<div class="url-img rounded-circle mr-2 d-flex align-items-center justify-content-center">
															<img class="lazy" src="assets/images/favicon.png" data-src="favicon/www.hifast.cn.png" onerror="javascript:this.src='https://nav.iowen.cn/assets/images/favicon.png'">
														</div>
														<div class="url-info flex-fill">
															<div class="text-sm overflowClip_1">
																<a href="javascript:;" title="快导航网" target="_blank"><strong>快导航网</strong></a>
															</div>
															<p class="overflowClip_1 m-0 text-xs">站在前方,为你导航_技术导航网_滚石技术导航_网址导航大全</p>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="url-card col-6 col-md-3">
											<div class="card url-body default">
												<div class="card-body">
													<div class="url-content d-flex align-items-center">
														<div class="url-img rounded-circle mr-2 d-flex align-items-center justify-content-center">
															<img class="lazy" src="assets/images/favicon.png" data-src="favicon/nav.hzwdd.cn.png" onerror="javascript:this.src='https://nav.iowen.cn/assets/images/favicon.png'">
														</div>
														<div class="url-info flex-fill">
															<div class="text-sm overflowClip_1">
																<a href="javascript:;" title="西瓜导航" target="_blank"><strong>西瓜导航</strong></a>
															</div>
															<p class="overflowClip_1 m-0 text-xs">收藏各种好玩有趣的网站</p>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="url-card col-6 col-md-3">
											<div class="card url-body default">
												<div class="card-body">
													<div class="url-content d-flex align-items-center">
														<div class="url-img rounded-circle mr-2 d-flex align-items-center justify-content-center">
															<img class="lazy" src="assets/images/favicon.png" data-src="favicon/www.8kmm.com.png" onerror="javascript:this.src='https://nav.iowen.cn/assets/images/favicon.png'">
														</div>
														<div class="url-info flex-fill">
															<div class="text-sm overflowClip_1">
																<a href="javascript:;" title="八千导航" target="_blank"><strong>八千导航</strong></a>
															</div>
															<p class="overflowClip_1 m-0 text-xs">八千导航</p>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="url-card col-6 col-md-3">
											<div class="card url-body default">
												<div class="card-body">
													<div class="url-content d-flex align-items-center">
														<div class="url-img rounded-circle mr-2 d-flex align-items-center justify-content-center">
															<img class="lazy" src="assets/images/favicon.png" data-src="favicon/www.aboutppt.com.png" onerror="javascript:this.src='https://nav.iowen.cn/assets/images/favicon.png'">
														</div>
														<div class="url-info flex-fill">
															<div class="text-sm overflowClip_1">
																<a href="javascript:;" title="AboutPPT导航" target="_blank"><strong>AboutPPT导航</strong></a>
															</div>
															<p class="overflowClip_1 m-0 text-xs">PPT演示设计网址导航</p>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="url-card col-6 col-md-3">
											<div class="card url-body default">
												<div class="card-body">
													<div class="url-content d-flex align-items-center">
														<div class="url-img rounded-circle mr-2 d-flex align-items-center justify-content-center">
															<img class="lazy" src="assets/images/favicon.png" data-src="favicon/xiaojun.space.png" onerror="javascript:this.src='https://nav.iowen.cn/assets/images/favicon.png'">
														</div>
														<div class="url-info flex-fill">
															<div class="text-sm overflowClip_1">
																<a href="javascript:;" title="小菌你好" target="_blank"><strong>小菌你好</strong></a>
															</div>
															<p class="overflowClip_1 m-0 text-xs">小菌你好，一个玩机分享导航平台。</p>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="clear"></div>
								</article>
							</div><!-- .content -->
						</article><!-- #page -->

						<!-- comments -->
						<div class="post-apd mt-4">
							<script async="" src="pagead/js/adsbygoogle.js"></script>
							<ins class="adsbygoogle" style="display:block" data-ad-format="autorelaxed" data-ad-client="ca-pub-3126850295060981" data-ad-slot="3117450257"></ins>
							<script>
								(adsbygoogle = window.adsbygoogle || []).push({});
							</script>
						</div>
						<div id="comments" class="comments">
							<h1 id="comments-list-title" class="comments-title h5 mx-1 my-4">
								<i class="iconfont icon-comment"></i>
								<span class="noticom">
									<a href="#comments" class="comments-title">4 条评论</a>
								</span>
							</h1>
							<div class="card">
								<div class="card-body">
									<div id="respond_box">
										<div id="respond" class="comment-respond">
											<form action="https://nav.iowen.cn/wp-comments-post.php" method="post" id="commentform" class="text-sm mb-4">
												<div class="visitor-avatar d-flex flex-fill mb-2">
													<img class="v-avatar rounded-circle" src="assets/images/gravatar.jpg">
												</div>
												<div class="comment-textarea mb-3">
													<textarea name="comment" id="comment" class="form-control" placeholder="输入评论内容..." tabindex="4" cols="50" rows="3"></textarea>
												</div>

												<div id="comment-author-info" class="row  row-sm">
													<div class="col-sm-6 col-lg-4 mb-3"><input type="text" name="author" id="author" class="form-control" value="" size="22" placeholder="昵称" tabindex="2"></div>
													<div class="col-sm-6 col-lg-4 mb-3"><input type="text" name="email" id="email" class="form-control" value="" size="22" placeholder="邮箱" tabindex="3"></div>
													<div class="col-sm-12 col-lg-4 mb-3"><input type="text" name="url" id="url" class="form-control" value="" size="22" placeholder="网址" tabindex="4"></div>
												</div>
												<div class="com-footer text-right">
													<input type="hidden" id="_wpnonce" name="_wpnonce" value="c1b2a2e393"><input type="hidden" name="_wp_http_referer" value="/links"> <a rel="nofollow" id="cancel-comment-reply-link" style="display: none;" href="javascript:;" class="btn btn-light custom_btn-outline mx-2">再想想</a>
													<input class="btn btn-dark custom_btn-d" name="submit" type="button" id="TencentCaptcha" tabindex="5" value="发表评论" data-appid="2095453596" data-cbfn="commentsTicket">
													<input type='hidden' name='comment_post_ID' value='507' id='comment_post_ID'>
													<input type='hidden' name='comment_parent' id='comment_parent' value='0'>
												</div>
											</form>
											<script type="text/javascript">
												window.commentsTicket = function(res) {
													if (res.ret === 0) {
														$.ajax({
															url: "https://nav.iowen.cn/wp-admin/admin-ajax.php",
															data: "ticket=" + res.ticket + "&randstr=" + res.randstr + "&action=io_007_validate",
															type: "POST",
															dataType: "json",
														}).done(function(response) {
															if (response.result) {
																$("#commentform").submit();
															} else {
																showAlert(JSON.parse('{"status":3,"msg":"' + response.message + '"}'));
															}
														}).fail(function() {
															showAlert(JSON.parse('{"status":4,"msg":"网络错误！"}'));
														})
													} else if (res.ret === 2) {
														showAlert(JSON.parse('{"status":3,"msg":"你没有完成验证！"}'));
													}
												}
											</script>
											<div class="clear"></div>
										</div>
									</div>
									<div id="loading-comments"><span></span></div>
									<ul class="comment-list">
										<li class="comment even thread-even depth-1 comment" id="li-comment-106">
											<div id="comment-106" class="comment_body d-flex flex-fill">
												<div class="profile mr-2 mr-md-3">
													<img alt='湘伦' src='avatar/81fd3c6a2644d897f534a5bd0ad05718.jpg' srcset='https://sdn.geekzu.org/avatar/81fd3c6a2644d897f534a5bd0ad05718?s=192&d=retro&r=g 2x' class='avatar avatar-96 photo' height='96' width='96' loading='lazy'>
												</div>
												<section class="comment-text d-flex flex-fill flex-column">
													<div class="comment-info d-flex align-items-center mb-1">
														<div class="comment-author text-sm w-100"><a href='javascript:;' target='_blank' rel='nofollow noopener noreferrer' class='url'>湘伦</a> <span class="rank" title="头衔：游客">游客</span> </div>
													</div>
													<div class="comment-content d-inline-block text-sm">
														<p>本站名称：印花设计导航<br>
															本站链接：ps2020.cc<br>
															本站描述：设计师网址导航</p>

													</div>
													<div class="d-flex flex-fill text-xs text-muted pt-2">
														<div class="comment-meta">
															<div class="info"><time itemprop="datePublished" datetime="2020-04-04T20:25:25+08:00">12个月前</time></div>
														</div>
														<div class="flex-fill"></div>
														<a rel='nofollow' class='comment-reply-link' href='javascript:;' data-commentid="106" data-postid="507" data-belowelement="comment-106" data-respondelement="respond" data-replyto="回复给湘伦" aria-label='回复给湘伦'>回复</a>
													</div>
												</section>
											</div>
											<ul class="children">
												<li class="comment byuser bypostauthor odd alt depth-2 comment" id="li-comment-108">
													<div id="comment-108" class="comment_body d-flex flex-fill">
														<div class="profile mr-2 mr-md-3">
															<img alt='一为' src='wp-content/uploads/avatars/1-1615826147.jpg' class=' avatar avatar-96 photo' height='96' width='96'>
														</div>
														<section class="comment-text d-flex flex-fill flex-column">
															<div class="comment-info d-flex align-items-center mb-1">
																<div class="comment-author text-sm w-100"><a href='javascript:;' target='_blank' rel='nofollow noopener noreferrer' class='url'>一为</a> <span class="is-author" data-toggle="tooltip" data-placement="right" title="博主"><i class="iconfont icon-user icon-fw"></i></span> </div>
															</div>
															<div class="comment-content d-inline-block text-sm">
																<p>好的 加了</p>

															</div>
															<div class="d-flex flex-fill text-xs text-muted pt-2">
																<div class="comment-meta">
																	<div class="info"><time itemprop="datePublished" datetime="2020-04-05T21:07:08+08:00">12个月前</time></div>
																</div>
																<div class="flex-fill"></div>
																<a rel='nofollow' class='comment-reply-link' href='javascript:;' data-commentid="108" data-postid="507" data-belowelement="comment-108" data-respondelement="respond" data-replyto="回复给一为" aria-label='回复给一为'>回复</a>
															</div>
														</section>
													</div>
												</li><!-- #comment-## -->
											</ul><!-- .children -->
										</li><!-- #comment-## -->
										<li class="comment even thread-odd thread-alt depth-1 comment" id="li-comment-113">
											<div id="comment-113" class="comment_body d-flex flex-fill">
												<div class="profile mr-2 mr-md-3">
													<img alt='虚像' src='avatar/1dc2fb7945dd0aea3ae96377f2773c1e.jpg' srcset='https://sdn.geekzu.org/avatar/1dc2fb7945dd0aea3ae96377f2773c1e?s=192&d=retro&r=g 2x' class='avatar avatar-96 photo' height='96' width='96' loading='lazy'>
												</div>
												<section class="comment-text d-flex flex-fill flex-column">
													<div class="comment-info d-flex align-items-center mb-1">
														<div class="comment-author text-sm w-100"><a href='javascript:;' target='_blank' rel='nofollow noopener noreferrer' class='url'>虚像</a> <span class="rank" title="头衔：游客">游客</span> </div>
													</div>
													<div class="comment-content d-inline-block text-sm">
														<p>本站名称:快导航网<br>
															本站链接:www点hifast点cn<br>
															本站描述:站在前方，为你导航</p>

													</div>
													<div class="d-flex flex-fill text-xs text-muted pt-2">
														<div class="comment-meta">
															<div class="info"><time itemprop="datePublished" datetime="2020-05-18T00:33:50+08:00">11个月前</time></div>
														</div>
														<div class="flex-fill"></div>
														<a rel='nofollow' class='comment-reply-link' href='javascript:;' data-commentid="113" data-postid="507" data-belowelement="comment-113" data-respondelement="respond" data-replyto="回复给虚像" aria-label='回复给虚像'>回复</a>
													</div>
												</section>
											</div>
										</li><!-- #comment-## -->
										<li class="comment odd alt thread-even depth-1 comment" id="li-comment-158">
											<div id="comment-158" class="comment_body d-flex flex-fill">
												<div class="profile mr-2 mr-md-3">
													<img alt='菌' src='avatar/7e35d248c0d339aa812536c5c662fe9f.jpg' srcset='https://sdn.geekzu.org/avatar/7e35d248c0d339aa812536c5c662fe9f?s=192&d=retro&r=g 2x' class='avatar avatar-96 photo' height='96' width='96' loading='lazy'>
												</div>
												<section class="comment-text d-flex flex-fill flex-column">
													<div class="comment-info d-flex align-items-center mb-1">
														<div class="comment-author text-sm w-100"><a href='javascript:;' target='_blank' rel='nofollow noopener noreferrer' class='url'>菌</a> <span class="rank" title="头衔：游客">游客</span> </div>
													</div>
													<div class="comment-content d-inline-block text-sm">
														<p>本站名称：小菌你好<br>
															本站链接：xiaojun.space<br>
															本站描述：小菌你好，一个玩机分享导航平台。</p>

													</div>
													<div class="d-flex flex-fill text-xs text-muted pt-2">
														<div class="comment-meta">
															<div class="info"><time itemprop="datePublished" datetime="2021-03-13T19:37:35+08:00">2周前</time></div>
														</div>
														<div class="flex-fill"></div>
														<a rel='nofollow' class='comment-reply-link' href='javascript:;' data-commentid="158" data-postid="507" data-belowelement="comment-158" data-respondelement="respond" data-replyto="回复给菌" aria-label='回复给菌'>回复</a>
													</div>
												</section>
											</div>
										</li><!-- #comment-## -->

									</ul>

								</div>
							</div>
						</div>
						<!-- comments end -->
					</main>
				</div>
			</div>


			<footer class="main-footer footer-type-1 text-xs">
				<div id="footer-tools" class="d-flex flex-column">
					<a href="javascript:" id="go-to-up" class="btn rounded-circle go-up m-1" rel="go-top">
						<i class="iconfont icon-to-up"></i>
					</a>
					<!-- 天气  -->
					<div class="btn rounded-circle weather m-1">
						<div id="he-plugin-simple" style="display: contents;"></div>
						<script>
							WIDGET = {
								CONFIG: {
									"modules": "02",
									"background": 5,
									"tmpColor": "888",
									"tmpSize": 14,
									"cityColor": "888",
									"citySize": 14,
									"aqiSize": 14,
									"weatherIconSize": 24,
									"alertIconSize": 18,
									"padding": "7px 2px 7px 2px",
									"shadow": "1",
									"language": "auto",
									"borderRadius": 5,
									"fixed": "false",
									"vertical": "middle",
									"horizontal": "left",
									"key": "a922adf8928b4ac1ae7a31ae7375e191"
								}
							}
						</script>
						<script src="assets/js/he-simple-common-1.1.js"></script>
					</div>
					<!-- 天气 end -->
					<a href="javascript:" id="switch-mode" class="btn rounded-circle switch-dark-mode m-1" data-toggle="tooltip" data-placement="left" title="夜间模式">
						<i class="mode-ico iconfont icon-light"></i>
					</a>
				</div>
				<div class="footer-inner">
					<div class="footer-text">
						Copyright © 2021 一为导航 &nbsp;&nbsp;Design by <a href="index1.html" target="_blank"><strong>一为</strong></a>&nbsp;&nbsp; </div>
				</div>
			</footer>
		</div><!-- main-content end -->
	</div><!-- page-container end -->

	<div class="modal fade search-modal" id="search-modal">
		<div class="modal-dialog modal-lg modal-dialog-centered">
			<div class="modal-content">
				<div class="modal-body">

					<div id="search" class="s-search mx-auto my-4">
						<div id="search-list" class="hide-type-list">
							<div class="s-type">
								<span></span>
								<div class="s-type-list">
									<label for="m_type-baidu" data-id="group-a">常用</label><label for="m_type-baidu1" data-id="group-b">搜索</label><label for="m_type-br" data-id="group-c">工具</label><label for="m_type-zhihu" data-id="group-d">社区</label><label for="m_type-taobao1" data-id="group-e">生活</label><label for="m_type-zhaopin" data-id="group-f">求职</label>
								</div>
							</div>
							<div class="search-group group-a"><span class="type-text text-muted">常用</span>
								<ul class="search-type">
									<li><input checked="checked" hidden="" type="radio" name="type2" id="m_type-baidu" value="https://www.baidu.com/s?wd=" data-placeholder="百度一下"><label for="m_type-baidu"><span class="text-muted">百度</span></label></li>
									<li><input hidden="" type="radio" name="type2" id="m_type-google" value="https://www.google.com/search?q=" data-placeholder="谷歌两下"><label for="m_type-google"><span class="text-muted">Google</span></label></li>
									<li><input hidden="" type="radio" name="type2" id="m_type-zhannei" value="https://nav.iowen.cn/?post_type=sites&s=" data-placeholder="站内搜索"><label for="m_type-zhannei"><span class="text-muted">站内</span></label></li>
									<li><input hidden="" type="radio" name="type2" id="m_type-taobao" value="https://s.taobao.com/search?q=" data-placeholder="淘宝"><label for="m_type-taobao"><span class="text-muted">淘宝</span></label></li>
									<li><input hidden="" type="radio" name="type2" id="m_type-bing" value="https://cn.bing.com/search?q=" data-placeholder="微软Bing搜索"><label for="m_type-bing"><span class="text-muted">Bing</span></label></li>
								</ul>
							</div>
							<div class="search-group group-b"><span class="type-text text-muted">搜索</span>
								<ul class="search-type">
									<li><input hidden="" type="radio" name="type2" id="m_type-baidu1" value="https://www.baidu.com/s?wd=" data-placeholder="百度一下"><label for="m_type-baidu1"><span class="text-muted">百度</span></label></li>
									<li><input hidden="" type="radio" name="type2" id="m_type-google1" value="https://www.google.com/search?q=" data-placeholder="谷歌两下"><label for="m_type-google1"><span class="text-muted">Google</span></label></li>
									<li><input hidden="" type="radio" name="type2" id="m_type-360" value="https://www.so.com/s?q=" data-placeholder="360好搜"><label for="m_type-360"><span class="text-muted">360</span></label></li>
									<li><input hidden="" type="radio" name="type2" id="m_type-sogo" value="https://www.sogou.com/web?query=" data-placeholder="搜狗搜索"><label for="m_type-sogo"><span class="text-muted">搜狗</span></label></li>
									<li><input hidden="" type="radio" name="type2" id="m_type-bing1" value="https://cn.bing.com/search?q=" data-placeholder="微软Bing搜索"><label for="m_type-bing1"><span class="text-muted">Bing</span></label></li>
									<li><input hidden="" type="radio" name="type2" id="m_type-sm" value="https://yz.m.sm.cn/s?q=" data-placeholder="UC移动端搜索"><label for="m_type-sm"><span class="text-muted">神马</span></label></li>
								</ul>
							</div>
							<div class="search-group group-c"><span class="type-text text-muted">工具</span>
								<ul class="search-type">
									<li><input hidden="" type="radio" name="type2" id="m_type-br" value="https://rank.chinaz.com/all/" data-placeholder="请输入网址(不带https://)"><label for="m_type-br"><span class="text-muted">权重查询</span></label></li>
									<li><input hidden="" type="radio" name="type2" id="m_type-links" value="https://link.chinaz.com/" data-placeholder="请输入网址(不带https://)"><label for="m_type-links"><span class="text-muted">友链检测</span></label></li>
									<li><input hidden="" type="radio" name="type2" id="m_type-icp" value="https://icp.aizhan.com/" data-placeholder="请输入网址(不带https://)"><label for="m_type-icp"><span class="text-muted">备案查询</span></label></li>
									<li><input hidden="" type="radio" name="type2" id="m_type-ping" value="https://ping.chinaz.com/" data-placeholder="请输入网址(不带https://)"><label for="m_type-ping"><span class="text-muted">PING检测</span></label></li>
									<li><input hidden="" type="radio" name="type2" id="m_type-404" value="https://tool.chinaz.com/Links/?DAddress=" data-placeholder="请输入网址(不带https://)"><label for="m_type-404"><span class="text-muted">死链检测</span></label></li>
									<li><input hidden="" type="radio" name="type2" id="m_type-ciku" value="https://www.ciku5.com/s?wd=" data-placeholder="请输入关键词"><label for="m_type-ciku"><span class="text-muted">关键词挖掘</span></label></li>
								</ul>
							</div>
							<div class="search-group group-d"><span class="type-text text-muted">社区</span>
								<ul class="search-type">
									<li><input hidden="" type="radio" name="type2" id="m_type-zhihu" value="https://www.zhihu.com/search?type=content&q=" data-placeholder="知乎"><label for="m_type-zhihu"><span class="text-muted">知乎</span></label></li>
									<li><input hidden="" type="radio" name="type2" id="m_type-wechat" value="https://weixin.sogou.com/weixin?type=2&query=" data-placeholder="微信"><label for="m_type-wechat"><span class="text-muted">微信</span></label></li>
									<li><input hidden="" type="radio" name="type2" id="m_type-weibo" value="https://s.weibo.com/weibo/" data-placeholder="微博"><label for="m_type-weibo"><span class="text-muted">微博</span></label></li>
									<li><input hidden="" type="radio" name="type2" id="m_type-douban" value="https://www.douban.com/search?q=" data-placeholder="豆瓣"><label for="m_type-douban"><span class="text-muted">豆瓣</span></label></li>
									<li><input hidden="" type="radio" name="type2" id="m_type-why" value="https://ask.seowhy.com/search/?q=" data-placeholder="SEO问答社区"><label for="m_type-why"><span class="text-muted">搜外问答</span></label></li>
								</ul>
							</div>
							<div class="search-group group-e"><span class="type-text text-muted">生活</span>
								<ul class="search-type">
									<li><input hidden="" type="radio" name="type2" id="m_type-taobao1" value="https://s.taobao.com/search?q=" data-placeholder="淘宝"><label for="m_type-taobao1"><span class="text-muted">淘宝</span></label></li>
									<li><input hidden="" type="radio" name="type2" id="m_type-jd" value="https://search.jd.com/Search?keyword=" data-placeholder="京东"><label for="m_type-jd"><span class="text-muted">京东</span></label></li>
									<li><input hidden="" type="radio" name="type2" id="m_type-xiachufang" value="https://www.xiachufang.com/search/?keyword=" data-placeholder="下厨房"><label for="m_type-xiachufang"><span class="text-muted">下厨房</span></label></li>
									<li><input hidden="" type="radio" name="type2" id="m_type-xiangha" value="https://www.xiangha.com/so/?q=caipu&s=" data-placeholder="香哈菜谱"><label for="m_type-xiangha"><span class="text-muted">香哈菜谱</span></label></li>
									<li><input hidden="" type="radio" name="type2" id="m_type-12306" value="https://www.12306.cn/?" data-placeholder="12306"><label for="m_type-12306"><span class="text-muted">12306</span></label></li>
									<li><input hidden="" type="radio" name="type2" id="m_type-kd100" value="https://www.kuaidi100.com/?" data-placeholder="快递100"><label for="m_type-kd100"><span class="text-muted">快递100</span></label></li>
									<li><input hidden="" type="radio" name="type2" id="m_type-qunar" value="https://www.qunar.com/?" data-placeholder="去哪儿"><label for="m_type-qunar"><span class="text-muted">去哪儿</span></label></li>
								</ul>
							</div>
							<div class="search-group group-f"><span class="type-text text-muted">求职</span>
								<ul class="search-type">
									<li><input hidden="" type="radio" name="type2" id="m_type-zhaopin" value="https://sou.zhaopin.com/jobs/searchresult.ashx?kw=" data-placeholder="智联招聘"><label for="m_type-zhaopin"><span class="text-muted">智联招聘</span></label></li>
									<li><input hidden="" type="radio" name="type2" id="m_type-51job" value="https://search.51job.com/?" data-placeholder="前程无忧"><label for="m_type-51job"><span class="text-muted">前程无忧</span></label></li>
									<li><input hidden="" type="radio" name="type2" id="m_type-lagou" value="https://www.lagou.com/jobs/list_" data-placeholder="拉钩网"><label for="m_type-lagou"><span class="text-muted">拉钩网</span></label></li>
									<li><input hidden="" type="radio" name="type2" id="m_type-liepin" value="https://www.liepin.com/zhaopin/?key=" data-placeholder="猎聘网"><label for="m_type-liepin"><span class="text-muted">猎聘网</span></label></li>
								</ul>
							</div>
						</div>
						<form action="https://nav.iowen.cn?s=" method="get" target="_blank" class="super-search-fm">
							<input type="text" id="m_search-text" class="form-control smart-tips search-key" zhannei="" autocomplete="off" placeholder="输入关键字搜索" style="outline:0">
							<button type="submit"><i class="iconfont icon-search"></i></button>
						</form>
						<div class="card search-smart-tips" style="display: none">
							<ul></ul>
						</div>
					</div>

					<div class="px-1 mb-3"><i class="text-xl iconfont icon-hot mr-1" style="color:#f1404b;"></i><span class="h6">热门推荐： </span></div>
					<div class="mb-3">
						<li id="menu-item-332" class="menu-item menu-item-type-taxonomy menu-item-object-post_tag menu-item-332"><a href="tag/黑洞.html">黑洞</a></li>
						<li id="menu-item-333" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-333"><a href="E5AFBCE888AAE4B8BBE9A298.html">导航主题</a></li>
						<li id="menu-item-335" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-335"><a href="E59BBEE6A087.html">图标</a></li>
					</div>
				</div>
				<div style="position: absolute;bottom: -40px;width: 100%;text-align: center;"><a href="javascript:" data-dismiss="modal"><i class="iconfont icon-close-circle icon-2x" style="color: #fff;"></i></a></div>
			</div>
		</div>
	</div>
	<script type='text/javascript' src='<?= $this->cdn('jqueryui/1.12.1/jquery-ui.min.js') ?>' id='jquery-ui-js'></script>
	<script type='text/javascript' src='assets/js/jquery.ui.touch-punch.min.js' id='jqueryui-touch-js'></script>
	<script type='text/javascript' src='assets/js//clipboard.min-5.6.2.js' id='clipboard-js'></script>
	<script type='text/javascript' id='popper-js-extra'>
		/* <![CDATA[ */
		var theme = {
			"ajaxurl": "https:\/\/nav.iowen.cn\/wp-admin\/admin-ajax.php",
			"addico": "https:\/\/nav.iowen.cn\/wp-content\/themes\/onenav\/images\/add.png",
			"order": "asc",
			"formpostion": "top",
			"defaultclass": "io-grey-mode",
			"isCustomize": "1",
			"icourl": "https:\/\/api.iowen.cn\/favicon\/",
			"icopng": ".png",
			"urlformat": "1",
			"customizemax": "10",
			"newWindow": "0",
			"lazyload": "1",
			"minNav": "1",
			"loading": "1",
			"hotWords": "baidu",
			"classColumns": " col-sm-6 col-md-4 col-xl-5a col-xxl-6a ",
			"apikey": "TWpBeU1UVTNOekk1TWpVMEIvZ1M2bFVIQllUMmxsV1dZelkxQTVPVzB3UW04eldGQmxhM3BNWW14bVNtWk4="
		};
		/* ]]> */
	</script>
	<script type='text/javascript' src='assets/js/popper.min.js' id='popper-js'></script>
	<script type='text/javascript' src='<?= $this->cdn('twitter-bootstrap/4.3.1/js/bootstrap.min.js') ?>' id='bootstrap-js'></script>
	<script type='text/javascript' src='assets/js/theia-sticky-sidebar.js' id='sidebar-js'></script>
	<script type='text/javascript' src='<?= $this->cdn('vanilla-lazyload/12.4.0/lazyload.min.js') ?>' id='lazyload-js'></script>
	<script type='text/javascript' src='<?= $this->cdn('fancybox/3.5.7/jquery.fancybox.min.js') ?>' id='lightbox-js-js'></script>
	<script type='text/javascript' src='assets/js/app.js' id='appjs-js'></script>
	<script type='text/javascript' src='assets/js//comment-reply.min-5.6.2.js' id='comment-reply-js'></script>
	<script type='text/javascript' src='wp-content/themes/onenav/js/comments-ajax-3.03029.1.js' id='comments-ajax-js'></script>
	<script type="text/javascript">
		$(document).ready(function() {
			var siteWelcome = $('#loading');
			siteWelcome.addClass('close');
			setTimeout(function() {
				siteWelcome.remove();
			}, 600);
		});
	</script>
	<script type="text/javascript">
		$(document).on('click', 'a.smooth-n', function(ev) {
			ev.preventDefault();
			$("html, body").animate({
				scrollTop: $($(this).attr("href")).offset().top - 90
			}, {
				duration: 500,
				easing: "swing"
			});
		});
	</script>
	<!-- 自定义代码 -->
	<!-- end 自定义代码 -->
</body>

</html>