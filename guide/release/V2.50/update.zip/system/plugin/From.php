<?php

namespace system\plugin;

use system\admin\Form as AdminForm;

class Form
{

	private $options;

	public $html = [];

	public $active = [];

	public function __construct($plugin)
	{
		$this->options = Manager::options($plugin);
	}

	private function field(&$name, &$value)
	{
		$form_name = $name;
		$name = trim($name, '[]');
		if (isset($this->options[$name])) {
			$value = $this->options[$name];
		} else {
			$this->active[$name] = $value;
		}
		$name = $form_name;
	}

	public function input($title, $name, $value = null, $type = 'text', $tip = null, $options = [])
	{
		$this->field($name, $value);
		return AdminForm::input($title, $name, $value, $type, $tip, $options);
	}

	public function text($title, $name, $value = null, $tip = null, $options = [])
	{
		$this->field($name, $value);
		return AdminForm::input($title, $name, $value, 'text', $tip, $options);
	}

	public function url($title, $name, $value = null, $tip = null, $options = [])
	{
		$this->field($name, $value);
		return AdminForm::input($title, $name, $value, 'url', $tip, $options);
	}

	public function number($title, $name, $value = null, $tip = null, $options = [])
	{
		$this->field($name, $value);
		return AdminForm::input($title, $name, $value, 'number', $tip, $options);
	}

	public function select($title, $name, $list = [], $selected = null, $tip = null, $options = [])
	{
		$this->field($name, $selected);
		return AdminForm::select($title, $name, $list, $selected, $tip, $options);
	}

	public function selects($title, $name, $list = [], $selected = null, $tip = null, $options = [])
	{
		$this->field($name, $selected);
		return AdminForm::selects($title, $name, $list, $selected, $tip, $options);
	}

	public function textarea($title, $name, $value = null, $tip = null, $options = [])
	{
		$this->field($name, $value);
		return AdminForm::textarea($title, $name, $value, $tip, $options);
	}

	public function datepicker($title, $name, $value = null, $tip = null, $options = [])
	{
		$this->field($name, $value);
		return AdminForm::datepicker($title, $name, $value, $tip, $options);
	}

	public function create($field)
	{
		$this->html[] = $field;
	}
}
