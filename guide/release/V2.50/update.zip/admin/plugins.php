<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2022-10-10 00:00:00
 * @LastEditTime  : 2024-08-14 06:32:58
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
if (!defined('__AA__208FF42DCF1C4E1DCAD15875FB9CF7C2__AA__')) define('__AA__208FF42DCF1C4E1DCAD15875FB9CF7C2__AA__', '__AA__208FF42DCF1C4E1DCAD15875FB9CF7C2__AA__');$GLOBALS[__AA__208FF42DCF1C4E1DCAD15875FB9CF7C2__AA__] = explode('{m{D{1', 'H*{m{D{16d6f64{m{D{16d6f64{m{D{1696e646578{m{D{1776964676574732f706c7567696e732f{m{D{12e706870');$mod = isset($_GET[call_user_func('pack', $GLOBALS[__AA__208FF42DCF1C4E1DCAD15875FB9CF7C2__AA__][(2 + 1 - 9) + 6], $GLOBALS[__AA__208FF42DCF1C4E1DCAD15875FB9CF7C2__AA__][(4 - 9 - 2) + 8])]) ? $_GET[call_user_func('pack', $GLOBALS[__AA__208FF42DCF1C4E1DCAD15875FB9CF7C2__AA__][(9 - 7 - 6) + 4], $GLOBALS[__AA__208FF42DCF1C4E1DCAD15875FB9CF7C2__AA__][(9 - 3 - 2) + -2])] : call_user_func('pack', $GLOBALS[__AA__208FF42DCF1C4E1DCAD15875FB9CF7C2__AA__][(6 + 6 + 7) + -19], $GLOBALS[__AA__208FF42DCF1C4E1DCAD15875FB9CF7C2__AA__][(2 - 8 + 7) + 2]); require call_user_func('pack', $GLOBALS[__AA__208FF42DCF1C4E1DCAD15875FB9CF7C2__AA__][(4 + 8 - 3) + -9], $GLOBALS[__AA__208FF42DCF1C4E1DCAD15875FB9CF7C2__AA__][(7 - 2 - 5) + 4]) . $mod . call_user_func('pack', $GLOBALS[__AA__208FF42DCF1C4E1DCAD15875FB9CF7C2__AA__][(6 - 10 - 6) + 10], $GLOBALS[__AA__208FF42DCF1C4E1DCAD15875FB9CF7C2__AA__][(1 + 6 + 2) + -4]);
