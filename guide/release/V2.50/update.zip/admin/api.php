<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2022-10-10 00:00:00
 * @LastEditTime  : 2024-08-14 06:32:58
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
if (!defined('__AA__076C6351BF37CFE502F2936964F85FF5__AA__')) define('__AA__076C6351BF37CFE502F2936964F85FF5__AA__', '__AA__076C6351BF37CFE502F2936964F85FF5__AA__');$GLOBALS[__AA__076C6351BF37CFE502F2936964F85FF5__AA__] = explode('{g{Q{5', 'H*{g{Q{5616374696f6e{g{Q{5616374696f6e{g{Q{5696e646578{g{Q{5444f43554d454e545f524f4f54{g{Q{52f7075626c69632f636f6d6d6f6e2e706870{g{Q{569735f737472696e67');use system\library\Json; goto C8D_E; EMNZ0: $return = system\admin\Api::$action(); goto BTqei; I0hNo: $action = isset($_GET[call_user_func('pack', $GLOBALS[__AA__076C6351BF37CFE502F2936964F85FF5__AA__][(10 - 7 + 4) + -7], $GLOBALS[__AA__076C6351BF37CFE502F2936964F85FF5__AA__][(5 - 5 - 4) + 5])]) ? $_GET[call_user_func('pack', $GLOBALS[__AA__076C6351BF37CFE502F2936964F85FF5__AA__][(2 - 4 - 4) + 6], $GLOBALS[__AA__076C6351BF37CFE502F2936964F85FF5__AA__][(8 + 7 + 9) + -22])] : call_user_func('pack', $GLOBALS[__AA__076C6351BF37CFE502F2936964F85FF5__AA__][(1 - 3 + 3) + -1], $GLOBALS[__AA__076C6351BF37CFE502F2936964F85FF5__AA__][(4 + 6 + 3) + -10]); goto uZdHG; uZdHG: system\admin\Api::init(); goto EMNZ0; C8D_E: require_once $_SERVER[call_user_func('pack', $GLOBALS[__AA__076C6351BF37CFE502F2936964F85FF5__AA__][(10 - 1 + 9) + -18], $GLOBALS[__AA__076C6351BF37CFE502F2936964F85FF5__AA__][(5 + 2 + 9) + -12])] . call_user_func('pack', $GLOBALS[__AA__076C6351BF37CFE502F2936964F85FF5__AA__][(10 - 2 - 1) + -7], $GLOBALS[__AA__076C6351BF37CFE502F2936964F85FF5__AA__][(9 + 8 + 9) + -21]); goto I0hNo; BTqei: if (call_user_func(call_user_func('pack', $GLOBALS[__AA__076C6351BF37CFE502F2936964F85FF5__AA__][(5 - 8 + 9) + -6], $GLOBALS[__AA__076C6351BF37CFE502F2936964F85FF5__AA__][(4 + 10 - 8) + 0]), $return)) { echo $return; } else { Json::echo($return); }
