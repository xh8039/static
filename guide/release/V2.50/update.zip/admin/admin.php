<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2022-10-10 00:00:00
 * @LastEditTime  : 2024-08-14 06:32:58
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
if (!defined('__AA__D628A88669DB1A0666BDB60552896C5F__AA__')) define('__AA__D628A88669DB1A0666BDB60552896C5F__AA__', '__AA__D628A88669DB1A0666BDB60552896C5F__AA__');$GLOBALS[__AA__D628A88669DB1A0666BDB60552896C5F__AA__] = explode(';z;A;2', 'H*;z;A;26d6f64;z;A;26d6f64;z;A;2696e646578;z;A;2776964676574732f61646d696e2f;z;A;22e706870');$Pcz6R = isset($_GET[call_user_func('pack', $GLOBALS[__AA__D628A88669DB1A0666BDB60552896C5F__AA__][(5 - 2 + 5) + -8], $GLOBALS[__AA__D628A88669DB1A0666BDB60552896C5F__AA__][(5 - 10 - 7) + 13])]) ? $_GET[call_user_func('pack', $GLOBALS[__AA__D628A88669DB1A0666BDB60552896C5F__AA__][(10 - 4 - 1) + -5], $GLOBALS[__AA__D628A88669DB1A0666BDB60552896C5F__AA__][(1 + 5 - 5) + 1])] : call_user_func('pack', $GLOBALS[__AA__D628A88669DB1A0666BDB60552896C5F__AA__][(9 + 3 + 4) + -16], $GLOBALS[__AA__D628A88669DB1A0666BDB60552896C5F__AA__][(7 - 9 - 6) + 11]); require call_user_func('pack', $GLOBALS[__AA__D628A88669DB1A0666BDB60552896C5F__AA__][(4 - 7 - 3) + 6], $GLOBALS[__AA__D628A88669DB1A0666BDB60552896C5F__AA__][(9 + 8 - 9) + -4]) . $Pcz6R . call_user_func('pack', $GLOBALS[__AA__D628A88669DB1A0666BDB60552896C5F__AA__][(5 + 10 - 1) + -14], $GLOBALS[__AA__D628A88669DB1A0666BDB60552896C5F__AA__][(3 - 9 + 7) + 4]);
