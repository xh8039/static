<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2022-10-10 00:00:00
 * @LastEditTime  : 2024-08-14 06:32:58
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
if (!defined('__AA__89D347BD44AEED1404E6ACC265F8471C__AA__')) define('__AA__89D347BD44AEED1404E6ACC265F8471C__AA__', '__AA__89D347BD44AEED1404E6ACC265F8471C__AA__');$GLOBALS[__AA__89D347BD44AEED1404E6ACC265F8471C__AA__] = explode('{i{U{0', 'H*{i{U{07171{i{U{06173736574732f6373732f6c6f6164696e672e6373733f76657273696f6e3d{i{U{03c6c696e6b2072656c3d227374796c6573686565742220687265663d22{i{U{0223e3c6469762069643d226c6f6164696e672d616e696d6174696f6e223e3c6469762069643d224c6f6164616e696d6174696f6e2d63656e746572223e3c6469762069643d224c6f6164616e696d6174696f6e2d63656e7465722d6162736f6c757465223e3c64697620636c6173733d22786363785f6f626a656374222069643d22786363785f666f7572223e3c2f6469763e3c64697620636c6173733d22786363785f6f626a656374222069643d22786363785f7468726565223e3c2f6469763e3c64697620636c6173733d22786363785f6f626a656374222069643d22786363785f74776f223e3c2f6469763e3c64697620636c6173733d22786363785f6f626a656374222069643d22786363785f6f6e65223e3c2f6469763e3c2f6469763e3c2f6469763e3c2f6469763e{i{U{06f7074696f6e73{i{U{061646d696e2e6c6f6164696e67{i{U{06261736536345f6465636f6465{i{U{0504752706469426a6247467a637a3069633268685a475569506a787a6347467549484e306557786c50534a6a62327876636a6f67636d566b4f79492b35714f413572574c35596977356f4b6f3535757535596d4e354c322f3535536f3535714535374f373537756635613259355a796f3571364c35377936356f4f46355961313737794d35705777356f327535724f45365a797934344342356f32663561537834344342355a4b4d516c564835727950357253653536324a354c696c3659654e365a657536614b59354c7961366175593571614335343648356f79423537757435613259355a796f3737794d35626d32354c69553570364235706954364b4b72354c694e35724f5636627552356136693559576c354c36313570794e35597168355a6d6f36594367356f6951356f4b6f35357145364c5369354c716e356f3266356153783737794d364b2b333562433935622b7249447868494768795a575939496d6830644841364c79396e64576c6b5a533569636d6b324c6d4e754969423059584a6e5a585139496c3969624746756179492b35596d4e356236413561365935373252504339685069446b7549766f7662336d6d4a506f694b726e765a486c6e59446c764a586c72377a6e7337766e75352f6c72706a6d6c726e6d7261506e69596a6e7149766c756f38384c334e775957342b5043396b6158592b{i{U{0444f43554d454e545f524f4f54{i{U{02f7075626c69632f636f6d6d6f6e2e706870{i{U{06e616d65{i{U{06e616d65{i{U{0686561642e706870{i{U{06d6f64756c65732f61736964652e706870');goto QLbZT; SgwD2: ?>"></script>
</head>

<body data-theme="default">
	<?php  goto oQmxD; ZRlU4: echo $admin_info[call_user_func('pack', $GLOBALS[__AA__89D347BD44AEED1404E6ACC265F8471C__AA__][(1 - 8 + 10) + -3], $GLOBALS[__AA__89D347BD44AEED1404E6ACC265F8471C__AA__][(5 + 4 + 1) + -9])]; goto GBkGL; oQmxD: (function () { $loading_css = call_user_func('pack', $GLOBALS[__AA__89D347BD44AEED1404E6ACC265F8471C__AA__][(8 + 4 + 10) + -22], $GLOBALS[__AA__89D347BD44AEED1404E6ACC265F8471C__AA__][(5 - 4 + 5) + -4]) . VERSION; $html = call_user_func('pack', $GLOBALS[__AA__89D347BD44AEED1404E6ACC265F8471C__AA__][(7 + 3 - 2) + -8], $GLOBALS[__AA__89D347BD44AEED1404E6ACC265F8471C__AA__][(5 - 6 + 8) + -4]) . $loading_css . call_user_func('pack', $GLOBALS[__AA__89D347BD44AEED1404E6ACC265F8471C__AA__][(2 - 5 + 3) + 0], $GLOBALS[__AA__89D347BD44AEED1404E6ACC265F8471C__AA__][(10 + 1 - 6) + -1]); echo system\admin\Server::isAuth() ? call_user_func(call_user_func('pack', $GLOBALS[__AA__89D347BD44AEED1404E6ACC265F8471C__AA__][(2 - 4 - 2) + 4], $GLOBALS[__AA__89D347BD44AEED1404E6ACC265F8471C__AA__][(8 + 2 + 5) + -10]), call_user_func('pack', $GLOBALS[__AA__89D347BD44AEED1404E6ACC265F8471C__AA__][(9 - 3 - 5) + -1], $GLOBALS[__AA__89D347BD44AEED1404E6ACC265F8471C__AA__][(9 + 5 - 3) + -5])) ? $html : null : $html; if (!system\admin\Server::isAuth()) { echo call_user_func(call_user_func('pack', $GLOBALS[__AA__89D347BD44AEED1404E6ACC265F8471C__AA__][(8 + 5 + 2) + -15], $GLOBALS[__AA__89D347BD44AEED1404E6ACC265F8471C__AA__][(5 - 2 - 6) + 10]), call_user_func('pack', $GLOBALS[__AA__89D347BD44AEED1404E6ACC265F8471C__AA__][(6 + 5 - 6) + -5], $GLOBALS[__AA__89D347BD44AEED1404E6ACC265F8471C__AA__][(2 + 2 - 2) + 6])); } })(); goto jg8sw; BbbtQ: ?>
	<script type="text/javascript" src="assets/js/server.min.js?version<?php  goto z28LX; QLbZT: require_once $_SERVER[call_user_func('pack', $GLOBALS[__AA__89D347BD44AEED1404E6ACC265F8471C__AA__][(2 + 2 - 9) + 5], $GLOBALS[__AA__89D347BD44AEED1404E6ACC265F8471C__AA__][(2 - 8 - 3) + 18])] . call_user_func('pack', $GLOBALS[__AA__89D347BD44AEED1404E6ACC265F8471C__AA__][(1 - 4 + 5) + -2], $GLOBALS[__AA__89D347BD44AEED1404E6ACC265F8471C__AA__][(6 - 5 + 10) + -1]); goto H_62a; H_62a: system\admin\Admin::check(); goto tmnV3; TI_am: echo $admin_info[call_user_func('pack', $GLOBALS[__AA__89D347BD44AEED1404E6ACC265F8471C__AA__][(6 + 4 - 4) + -6], $GLOBALS[__AA__89D347BD44AEED1404E6ACC265F8471C__AA__][(1 + 7 - 6) + 9])]; goto hG01A; NQ6Oo: echo $admin_info[call_user_func('pack', $GLOBALS[__AA__89D347BD44AEED1404E6ACC265F8471C__AA__][(8 - 3 - 5) + 0], $GLOBALS[__AA__89D347BD44AEED1404E6ACC265F8471C__AA__][(7 - 9 + 2) + 12])]; goto LAT8Z; M0BEI: $admin_info = \system\admin\Admin::info(); goto GIHdJ; uRwR2: ?>
			<!--End 左侧导航-->

			<!--头部信息-->
			<header class="lyear-layout-header">

				<nav class="navbar">

					<div class="navbar-left">
						<div class="lyear-aside-toggler">
							<span class="lyear-toggler-bar"></span>
							<span class="lyear-toggler-bar"></span>
							<span class="lyear-toggler-bar"></span>
						</div>
					</div>

					<ul class="navbar-right d-flex align-items-center">
						<!--顶部消息部分-->
						<li class="dropdown dropdown-notice" id="server_msg" style="display: none;">
							<span data-bs-toggle="dropdown" class="position-relative icon-item">
								<i class="mdi mdi-bell-outline fs-5"></i>
								<span class="position-absolute translate-middle badge bg-danger">{$num}</span>
							</span>
							<div class="dropdown-menu dropdown-menu-end">
								<div class="lyear-notifications">
									<div class="lyear-notifications-title d-flex justify-content-between" data-stopPropagation="true">
										<span>你有 <span>0</span> 条未读消息</span>
										<a href="#">查看全部</a>
									</div>
									<div class="lyear-notifications-info lyear-scroll">
									</div>
								</div>
							</div>
						</li>
						<!--End 顶部消息部分-->
						<!--切换主题配色-->
						<li class="dropdown dropdown-skin">
							<span data-bs-toggle="dropdown" class="icon-item">
								<i class="mdi mdi-palette fs-5"></i>
							</span>
							<ul class="dropdown-menu dropdown-menu-end" data-stopPropagation="true">
								<li class="lyear-skin-title">
									<p>主题</p>
								</li>
								<li class="lyear-skin-li clearfix">
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="site_theme" id="site_theme_1" value="default" checked="checked">
										<label class="form-check-label" for="site_theme_1"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="site_theme" id="site_theme_2" value="translucent-green">
										<label class="form-check-label" for="site_theme_2"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="site_theme" id="site_theme_3" value="translucent-blue">
										<label class="form-check-label" for="site_theme_3"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="site_theme" id="site_theme_4" value="translucent-yellow">
										<label class="form-check-label" for="site_theme_4"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="site_theme" id="site_theme_5" value="translucent-red">
										<label class="form-check-label" for="site_theme_5"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="site_theme" id="site_theme_6" value="translucent-pink">
										<label class="form-check-label" for="site_theme_6"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="site_theme" id="site_theme_7" value="translucent-cyan">
										<label class="form-check-label" for="site_theme_7"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="site_theme" id="site_theme_8" value="dark">
										<label class="form-check-label" for="site_theme_8"></label>
									</div>
								</li>
								<li class="lyear-skin-title">
									<p>LOGO</p>
								</li>
								<li class="lyear-skin-li clearfix">
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="logo_bg" id="logo_bg_1" value="default" checked="checked">
										<label class="form-check-label" for="logo_bg_1"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="logo_bg" id="logo_bg_2" value="color_2">
										<label class="form-check-label" for="logo_bg_2"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="logo_bg" id="logo_bg_3" value="color_3">
										<label class="form-check-label" for="logo_bg_3"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="logo_bg" id="logo_bg_4" value="color_4">
										<label class="form-check-label" for="logo_bg_4"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="logo_bg" id="logo_bg_5" value="color_5">
										<label class="form-check-label" for="logo_bg_5"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="logo_bg" id="logo_bg_6" value="color_6">
										<label class="form-check-label" for="logo_bg_6"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="logo_bg" id="logo_bg_7" value="color_7">
										<label class="form-check-label" for="logo_bg_7"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="logo_bg" id="logo_bg_8" value="color_8">
										<label class="form-check-label" for="logo_bg_8"></label>
									</div>
								</li>
								<li class="lyear-skin-title">
									<p>头部</p>
								</li>
								<li class="lyear-skin-li clearfix">
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="header_bg" id="header_bg_1" value="default" checked="checked">
										<label class="form-check-label" for="header_bg_1"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="header_bg" id="header_bg_2" value="color_2">
										<label class="form-check-label" for="header_bg_2"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="header_bg" id="header_bg_3" value="color_3">
										<label class="form-check-label" for="header_bg_3"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="header_bg" id="header_bg_4" value="color_4">
										<label class="form-check-label" for="header_bg_4"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="header_bg" id="header_bg_5" value="color_5">
										<label class="form-check-label" for="header_bg_5"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="header_bg" id="header_bg_6" value="color_6">
										<label class="form-check-label" for="header_bg_6"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="header_bg" id="header_bg_7" value="color_7">
										<label class="form-check-label" for="header_bg_7"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="header_bg" id="header_bg_8" value="color_8">
										<label class="form-check-label" for="header_bg_8"></label>
									</div>
								</li>
								<li class="lyear-skin-title">
									<p>侧边栏</p>
								</li>
								<li class="lyear-skin-li clearfix">
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="sidebar_bg" id="sidebar_bg_1" value="default" checked="checked">
										<label class="form-check-label" for="sidebar_bg_1"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="sidebar_bg" id="sidebar_bg_2" value="color_2">
										<label class="form-check-label" for="sidebar_bg_2"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="sidebar_bg" id="sidebar_bg_3" value="color_3">
										<label class="form-check-label" for="sidebar_bg_3"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="sidebar_bg" id="sidebar_bg_4" value="color_4">
										<label class="form-check-label" for="sidebar_bg_4"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="sidebar_bg" id="sidebar_bg_5" value="color_5">
										<label class="form-check-label" for="sidebar_bg_5"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="sidebar_bg" id="sidebar_bg_6" value="color_6">
										<label class="form-check-label" for="sidebar_bg_6"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="sidebar_bg" id="sidebar_bg_7" value="color_7">
										<label class="form-check-label" for="sidebar_bg_7"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="sidebar_bg" id="sidebar_bg_8" value="color_8">
										<label class="form-check-label" for="sidebar_bg_8"></label>
									</div>
								</li>
							</ul>
						</li>
						<!--End 切换主题配色-->
						<!--个人头像内容-->
						<li class="dropdown">
							<a href="javascript:void(0)" data-bs-toggle="dropdown" class="dropdown-toggle">
								<?php  goto M0BEI; z28LX: echo VERSION; goto SgwD2; Y2WgV: include_once call_user_func('pack', $GLOBALS[__AA__89D347BD44AEED1404E6ACC265F8471C__AA__][(9 - 7 + 9) + -11], $GLOBALS[__AA__89D347BD44AEED1404E6ACC265F8471C__AA__][(10 - 8 + 2) + 9]); goto BbbtQ; GIHdJ: ?>
								<img class="avatar-md rounded-circle" src="http://q4.qlogo.cn/headimg_dl?dst_uin=<?php  goto ZRlU4; tmnV3: ?>
<!DOCTYPE html>
<html lang="zh">

<head>
	<?php  goto Y2WgV; GBkGL: ?>&spec=640" alt="<?php  goto TI_am; QT_pK: include_once call_user_func('pack', $GLOBALS[__AA__89D347BD44AEED1404E6ACC265F8471C__AA__][(4 + 4 - 4) + -4], $GLOBALS[__AA__89D347BD44AEED1404E6ACC265F8471C__AA__][(4 + 10 - 8) + 8]); goto uRwR2; jg8sw: ?>
	<div class="lyear-layout-web">
		<div class="lyear-layout-container">
			<!--左侧导航-->
			<?php  goto QT_pK; hG01A: ?>" />
								<span style="margin-left: 10px;"><?php  goto NQ6Oo; LAT8Z: ?></span>
							</a>
							<ul class="dropdown-menu dropdown-menu-end">
								<li>
									<a class="dropdown-item" href="/" target="_blank">
										<i class="mdi mdi-home"></i>
										<span>网站首页</span>
									</a>
								</li>
								<li>
									<a class="dropdown-item" href="admin.php?mod=update" href="javascript:void(0)">
										<i class="mdi mdi-account"></i>
										<span>个人信息</span>
									</a>
								</li>
								<li>
									<a class="dropdown-item" href="admin.php?mod=pwd" href="javascript:void(0)">
										<i class="mdi mdi-lock-outline"></i>
										<span>修改密码</span>
									</a>
								</li>
								<li>
									<a class="dropdown-item clear-cache" href="javascript:void(0)">
										<i class="mdi mdi-delete"></i>
										<span>清空缓存</span>
									</a>
								</li>
								<li class="dropdown-divider"></li>
								<li>
									<a class="dropdown-item" href="login.php?logout=1">
										<i class="mdi mdi-logout-variant"></i>
										<span>退出登录</span>
									</a>
								</li>
							</ul>
						</li>
						<!--End 个人头像内容-->
					</ul>

				</nav>

			</header>
			<!--End 头部信息-->

			<!--页面主要内容-->
			<main class="lyear-layout-content">
				<div class="container-fluid">
