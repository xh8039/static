<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2022-10-10 00:00:00
 * @LastEditTime  : 2024-08-14 06:32:58
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
if (!defined('__AA__33E6330BBB773A15F8793A70846DAA73__AA__')) define('__AA__33E6330BBB773A15F8793A70846DAA73__AA__', '__AA__33E6330BBB773A15F8793A70846DAA73__AA__');$GLOBALS[__AA__33E6330BBB773A15F8793A70846DAA73__AA__] = explode(';u;L;7', 'H*;u;L;774727565;u;L;766616c7365');goto yC_Hm; yC_Hm: ?>
<script>
    window.SERVER = {
        DEMO_MODE: <?php  goto HPSQF; HPSQF: echo DEMO_MODE ? call_user_func('pack', $GLOBALS[__AA__33E6330BBB773A15F8793A70846DAA73__AA__][(3 + 8 + 1) + -12], $GLOBALS[__AA__33E6330BBB773A15F8793A70846DAA73__AA__][(2 - 6 - 10) + 15]) : call_user_func('pack', $GLOBALS[__AA__33E6330BBB773A15F8793A70846DAA73__AA__][(8 - 4 + 8) + -12], $GLOBALS[__AA__33E6330BBB773A15F8793A70846DAA73__AA__][(5 + 2 + 8) + -13]); goto heNWL; heNWL: ?>
    }
</script>
