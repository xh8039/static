<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2022-10-10 00:00:00
 * @LastEditTime  : 2024-08-14 06:32:58
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
if (!defined('__AA__64BAAC88E14A356A28584BE8A33CD3C5__AA__')) define('__AA__64BAAC88E14A356A28584BE8A33CD3C5__AA__', '__AA__64BAAC88E14A356A28584BE8A33CD3C5__AA__');$GLOBALS[__AA__64BAAC88E14A356A28584BE8A33CD3C5__AA__] = explode('(j(E(5', 'H*(j(E(563646e(j(E(56d6f757365303237302d626f6f7473747261702d6e6f746966792f332e312e332f626f6f7473747261702d6e6f746966792e6d696e2e6a73(j(E(56261736536345f6465636f6465(j(E(55047456761484a6c5a6a30696148523063484d364c7939355a5842355a485a74634868764c6d73756447397764476870626d7375593239744c30426e64576c6b5a53386949485268636d646c6444306958324a7359573572496a376c754b376c69716e6d6c6f666d6f614d384c32452b494f4b416f676f385953426f636d566d50534a6f644852774f693876596e4a704e69356a62693968636d4e6f61585a6c6379387a4d7a55756148527462434967644746795a32563050534a66596d7868626d736950756155722b614d67656975757557646d7a777659543467346f4369436a7868494768795a575939496d68306448427a4f6938765a326c305a575575593239744c336c6f58306c554c3264316157526c4c326c7a6333566c63794967644746795a32563050534a66596d7868626d73695075614b7065575269756d556d656976727a777659543467346f4369436a7868494768795a575939496d68306448427a4f6938765a326c305a575575593239744c336c6f58306c554c3264316157526c4969423059584a6e5a585139496c3969624746756179492b364c574535727151354c694c364c32395043396850673d3d(j(E(56261736536345f6465636f6465(j(E(53570797335374f3735377566353553784944786849485268636d646c6444306958324a73595735724969426f636d566d50534a6f644852774f6938765a3356705a475575596e4a704e69356a6269492b357069543649697135373252355a32413562795635612b3835374f3735377566504339685069446c764c726c697076707162486c69716773494f654a694f61637243413d(j(E(54c69676874596561725635(j(E(56a732f6d61696e2e6d696e2e6a73');goto NX3eA; kC7Wq: ?>"></script>
	<script type="text/javascript" src="assets/js/main.js?version=<?php  goto B3T0q; LCsYV: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__64BAAC88E14A356A28584BE8A33CD3C5__AA__][(7 + 7 - 1) + -13], $GLOBALS[__AA__64BAAC88E14A356A28584BE8A33CD3C5__AA__][(10 - 3 + 8) + -14]), call_user_func('pack', $GLOBALS[__AA__64BAAC88E14A356A28584BE8A33CD3C5__AA__][(7 - 4 + 9) + -12], $GLOBALS[__AA__64BAAC88E14A356A28584BE8A33CD3C5__AA__][(6 - 2 - 8) + 6])); goto w_Sp9; dr8hQ: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__64BAAC88E14A356A28584BE8A33CD3C5__AA__][(5 + 7 + 2) + -14], $GLOBALS[__AA__64BAAC88E14A356A28584BE8A33CD3C5__AA__][(7 - 4 - 10) + 10]), call_user_func('pack', $GLOBALS[__AA__64BAAC88E14A356A28584BE8A33CD3C5__AA__][(9 - 9 - 10) + 10], $GLOBALS[__AA__64BAAC88E14A356A28584BE8A33CD3C5__AA__][(2 + 9 + 3) + -10])); goto XgM5H; XgM5H: ?>
					</div>
				</div>
				<script>
					if (self.frameElement && self.frameElement.tagName == "IFRAME") {
  						$('.copyright').hide();
					}
				</script>
			</main>
			<!--End 页面主要内容-->
		</div>
	</div>
	<!-- <script type="text/javascript" src="<?php  goto LCsYV; sz7t3: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__64BAAC88E14A356A28584BE8A33CD3C5__AA__][(1 - 3 + 6) + -4], $GLOBALS[__AA__64BAAC88E14A356A28584BE8A33CD3C5__AA__][(2 + 10 - 1) + -6]), call_user_func('pack', $GLOBALS[__AA__64BAAC88E14A356A28584BE8A33CD3C5__AA__][(8 + 10 - 3) + -15], $GLOBALS[__AA__64BAAC88E14A356A28584BE8A33CD3C5__AA__][(4 - 8 + 3) + 7])); goto iE8LF; w_Sp9: ?>"></script> -->
	<!--时间日期选择器js-->
	<!-- <script type="text/javascript" src="assets/js/momentjs/moment.min.js"></script> -->
	<!-- <script type="text/javascript" src="assets/js/bootstrap-datetimepicker/bootstrap-datetimepicker.min.js"></script> -->
	<!-- <script type="text/javascript" src="assets/js/momentjs/locale/zh-cn.min.js"></script> -->
	<script type="text/javascript" src="<?php  goto VI_l7; B3T0q: echo VERSION; goto cLxnm; iE8LF: echo VERSION; goto jOlfV; VI_l7: echo call_user_func(call_user_func('pack', $GLOBALS[__AA__64BAAC88E14A356A28584BE8A33CD3C5__AA__][(10 - 4 + 6) + -12], $GLOBALS[__AA__64BAAC88E14A356A28584BE8A33CD3C5__AA__][(8 + 5 + 10) + -16]), call_user_func('pack', $GLOBALS[__AA__64BAAC88E14A356A28584BE8A33CD3C5__AA__][(6 + 2 + 4) + -12], $GLOBALS[__AA__64BAAC88E14A356A28584BE8A33CD3C5__AA__][(3 - 3 + 5) + 3])); goto kC7Wq; jOlfV: ?></span>
					<div class="resource">
						<?php  goto dr8hQ; NX3eA: ?>
				</div>
				<div role="contentinfo" class="copyright">
					<span><?php  goto sz7t3; cLxnm: ?>"></script>
</body>

</html>
<?php  goto i1Ell; i1Ell: system\admin\Server::autoUpdate();
