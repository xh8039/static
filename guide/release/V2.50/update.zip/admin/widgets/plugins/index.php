<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2022-10-10 00:00:00
 * @LastEditTime  : 2024-08-14 06:32:58
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
if (!defined('__AA__A7C0BE578C6809B25435F1FD427EE2CD__AA__')) define('__AA__A7C0BE578C6809B25435F1FD427EE2CD__AA__', '__AA__A7C0BE578C6809B25435F1FD427EE2CD__AA__');$GLOBALS[__AA__A7C0BE578C6809B25435F1FD427EE2CD__AA__] = explode('[o[H[5', 'H*[o[H[56d6f64756c65732f6865616465722e706870[o[H[5[o[H[5e68f92e4bbb6e7aea1e79086');goto lq7ZI; qNVd7: include call_user_func('pack', $GLOBALS[__AA__A7C0BE578C6809B25435F1FD427EE2CD__AA__][(10 - 4 - 1) + -5], $GLOBALS[__AA__A7C0BE578C6809B25435F1FD427EE2CD__AA__][(6 + 9 - 2) + -12]); goto CnShW; CnShW: system\admin\View::table(call_user_func('pack', $GLOBALS[__AA__A7C0BE578C6809B25435F1FD427EE2CD__AA__][(6 - 1 - 4) + -1], $GLOBALS[__AA__A7C0BE578C6809B25435F1FD427EE2CD__AA__][(4 + 7 - 5) + -4])); goto qBy87; lq7ZI: $title = call_user_func('pack', $GLOBALS[__AA__A7C0BE578C6809B25435F1FD427EE2CD__AA__][(4 - 6 + 10) + -8], $GLOBALS[__AA__A7C0BE578C6809B25435F1FD427EE2CD__AA__][(8 + 7 - 2) + -10]); goto qNVd7; qBy87: ?>
<script>
	BootstrapTable.options.act = 'getPlugin';
	BootstrapTable.table_options.search = false;
	BootstrapTable.table_options.uniqueId = 'name'; //唯一字段
	BootstrapTable.table_options.idField = 'name'; //每行的唯一标识字段
	BootstrapTable.options.status_api = 'pluginStatus';
	BootstrapTable.options.operate.delete = false;
	BootstrapTable.columns = [{
			field: 'title',
			align: 'center',
			title: '名称',
			titleTooltip: '插件名称'
		},
		{
			field: 'description',
			align: 'center',
			title: '描述',
		},
		{
			field: 'author',
			align: 'center',
			title: '作者',
			formatter: function(value, row) {
				value = `<a target="_blank" href="${row.link}">${value}</a>`
				return value;
			}
		},
		{
			field: 'version',
			align: 'center',
			title: '版本',
			sortable: true,
		}
	]
	BootstrapTable.init();
</script>
