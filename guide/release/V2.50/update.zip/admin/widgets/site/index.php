<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2022-10-10 00:00:00
 * @LastEditTime  : 2024-08-14 06:32:58
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
if (!defined('__AA__20191BBC0DC76E2DBE42332BE9526693__AA__')) define('__AA__20191BBC0DC76E2DBE42332BE9526693__AA__', '__AA__20191BBC0DC76E2DBE42332BE9526693__AA__');$GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__] = explode('?b?P?3', 'H*?b?P?33c6120646174612d75726c3d223f6d6f643d6372656174652220636c6173733d2262746e2062746e2d7072696d617279206d622d31206d652d31206c617965725f696672616d65223e3c7370616e20636c6173733d226d6469206d64692d706c75732220617269612d68696464656e3d2274727565223e3c2f7370616e3e20e696b0e5a29e3c2f613e?b?P?36964?b?P?37469746c65?b?P?3e7ab99e782b9e7aea1e79086?b?P?3736f72745f73656c656374?b?P?3616c6c?b?P?3636c617373?b?P?3666f726d2d636f6e74726f6c2073656c6563747069636b6572?b?P?37374796c65?b?P?377696474683a20313030253b70616464696e673a367078203070783b?b?P?36f6e6368616e6765?b?P?3736f72745f73656c656374287468697329?b?P?3736f7274?b?P?36d6f64756c65732f6865616465722e706870?b?P?3656c656d656e74?b?P?3646976?b?P?3636c617373?b?P?3666c6f61742d7269676874206d622d31206d732d31?b?P?3616c6c?b?P?3e68980e69c89e7b1bbe588ab');use JsonDb\JsonDb\Db; use system\library\FormBuilder; goto t7LCY; QiEIH: $buttons = call_user_func('pack', $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(10 - 7 + 1) + -4], $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(7 + 5 + 7) + -18]) . $sort_select; goto cO_v8; cO_v8: system\admin\View::table($buttons); goto SACxS; ijU3Z: foreach ($sort as $key => $value) { $list[$value[call_user_func('pack', $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(1 + 2 - 8) + 5], $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(6 + 7 - 1) + -10])]] = $value[call_user_func('pack', $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(8 - 1 - 5) + -2], $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(3 + 10 + 6) + -16])]; } goto C6Se3; t7LCY: $title = call_user_func('pack', $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(2 + 6 - 5) + -3], $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(4 + 8 - 3) + -5]); goto Py8qU; C6Se3: $sort_select = FormBuilder::select(call_user_func('pack', $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(10 - 2 - 6) + -2], $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(9 + 10 - 2) + -12]), $list, call_user_func('pack', $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(3 + 8 - 2) + -9], $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(6 + 10 - 9) + -1]), [call_user_func('pack', $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(6 + 7 + 4) + -17], $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(2 + 6 - 9) + 8]) => call_user_func('pack', $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(5 + 9 - 5) + -9], $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(6 - 9 + 7) + 4]), call_user_func('pack', $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(9 - 10 - 7) + 8], $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(3 + 7 - 6) + 5]) => call_user_func('pack', $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(7 - 9 + 9) + -7], $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(8 + 5 + 4) + -7]), call_user_func('pack', $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(6 - 8 + 3) + -1], $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(8 + 9 + 7) + -13]) => call_user_func('pack', $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(8 + 6 - 8) + -6], $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(10 + 1 + 5) + -4])]); goto RkLZK; T3Eoe: $sort = Db::name(call_user_func('pack', $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(7 + 2 + 1) + -10], $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(4 - 1 + 3) + 7]))->selectAll(); goto PykDI; Py8qU: include call_user_func('pack', $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(2 + 3 + 10) + -15], $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(1 + 3 - 5) + 15]); goto T3Eoe; RkLZK: $sort_select = call_user_func(call_user_func('pack', $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(7 - 2 - 7) + 2], $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(4 - 7 - 10) + 28]), call_user_func('pack', $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(9 + 5 - 3) + -11], $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(9 - 6 + 10) + 3]))->attr([call_user_func('pack', $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(7 - 2 - 1) + -4], $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(7 - 7 + 2) + 15]) => call_user_func('pack', $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(6 + 2 - 1) + -7], $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(6 - 8 - 5) + 25])])->get($sort_select); goto QiEIH; PykDI: $list = [call_user_func('pack', $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(5 - 3 + 10) + -12], $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(5 - 6 - 6) + 26]) => call_user_func('pack', $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(6 - 9 - 4) + 7], $GLOBALS[__AA__20191BBC0DC76E2DBE42332BE9526693__AA__][(3 + 2 - 8) + 23])]; goto ijU3Z; SACxS: ?>
<script>
	BootstrapTable.options.table = 'site';
	BootstrapTable.options.act = 'getSite';
	BootstrapTable.table_options.queryParams = (params) => {
		params.class = $('[name=sort_select]').val();
		return params;
	}
	BootstrapTable.table_options.sortName = 'create_time';
	BootstrapTable.table_options.sortOrder = 'desc';
	BootstrapTable.columns = [{
			field: 'title',
			align: 'center',
			title: '标题',
			sortable: true,
			titleTooltip: '站点标题'
		},
		{
			field: 'url',
			align: 'center',
			title: '链接',
			titleTooltip: '站点内容',
			sortable: true,
			formatter: function(value) {
				return `<div class="hide" style="max-width:48vw"><a href="${value}" target="_blank">${value}</a></div>`;
			}
		},
		{
			field: "sort",
			title: '分类',
			titleTooltip: '所属分类',
			align: "center",
		},
		{
			field: 'order',
			align: 'center',
			sortable: true, // 是否作为排序列
			title: '排序',
		},
		{
			field: 'create_time',
			align: 'center',
			title: '创建时间',
			visible: false,
			sortable: true
		},
		{
			field: 'failure_time',
			align: 'center',
			title: '有效时间',
			// visible: false,
			sortable: true,
			formatter: function(value, row) {
				return value ? value : '永久有效';
			},
		}
	]
	BootstrapTable.init();

	function sort_select(self) {
		var value = self.value;
		$('table').bootstrapTable('refresh', {
			query: {
				class: value
			}
		});
	}
</script>
