<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2022-10-10 00:00:00
 * @LastEditTime  : 2024-08-14 10:39:45
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
if (!defined('__AA__7150C4604F1C086DB59A58FD577E1E17__AA__')) define('__AA__7150C4604F1C086DB59A58FD577E1E17__AA__', '__AA__7150C4604F1C086DB59A58FD577E1E17__AA__');$GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__] = explode('<v<A<1', 'H*<v<A<1e9a696e9a1b5e4b8bbe9a298e7aea1e79086<v<A<16d6f64756c65732f6865616465722e706870<v<A<17468656d655f63617264<v<A<16f7074696f6e73<v<A<163757272656e745f7468656d65<v<A<16e616d65<v<A<173637265656e73686f74<v<A<1617574686f72<v<A<16f7074696f6e73<v<A<174727565<v<A<166616c7365<v<A<16c696e6b<v<A<166696c655f657869737473<v<A<16e616d65<v<A<173637265656e73686f742e6a7067<v<A<17469746c65<v<A<176657273696f6e<v<A<16e616d65<v<A<13f76657273696f6e3d<v<A<176657273696f6e<v<A<16465736372697074696f6e<v<A<173637265656e73686f74<v<A<12f636f6e74656e742f7374617469632f696d616765732f5468656d654e6f496d672e6a7067<v<A<17469746c65<v<A<12f636f6e74656e742f7468656d65732f<v<A<16e616d65<v<A<12f73637265656e73686f742e6a7067<v<A<17468656d655f63617264<v<A<16f7074696f6e73<v<A<163757272656e745f7468656d65<v<A<16d6f64756c65732f666f6f7465722e706870');$title = call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(3 - 3 - 7) + 7], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(7 + 10 - 4) + -12]); include call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(9 - 3 - 3) + -3], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(5 - 2 + 2) + -3]); use system\theme\Manager; goto xjtZs; DNgSP: unset($A9ff8[$rB1OW]); goto MsyEc; h3o2k: call_user_func(call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(1 - 7 - 9) + 15], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(7 + 10 - 9) + -5]), $A9ff8[$rB1OW]); goto DNgSP; xjtZs: ?>
<link href="https://cdn.bootcdn.net/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.css" rel="stylesheet">
<div class="row">
	<div class="col-lg-12">
		<div class="card" id="card">
			<header class="card-header d-flex justify-content-between">
				<div class="card-title"><?php  goto sBinB; nVY5Z: function theme_card($v7mjD) { goto TM5G1; JGbJD: if (call_user_func(call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(2 - 10 + 9) + -1], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(1 - 8 + 3) + 8]), call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(4 + 4 + 6) + -14], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(1 + 5 + 8) + -9])) == $v7mjD[call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(10 + 8 - 3) + -15], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(7 + 9 + 7) + -17])]) { goto WZXaO; } goto hOjLC; j3jlt: goto UqNAk; goto ejX_C; TM5G1: if (empty($v7mjD[call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(10 + 2 + 10) + -22], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(8 + 3 + 7) + -11])])) { goto NOyDJ; } goto IiMU0; ikcnP: xvbNY: goto HVJaq; zoECQ: echo $v7mjD[call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(10 + 6 - 7) + -9], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(9 + 7 - 9) + 1])]; goto Dy3cK; wnI91: ?>
						<div class="col">
							<div class="card h-100">
								<a href="<?php  goto aHHPD; Xw365: echo $v7mjD[call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(10 + 9 + 9) + -28], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(10 - 6 - 6) + 11])] ? call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(6 - 1 - 8) + 3], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(5 + 3 + 1) + 1]) : call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(4 + 8 - 6) + -6], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(2 + 10 + 7) + -8]); goto HaOe3; aHHPD: echo $AZseB; goto AJ9fP; AJ9fP: ?>" ajax-replace="true" data-fancybox="theme" data-caption="<b><?php  goto G5y80; HaOe3: ?>)">启用</button>
										<?php  goto n_SBe; n_SBe: goto xvbNY; goto xhCpM; PwQai: ?>
											<button disabled class="btn btn-primary btn-round btn-w-lg">正在使用</button>
										<?php  goto ikcnP; tadvd: UqNAk: goto LK0Dm; wlvBO: echo $v7mjD[call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(3 + 6 - 8) + -1], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(3 + 8 - 5) + 6])]; goto vI64T; Ws3Ti: if (call_user_func(call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(4 + 7 + 5) + -16], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(2 + 10 - 1) + 2]), THEME_PATH . $v7mjD[call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(5 + 1 + 5) + -11], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(7 + 5 + 5) + -3])] . DIR_SEP . call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(4 - 3 + 4) + -5], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(2 + 6 - 10) + 17]))) { goto pJWeF; } goto FSJwd; RDamE: NOyDJ: goto Ws3Ti; wORWU: echo $v7mjD[call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(5 + 4 + 8) + -17], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(9 + 2 + 6) + -1])]; goto tdvPm; DZFwP: echo $v7mjD[call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(1 + 2 + 8) + -11], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(7 - 5 - 4) + 19])]; goto TWp09; Htoyw: echo $v7mjD[call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(5 + 10 + 7) + -22], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(2 + 10 - 10) + 16])]; goto pDs9x; tdvPm: ?></h5>
									<div class="card-text">
										<span style="display:block;margin-bottom:5px">
											<span style="margin-right:15px">
												作者：<a href="<?php  goto wlvBO; vI64T: ?>" target="_blank"><?php  goto zoECQ; Zie8v: ?>" class="card-img-top screenshot" title="点击预览大图" data-bs-toggle="tooltip" data-bs-placement="top" />
								</a>
								<div class="card-body">
									<h5 class="card-title"><?php  goto wORWU; LK0Dm: zdGqW: goto n1n9r; Dy3cK: ?></a>
											</span>
											<span>版本：<?php  goto DZFwP; n1n9r: $AZseB .= call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(9 + 6 - 10) + -5], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(2 - 9 - 9) + 35]) . $v7mjD[call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(1 + 1 + 7) + -9], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(1 + 6 - 10) + 23])]; goto wnI91; ejX_C: pJWeF: goto gTpQ4; TWp09: ?></span>
										</span>
										<span>简介：<?php  goto wzmW1; wzmW1: echo $v7mjD[call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(10 - 2 + 4) + -12], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(6 + 3 + 2) + 10])]; goto yDoW0; yDoW0: ?></span>
									</div>
								</div>
								<footer class="card-footer text-end">
									<div style="display: flex;justify-content: center;">
										<?php  goto JGbJD; IiMU0: $AZseB = $v7mjD[call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(7 - 10 - 7) + 10], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(7 - 2 - 2) + 19])]; goto Yhibz; FSJwd: $AZseB = call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(5 + 5 + 1) + -11], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(2 + 9 - 1) + 13]); goto j3jlt; xhCpM: WZXaO: goto PwQai; G5y80: echo $v7mjD[call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(1 + 3 + 5) + -9], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(4 - 9 + 3) + 26])]; goto PEvpV; gTpQ4: $AZseB = call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(6 + 3 + 1) + -10], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(1 - 9 - 4) + 37]) . $v7mjD[call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(5 - 5 + 7) + -7], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(6 - 10 + 5) + 25])] . call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(5 + 1 + 4) + -10], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(10 - 6 - 3) + 26]); goto tadvd; pDs9x: ?>', <?php  goto Xw365; hOjLC: ?>
											<button class="btn btn-primary btn-round btn-w-lg" onclick="SetTheme('<?php  goto Htoyw; Yhibz: goto zdGqW; goto RDamE; PEvpV: ?></b>">
									<img referrer="no-referrer" src="<?php  goto wYPIJ; HVJaq: ?>
									</div>
								</footer>
							</div>
						</div>
					<?php  goto SSCMl; wYPIJ: echo $AZseB; goto Zie8v; SSCMl: } goto ojTKy; QB9yr: QQsfx: goto DmjDx; MsyEc: e5KLx: goto w3UPA; w3UPA: foreach ($A9ff8 as $iDz7m => $jIhq_) { call_user_func(call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(7 - 7 + 7) + -7], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(10 + 10 + 1) + 7]), $jIhq_); daE9u: } goto QB9yr; EH43M: $rB1OW = call_user_func(call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(3 - 9 - 8) + 14], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(5 - 8 - 5) + 37]), call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(7 - 2 + 9) + -14], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(9 - 2 - 8) + 31])); goto mqCIa; aeMlO: include call_user_func('pack', $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(9 + 4 - 1) + -12], $GLOBALS[__AA__7150C4604F1C086DB59A58FD577E1E17__AA__][(1 + 2 - 2) + 30]); goto jn_jH; DmjDx: ?>
				</div>
				<div class="alert alert-primary" role="alert">
					部分主题来自网络收集，含有作者信息的易航已添加作者信息和版权，如有问题请<a class="alert-link" href="http://wpa.qq.com/msgrd?v=3&uin=2136118039&site=qq&menu=yes"> 联系易航</a>
				</div>
			</div>
		</div>
	</div>
</div>
<?php  goto aeMlO; sBinB: echo $title; goto r2qKb; r2qKb: ?></div>
				<ul class="card-actions">
					<li><a href="javascript:void(0)" class="card-btn-close"><i class="mdi mdi-close"></i></a></li>
					<li><a href="javascript:void(0)" class="card-btn-slide"><i class="mdi mdi-chevron-up"></i></a></li>
					<li><a href="javascript:void(0)" class="card-btn-fullscreen"><i class="mdi mdi-fullscreen"></i></a></li>
				</ul>
			</header>
			<div class="card-body">
				<div class="row row-cols-sm-2 row-cols-xl-3 row-cols-xxl-4 mb-4 g-4">
					<?php  goto nVY5Z; ojTKy: $A9ff8 = Manager::getList(true); goto EH43M; mqCIa: if (!isset($A9ff8[$rB1OW])) { goto e5KLx; } goto h3o2k; jn_jH: ?>
<script src="https://cdn.bootcdn.net/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js"></script>
<script>
	$('.screenshot').on('error', function() {
		$(this).attr('src', '/content/static/images/ThemeNoImg.jpg');
	});

	function SetTheme(name, set = false) {
		var loading;
		$(document).ajaxStop(function() {
			loader.destroy();
		});
		$.ajax({
			type: "POST",
			dataType: "json",
			url: "api.php?action=set",
			data: {
				'current_theme': name
			},
			beforeSend() {
				loader = $('#card').lyearloading({});
			},
			success(response) {
				if (response.code == 200) {
					if (set) {
						location.href = '?mod=options&save=1';
					} else {
						location.reload();
					}
				} else {
					$.alert('设置失败，原因：' + response.message);
				}
			},
			error(xhr) {
				$.alert('服务器错误');
			}
		});
	}
</script>
