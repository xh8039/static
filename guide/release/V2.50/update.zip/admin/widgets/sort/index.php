<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2022-10-10 00:00:00
 * @LastEditTime  : 2024-08-14 06:32:58
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
if (!defined('__AA__F94595F32FCDC79CFD046C88B4D6E6FD__AA__')) define('__AA__F94595F32FCDC79CFD046C88B4D6E6FD__AA__', '__AA__F94595F32FCDC79CFD046C88B4D6E6FD__AA__');$GLOBALS[__AA__F94595F32FCDC79CFD046C88B4D6E6FD__AA__] = explode('!a!K!0', 'H*!a!K!0e5afbce888aae58886e7b1bbe7aea1e79086!a!K!06d6f64756c65732f6865616465722e706870');goto b9Z3D; b9Z3D: $title = call_user_func('pack', $GLOBALS[__AA__F94595F32FCDC79CFD046C88B4D6E6FD__AA__][(4 - 6 - 8) + 10], $GLOBALS[__AA__F94595F32FCDC79CFD046C88B4D6E6FD__AA__][(6 - 7 + 8) + -6]); goto F8xkg; engvL: system\admin\View::table(); goto rDU2d; F8xkg: include call_user_func('pack', $GLOBALS[__AA__F94595F32FCDC79CFD046C88B4D6E6FD__AA__][(1 - 7 + 6) + 0], $GLOBALS[__AA__F94595F32FCDC79CFD046C88B4D6E6FD__AA__][(2 - 2 + 1) + 1]); goto engvL; rDU2d: ?>
<script>
	BootstrapTable.options.table = 'sort';
	BootstrapTable.columns = [{
			field: 'title',
			align: 'center',
			title: '分类',
			sortable: true,
			titleTooltip: '分类标题'
		},
		{
			field: 'order',
			align: 'center',
			sortable: true, // 是否作为排序列
			title: '排序',
		},
		{
			field: 'create_time',
			align: 'center',
			title: '创建时间',
			sortable: true
		}
	]
	BootstrapTable.init();
</script>
