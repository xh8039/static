<?php

use JsonDb\JsonDb\Db;

$this->include('module/header.php', ['title' => '站点详情']);
$site = $this->getSite($site_id);
$total_view = total_view($site->id);
$month_view = month_view($site->id);
$day_view = day_view($site->id);
$star = isset($site->fields->star) ? ($site->fields->star == 'auto' ? getStarNum($total_view) : $site->fields->star) : getStarNum($total_view);
$sort = $this->getSort($site->sort_id);
$domain = getDomain($site->url);
Db::name('site')->merge('fields')->where('id', $site_id)->update([
	'fields' => [
		$this->themeName => [
			date('Y_m_d_') . 'view' => $day_view + 1,
			date('Y_m_') . 'view' => $month_view + 1,
			'total_view' => $total_view + 1
		]
	]
]);
?>
<div class="container">
	<div class="card board">
		<span class="icon"><i class="fa fa-map-signs fa-fw"></i></span>
		<?php echoBoard($site->title, $sort); ?>
	</div>
	<div class="card">
		<div class="card-body">
			<div class="site-main">
				<span class="title"><?= $site->title; ?></span>
				<span class="oz-xs-12 oz-sm-6 oz-lg-4">站点域名：<?= $domain; ?></span>
				<span class="oz-xs-12 oz-sm-6 oz-lg-4">站点星级：<img class="lazy-load" src="<?= TEMPLATE_URL; ?>assets/images/star/<?= $star ?>.png" alt=""></span>
				<span class="oz-xs-12 oz-sm-6 oz-lg-4">收录时间：<?= $site->create_time ?></span>
				<span class="oz-xs-12 oz-sm-6 oz-lg-4">备案信息：<a title="<?= $site->fields->icp ?? '暂无' ?>" href="http://icp.chinaz.com/info?q=<?= $domain; ?>" target="_blank"><?= $site->fields->icp ?? '暂无' ?></a></span>
				<span class="oz-xs-6 oz-sm-6 oz-lg-4">站长ＱＱ：<?php
					if (!empty($site->fields->qq)) {
					?>
						<a title="<?= $site->fields->qq; ?>" href="http://wpa.qq.com/msgrd?v=3&uin=<?= $site->fields->qq; ?>&site=qq&menu=yes" target="_blank"><?= $site->fields->qq; ?></a>
					<?php
					} else {
						echo '暂无';
					}
				?></span>
				<span class="oz-xs-6 oz-sm-6 oz-lg-4">所属分类：<a href="/sort/<?= $sort->id ?>.html"><?= $sort->title ?></a></span>
				<span class="oz-xs-6 oz-sm-6 oz-lg-4">日浏览数：<?= convertNum($day_view); ?>次</span>
				<span class="oz-xs-6 oz-sm-6 oz-lg-4">月浏览数：<?= convertNum($month_view); ?>次</span>
				<span class="oz-xs-6 oz-sm-6 oz-lg-4">总浏览数：<?= convertNum($total_view); ?>次</span>

				<span class="oz-xs-6 oz-sm-6 oz-lg-4">百度权重：<img class="lazy-load" src="https://baidurank.aizhan.com/api/br?domain=<?= $domain; ?>&style=images"></span>
				<span class="oz-xs-6 oz-sm-6 oz-lg-4">移动权重：<img class="lazy-load" src="https://baidurank.aizhan.com/api/mbr?domain=<?= $domain; ?>&style=images"></span>
				<span class="oz-xs-6 oz-sm-6 oz-lg-4">搜狗权重：<img class="lazy-load" src="https://sogourank.aizhan.com/api/mbr?domain=<?= $domain; ?>"></span>
				<a href="//whois.chinaz.com/?DomainName=<?= $domain; ?>" target="_blank">Whois查询</a> |
				<a href="//seo.chinaz.com/?host=<?= $domain; ?>" target="_blank">SEO综合查询</a> |
				<a href="//alexa.chinaz.com/?Domain=<?= $domain; ?>" target="_blank">Alexa排名查询</a> |
				<a href="//pr.chinaz.com/?PRAddress=<?= $domain; ?>" target="_blank">PR查询</a> |
				<a href="//tool.chinaz.com/speedtest.aspx?host=<?= $domain; ?>" target="_blank">网站测速</a> |
				<a href="//icp.chinaz.com/?s=<?= $domain; ?>" target="_blank">ICP备案查询</a> |
				<a href="//link.chinaz.com/?wd=<?= $domain; ?>" target="_blank">友情链接检测</a> |
				<a href="//rank.chinaz.com/?host=<?= $domain; ?>" target="_blank">百度权重查询</a> |
				<a href="//tool.chinaz.com/webscan/?host=<?= $domain; ?>" target="_blank">网站安全检测</a> |
				<a href="http://www.baidu.com/s?wd=site%3A<?= $domain; ?>" target="_blank">百度收录查询</a>
				</span>
			</div>
			<div class="site-side">
				<div class="snapshot">
					<img class="lazy-load" src="<?= 'https://mini.s-shot.ru/1024x768/PNG/800/?' . $site->url; ?>" src="<?= IMAGES_URL; ?>loading.gif" data-src="<?= 'https://mini.s-shot.ru/1024x768/PNG/800/?' . $site->url; ?>" alt="">
				</div>
				<a title="<?= $site->url; ?>" href="/goto/<?= $site->id ?>.html" target="_blank" class="oz-btn oz-btn-lg oz-btn-block oz-bg-orange">
					<i class="fa fa-telegram fa-fw" aria-hidden="true"></i> 网站直达
				</a>
				<button class="oz-btn oz-btn-lg oz-btn-block oz-bg-blue" onclick="addLove(this, <?= $site->id; ?>)">
					<i class="fa fa-thumbs-o-up fa-fw" aria-hidden="true"></i> 点赞 [<?= $site->fields->love ?? 0 ?>]
				</button>
			</div>
		</div>
	</div>
	<div class="card">
		<div class="card-head">
			<i class="fa fa-feed fa-fw" aria-hidden="true"></i> 站点信息
		</div>
		<div class="card-body content">
			<p><b>标题：</b><?= $site->title; ?></p>
			<p><b>关键词：</b><?= $site->keywords ?? '暂无'; ?></p>
			<p><b>描述：</b><?= $site->description ?? '暂无'; ?></p>
		</div>
		</span>
	</div>
	<div class="card">
		<div class="card-head">
			<i class="fa fa-plus-square fa-fw" aria-hidden="true"></i> 收录说明
		</div>
		<p>简单来说就是可以给您的网站提升权重排名，增加外链和网站流量！如果细分的话那么有如下几个好处！</p>
		<p>让您的网站更快、更多地被搜索引擎收录</p>
		<p>让您的网站名称的关键词在搜索引擎的搜索结果的第一页甚至第一个</p>
		<p>通过本站这个分类目录平台从而给您的网站带来巨大流量</p>
		<p>如您网站被搜索引擎屏蔽，<?= $this->site->title ?>永久缓存贵站信息，通过这个页面浏览者照样借助<?= $this->site->title ?>进入您的网站！</p>
		<br>
		<p>
			<font color="#ff0000">温馨提示：如果贵站想上百度，希望贵站能添加本页面为友情链接，感谢您对本站的支持！将下列代码添加到您的网站首页即可！</font><br>
			<span style="color: #000000; font-size: 14px;"><strong>&lt;a href="http://<?= $this->site->domain ?>" target="_blank"&gt;<?= $this->site->title ?>&lt;/a&gt;</strong>
			</span>
		</p>
	</div>
	<?php
	$advert_list = getAdverts('site_footer');
	foreach ($advert_list as $key => $value) {
		echoAd($value);
	}
	?>
	<div class="card">
		<div class="card-head">
			<i class="fa fa-magnet fa-fw" aria-hidden="true"></i> 相关站点
		</div>
		<div class="card-body">
			<?php
			$length = is_pc() ? 21 : 24;
			$site_list = Db::name('site')->where('sort_id', $sort->id)->limit(0, $length)->shuffle()->select();
			foreach ($site_list as $key => $value) {
				$site_list[$key]['fields'] = isset($value['fields'][$this->themeName]) ? $value['fields'][$this->themeName] : (object) [];
			}
			$site_list = array_to_object($site_list);
			echoSites($site_list);
			?>
		</div>
		</span>
	</div>
</div>
<script>
	//点赞功能
	function addLove(dom, id) {
		$.ajax({
			type: 'POST',
			url: '/api/site_love',
			data: {
				id
			},
			success: (result) => {
				if (result.code !== 200) {
					return layer.msg(result.msg, {
						anim: 6,
						time: 500
					})
				}
				layer.msg('点赞成功', {
					time: 500
				})
				$(dom).css({
					'pointer-events': 'none',
					'cursor': 'not-allowed',
					'opacity': 0.8
				});
				$(dom).html('<i class="fa fa-thumbs-up fa-fw active" aria-hidden="true"></i>&nbsp;已赞&nbsp;[' + result.love + ']')
			},
			error: () => {
				layer.msg('系统错误，请检查网络或联系管理员', {
					anim: 6,
					time: 1000,
				})
			}
		})
	}
</script>
<?php $this->include('module/footer.php') ?>