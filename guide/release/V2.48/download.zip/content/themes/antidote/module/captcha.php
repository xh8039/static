<?php
$_vc = new system\library\Captcha();
$_vc->doimg();
$_SESSION['captcha'] = $_vc->getCode();