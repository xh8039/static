<?php $this->include('module/header.php', ['title' => '申请收录']) ?>
<div class="container">
	<div class="card board">
		<span class="icon"><i class="fa fa-map-signs fa-fw"></i></span>
		<?php echoBoard('申请收录'); ?>
	</div>
	<div class="card">
		<div class="card-head"><i class="fa fa-plus-square fa-fw"></i>申请收录</div>
		<div class="card-body content">
			<?php // echo $page['content']; 
			?>
			<form id="apply-add" method="post" onsubmit="return false" style="margin-top: 8px">
				<div class="oz-xs-12 oz-sm-6 oz-form-group">
					<label class="oz-form-label">名称</label>
					<label class="oz-form-field">
						<input type="text" name="name" id="name" placeholder="请输入站点名称[必填]">
					</label>
				</div>
				<div class="oz-xs-12 oz-sm-6 oz-form-group">
					<label class="oz-form-label">分类</label>
					<label class="oz-form-field">
						<select name="sortId" id="sortId">
							<option value="">请选择站点分类[必选]</option>
							<?php
							$sorts = $this->getSort();
							foreach ($sorts as $sort) { ?>
								<option value="<?= $sort->id; ?>"><?= $sort->title; ?></option>
							<?php } ?>
						</select>
					</label>
				</div>
				<div class="oz-xs-12 oz-sm-6 oz-form-group">
					<label class="oz-form-label">QQ</label>
					<label class="oz-form-field">
						<input type="text" name="qq" id="qq" placeholder="请输入站长QQ号[非必填]">
					</label>
				</div>
				<div class="oz-xs-12 oz-sm-6 oz-form-group">
					<label class="oz-form-label">链接</label>
					<label class="oz-form-field">
						<select name="protocol" id="protocol">
							<option value="http://">http://</option>
							<option value="https://">https://</option>
						</select>
					</label>
					<label class="oz-form-field">
						<input type="text" name="domain" id="domain" placeholder="请输入站点域名[必填]">
					</label>
				</div>
				<div class="oz-xs-12 oz-sm-6 oz-form-group">
					<label class="oz-form-label">验证码</label>
					<label class="oz-form-field" style="flex: auto;">
						<input type="text" name="captcha" id="captcha" placeholder="请输入验证码[必填]">
					</label>
					<img id="captchaImage" src="<?= OZDAO_URL; ?>captcha.php" onclick="this.src='<?= OZDAO_URL; ?>captcha.php?'+Math.random();" alt="">
				</div>
				<div class="oz-center" style="margin-bottom: 8px">
					<button class="oz-btn oz-bg-blue" type="submit" onclick="addApply()" style="margin-right: 10px">
						<i class="fa fa-telegram fa-fw" aria-hidden="true"></i> 立即提交
					</button>
					<button class="oz-btn oz-bg-red" type="reset"><i class="fa fa-refresh fa-fw" aria-hidden="true"></i>
						重置输入
					</button>
				</div>
			</form>
		</div>
	</div>
</div>
<script>
	//申请收录
	function addApply() {
		if (checkInput([{
				id: 'name',
				msg: '请输入名称'
			}, {
				id: 'sortId',
				msg: '请选择分类'
			}, {
				id: 'sortId',
				msg: '请选择分类'
			}, {
				id: 'qq',
				msg: '请输入正确的QQ号',
				reg: qqReg,
				optional: true
			}, {
				id: 'domain',
				msg: '请输入正确的域名',
				reg: urlReg,
			}, {
				id: 'captcha',
				msg: '请输入验证码'
			}])) {
			$.ajax({
				type: 'POST',
				url: '/api/apply_add',
				data: $('#apply-add').serialize(),
				beforeSend: () => {
					layer.load(2)
				},
				success: (result) => {
					layer.closeAll('loading')
					setTimeout(() => {
						if (result.code !== 200) {
							return layer.alert('申请失败：' + result.msg, {
								anim: 6
							})
						}
						layer.msg(result.msg, {
							time: 1000
						})
					}, 250)
				},
				error: () => {
					layer.closeAll('loading')
					setTimeout(() => {
						layer.msg('系统错误，请检查网络或联系管理员', {
							anim: 6,
							time: 1000,
						})
					}, 250)
				}
			})
		}
	}
</script>

<?php $this->include('module/footer.php') ?>