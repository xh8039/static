<?php

/**
 * Antidote即解药，大方优雅的响应式模板，双栏设计，支持多个广告，有排行榜单
 *
 * @package Antidote
 * @author OZDAO
 * @version 1.0
 * @link http://nav.ouzero.com
 */

use JsonDb\JsonDb\Db;

$this->include('module/header.php', ['title' => '首页']);
$site = $this->getSites();
?>
<div class="banner" data-src="<?= empty($this->options('index_banner')) ? TEMPLATE_URL . 'assets/images/banner.jpg' : $this->options('index_banner') ?>">
	<ul class="search-type">
		<li class="title">搜索</li>
		<li class="item active" data-type="this">本站</li>
		<li class="item" data-type="baidu">百度</li>
		<li class="item" data-type="sogou">搜狗</li>
		<li class="item" data-type="360">360</li>
		<li class="item" data-type="bing">必应</li>
	</ul>
	<form class="search-form" action="/search.html" method="get">
		<input class="search-input" placeholder="请输入关键词..." name="keyword" required="required">
		<button type="submit" class="search-btn">本站搜索</button>
	</form>
</div>
<style>
	.tp_advertising {
		width: 100%;
		display: flex;
		justify-content: space-between;
		background: #fff;
		position: relative;
		box-shadow: 0 0 3px rgba(0, 0, 0, .2);
	}

	.tp_advertising p {
		color: #fff;
		font-size: 14px;
		line-height: 22px;
		background: #6F8EC5;
		position: absolute;
		bottom: 0;
		right: 0;
		margin: 0;
		padding: 0 8px;
		border-top-left-radius: 10px;
		opacity: .3;
	}

	.tp_advertising div {
		width: 16.66%;
		position: relative;
		z-index: 1;
	}

	.tp_advertising a {
		font-size: 12px;
		line-height: 22px;
		text-align: center;
		display: block;
		text-decoration: none;
		white-space: nowrap;
	}

	.tp_advertising a:hover {
		font-weight: bold;
		font-size: 14px;
		text-shadow: 0px 0px 1px rgba(0, 0, 0, .5);
	}

	.tp_1 a {
		color: #FF0033;
	}

	.tp_2 a {
		color: #9400D3;
	}

	.tp_3 a {
		color: #00BFFF;
	}

	.tp_4 a {
		color: #FF1493;
	}

	.tp_5 a {
		color: #FF4500;
	}

	.tp_6 a {
		color: #5fb878;
	}
</style>

<?php
if (options('sponsor')) {
?>
	<div class="tp_advertising">
		<p>网站赞助广告商</p>
		<?php
		$advert_list = (array) getAdverts('index_top');
		// halt($advert_list);
		if (!empty($advert_list)) {
			$result = array_chunk($advert_list, ceil(count($advert_list) / 6));
			for ($i = 0; $i < 5; $i++) {
				if (empty($result[$i])) {
					$result[$i] = [];
					$data = new class
					{
						public $url =  '/';
						public $title = '网站赞助';
					};
					for ($s = 0; $s < 7; $s++) {
						$result[$i][$s] = $data;
					}
				}
			}
			foreach ($result as $key => $value) {
				if ($key <= 4) {
					for ($i = 0; $i < 7; $i++) {
						if (empty($value[$i])) {
							$value[$i] = new class
							{
								public $url =  '/';
								public $title = '网站赞助';
							};
						}
					}
		?>
					<div class="tp_<?= $key + 1 ?>">
						<?php
						foreach ($value as $k => $v) {
						?>
							<a href="<?= $v->url ?>" target="_blank"><?= $v->title ?></a>
						<?php
						}
						?>
					</div>
			<?php
				}
			}
		} else {
			?>
			<div class="tp_1">
				<a href="/" target="_blank">网站赞助</a>
				<a href="/" target="_blank">网站赞助</a>
				<a href="/" target="_blank">网站赞助</a>
				<a href="/" target="_blank">网站赞助</a>
				<a href="/" target="_blank">网站赞助</a>
				<a href="/" target="_blank">网站赞助</a>
			</div>
			<div class="tp_2">
				<a href="/" target="_blank">网站赞助</a>
				<a href="/" target="_blank">网站赞助</a>
				<a href="/" target="_blank">网站赞助</a>
				<a href="/" target="_blank">网站赞助</a>
				<a href="/" target="_blank">网站赞助</a>
				<a href="/" target="_blank">网站赞助</a>
			</div>
			<div class="tp_3">
				<a href="/" target="_blank">网站赞助</a>
				<a href="/" target="_blank">网站赞助</a>
				<a href="/" target="_blank">网站赞助</a>
				<a href="/" target="_blank">网站赞助</a>
				<a href="/" target="_blank">网站赞助</a>
				<a href="/" target="_blank">网站赞助</a>
			</div>
			<div class="tp_4">
				<a href="/" target="_blank">网站赞助</a>
				<a href="/" target="_blank">网站赞助</a>
				<a href="/" target="_blank">网站赞助</a>
				<a href="/" target="_blank">网站赞助</a>
				<a href="/" target="_blank">网站赞助</a>
				<a href="/" target="_blank">网站赞助</a>
			</div>
			<div class="tp_5">
				<a href="/" target="_blank">网站赞助</a>
				<a href="/" target="_blank">网站赞助</a>
				<a href="/" target="_blank">网站赞助</a>
				<a href="/" target="_blank">网站赞助</a>
				<a href="/" target="_blank">网站赞助</a>
				<a href="/" target="_blank">网站赞助</a>
			</div>
		<?php
		}
		?>
	</div>
<?php
}
?>
<div class="container">
	<ul class="sort">
		<li><a href="#置顶站点" class="move"><span>置顶推荐</span> <i class="fa fa-thumbs-o-up fa-fw"></i></a></li>
		<?php echoSideSorts($this->getSort()); ?>
	</ul>
	<div id="main">
		<div class="card board">
			<span class="icon"><i class="fa fa-bullhorn fa-fw"></i></span>
			<marquee scrollamount="4" behavior="scroll" onmouseover="this.stop()" onmouseout="this.start()"><?= $this->options->notice ?></marquee>
		</div>
		<!--网站统计-->
		<div class="card">
			<b>
				<center>
					<a style="height: 50px;  line-height: 40px; margin-top: 0px; padding: 0 15px; font-size: 13px;font-weight: 300;color: #535b5f;background-color: #ffffff;">
						<b>共计收录：<font color="red"><strong><?= count($site) ?></strong> 个</font> - 待审网站：<font color="#03f">
								<strong><?= Db::name('site')->where('status', 0)->count() ?></strong> 个
							</font>
							- 本站已稳定运行了：<font color="green">
								<strong>
									<script>
										var urodz = new Date(<?= strtotime($this->site->create_date) * 1000; ?>);
										var now = new Date();
										var ile = now.getTime() - urodz.getTime();
										var dni = Math.floor(ile / (1000 * 60 * 60 * 24));
										document.write(+dni)
									</script>
								</strong> 天
							</font>
						</b>
					</a>
				</center>
			</b>
		</div>
		<!--网站统计-->
		<div id="置顶站点" class="card">
			<div class="card-head">
				<i class="fa fa-thumbs-o-up fa-fw"></i>
				<font style="color:blue;font-weight:700;">置顶站点 <?= $this->options('top_price') ?><a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=<?= $this->options('qq') ?>&site=qq&menu=yes"><img border="0" src="http://wpa.qq.com/pa?p=2:5133948:51" alt="点击这里给我发消息" title="点击这里给我发消息" /></font></a><a href="apply.html" class="more"><i class="fa fa-plus-square" aria-hidden="true"></i>申请收录</a>
			</div>
			<div class="card-body">
				<?php echoSites($this->getSites(null, ['top' => 1]), true) ?>
			</div>
			<?php
			$advert_list = getAdverts('index_header');
			foreach ($advert_list as $key => $value) {
				echoAd($value);
			}
			?>
		</div>
		<?php
		$sorts = $this->getSortSites();
		foreach ($sorts as $sort) { ?>
			<div id="<?= $sort->title; ?>" class="card">
				<div class="card-head">
					<i class="<?= isset($sort->fields->icon) ? $sort->fields->icon : null ?>"></i><?= $sort->title; ?>
					<a href="/sort/<?= $sort->id ?>.html" class="more"><i class="fa fa-ellipsis-h fa-fw"></i></a>
				</div>
				<div class="card-body">
					<?php echoSites($sort->sites); ?>
				</div>
			</div>
		<?php } ?>
	</div>

	<div id="side">
		<div class="card">
			<div class="card-head"><i class="fa fa-line-chart fa-fw"></i>今日TOP10</div>
			<div class="card-body">
				<?php echoSiteRanking(site_ranking('day', 10), 'day') ?>
			</div>
		</div>
		<div class="card">
			<div class="card-head"><i class="fa fa-coffee fa-fw"></i>最新收录</div>
			<div class="card-body">
				<div class="side-latest oz-timeline">
					<?php echoLatestSites(getLatestSites(5)); ?>
				</div>
			</div>
		</div>
		<div class="card">
			<div class="card-head"><i class="fa fa-pie-chart fa-fw"></i>热度统计</div>
			<div class="card-body side-statistic">
				<?php echoStatistics() ?>
			</div>
		</div>
		<!-- <div class="card">
			<div class="card-head"><i class="fa fa-folder-open fa-fw"></i>文章分类</div>
			<div class="card-body">
				<?php //  echoPostSorts($DATA->getPostSorts()); 
				?>
			</div>
		</div> -->
		<!-- <div class="card">
			<div class="card-head"><i class="fa fa-leaf fa-fw"></i>最新文章</div>
			<div class="card-body">
				<?php // echoPosts($DATA->getLatestPosts(10), true); 
				?>
			</div>
		</div> -->
		<?php
		$advert_list = getAdverts('index_footer');
		foreach ($advert_list as $key => $value) {
			echoAd($value);
		}
		?>
		<div class="card">
			<div class="card-head"><i class="fa fa-telegram fa-fw"></i>联系方式</div>
			<div class="card-body content">
				<p>站长QQ：<a href="http://wpa.qq.com/msgrd?v=3&uin=<?= $this->options->qq; ?>&site=qq&menu=yes" target="_blank"><?= $this->options->qq ?></a></p>
				<p>交流Ｑ群：<a href="<?= $this->options->qq_group_url ?>" target="_blank"><?= $this->options->qq_group ?></a></p>
				<p>站长邮箱：<a href="mailto:<?= $this->options->email ?>"><?= $this->options->email ?></a></p>
			</div>
		</div>
	</div>
</div>

<div class="card links">
	<div class="card-head"><i class="fa fa-link fa-fw"></i>友情链接 申请友链：<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=<?= $this->options->qq ?>&site=qq&menu=yes"><img border="0" src="http://wpa.qq.com/pa?p=2:5133948:51" alt="点击这里给我发消息" title="点击这里给我发消息" /></a></a></div>
	<div class="card-body">
		<?php echoLinks($this->getFriend()); ?>
	</div>
</div>
</div>

<?php $this->include('module/footer.php') ?>