<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-25 08:48:31
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 $lJkTI = isset($_GET["\x6d\x6f\144"]) ? $_GET["\x6d\157\x64"] : "\x69\x6e\x64\145\170"; require "\x77\x69\x64\x67\145\x74\163\57\163\151\x74\x65\x2f" . $lJkTI . "\56\x70\x68\160";
