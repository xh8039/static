<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-25 08:48:31
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 use system\admin\Form; goto o7NZq; o7NZq: $title = "\346\226\260\xe5\242\236\345\217\x8b\346\x83\205\351\x93\276\346\216\xa5"; goto AWEHm; Yjcmy: echo Form::form("\x69\x6e\163\145\162\x74\x54\141\x62\154\x65", ["\x74\x61\142\x6c\145" => "\x66\x72\x69\x65\156\x64\x73"], $wC5IS, "\xe6\x96\260\345\xa2\x9e\345\x8f\213\xe9\x93\276"); goto HY2yz; eRtzY: $wC5IS = implode(PHP_EOL, $wC5IS); goto Yjcmy; o7m7Q: $wC5IS = [Form::text("\xe7\xab\x99\xe7\x82\xb9\xe6\240\x87\351\xa2\x98", "\164\x69\x74\154\x65", null, null, ["\162\145\x71\165\x69\162\x65\x64" => true]), Form::input("\xe7\xab\x99\347\202\271\xe9\x93\xbe\346\x8e\245", "\x75\162\154", null, "\165\x72\x6c", null, ["\162\x65\x71\165\151\x72\145\144" => true]), Form::textarea("\347\253\231\xe7\x82\271\347\256\x80\xe4\273\x8b", "\144\x65\163\x63\x72\x69\x70\x74\x69\157\x6e"), Form::input("\xe7\xab\231\xe7\202\xb9\xe5\x85\xb3\351\224\256\350\xaf\x8d", "\x6b\x65\x79\167\157\x72\144\x73"), Form::input("\xe7\253\231\347\x82\xb9\x46\141\x76\151\x63\x6f\x6e", "\146\x61\166\151\143\157\x6e", null, "\165\x72\154", "\347\xab\x99\xe7\x82\xb9\106\141\x76\151\143\x6f\156\345\233\xbe\xe6\xa0\207\351\223\276\346\216\xa5"), Form::input("\x72\145\154\xe5\xb1\x9e\xe6\x80\xa7", "\162\x65\x6c", "\146\162\x69\x65\156\144", "\164\x65\x78\x74", "\xe4\xbe\x8b\345\246\202\357\274\232\x6e\x6f\x66\157\x6c\x6c\157\x77\xef\274\x88\xe6\263\xa8\351\x87\212\357\274\232\344\270\215\344\274\xa0\xe9\x80\x92\346\220\234\347\xb4\242\345\274\225\xe6\x93\216\xe6\x9d\x83\351\207\215\xef\xbc\x89"), Form::hidden("\x73\x74\x61\x74\x75\x73", 1)]; goto eRtzY; AWEHm: include "\x6d\x6f\144\x75\x6c\145\x73\x2f\x69\146\x72\x61\155\145\56\x70\150\x70"; goto o7m7Q; HY2yz: include "\x6d\x6f\144\x75\x6c\x65\163\x2f\146\157\157\x74\x65\x72\56\160\x68\x70";
