<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-25 08:48:31
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 use system\admin\Form; use system\plugin\Manager; goto MRHxY; MRHxY: $title = "\xe6\x8f\222\xe4\xbb\xb6\xe8\xae\xbe\347\xbd\256"; goto K3XpL; LFQRL: include_once ROOT . "\163\x79\163\x74\145\x6d\x2f\x70\154\x75\x67\x69\x6e\57\x46\x72\x6f\155\x2e\x70\150\x70"; goto luLP0; luLP0: $u0EPk = "\x70\x6c\165\147\x69\156\123\145\164"; goto u7pOi; K3XpL: include "\155\x6f\x64\x75\154\x65\163\x2f\151\x66\x72\141\x6d\x65\x2e\x70\150\x70"; goto LFQRL; VlR4Q: goto S01LI; goto B0ZJe; soXKa: echo "\xe6\x8f\x92\xe4\xbb\266\x20" . $ry735["\x74\x69\164\x6c\x65"] . "\x20\xe6\232\202\xe6\x97\240\xe8\x87\252\xe5\xae\232\xe4\xb9\x89\350\xae\276\xe7\xbd\256"; goto j9zyt; mcNso: echo Form::form("\160\x6c\x75\147\x69\156\x53\x65\x74", ["\x70\154\x75\x67\x69\156" => $_GET["\x6e\141\155\x65"]], $wC5IS); goto VlR4Q; B0ZJe: nerbY: goto soXKa; kDfFi: $wC5IS = implode(PHP_EOL, $wC5IS); goto mcNso; gh3Jf: $title = $ry735["\164\x69\x74\x6c\145"] . $title; goto fLY49; j9zyt: S01LI: goto MVDAu; fLY49: if (empty($wC5IS)) { goto nerbY; } goto kDfFi; W94Vb: $wC5IS = (function () use($ry735) { goto aTlsK; LlcQB: $wC5IS = empty($wC5IS->html) ? [] : $wC5IS->html; goto Ytnaf; XucWb: $gVFOm = PLUGINS_ROOT . $ry735["\156\x61\x6d\x65"] . DIR_SEP . "\x50\154\165\x67\151\156\x2e\160\150\160"; goto AiJPM; z4K5B: return $wC5IS; goto B0IDo; J_Tle: $wC5IS = $ry735["\x63\x6c\141\x73\163"]::config(new system\plugin\Form($ry735["\156\141\155\x65"])); goto LlcQB; aTlsK: $wC5IS = []; goto XucWb; xx7J7: p_f_k: goto z4K5B; Ytnaf: vcE6m: goto xx7J7; AiJPM: if (!is_file($gVFOm)) { goto p_f_k; } goto QBDMj; j2DVi: if (!method_exists($ry735["\x63\x6c\x61\x73\163"], "\x63\157\156\x66\151\x67")) { goto vcE6m; } goto J_Tle; QBDMj: include_once $gVFOm; goto j2DVi; B0IDo: })(); goto gh3Jf; u7pOi: $ry735 = Manager::getInfo($_GET["\156\141\155\145"], true); goto W94Vb; MVDAu: include "\155\157\x64\x75\x6c\x65\x73\x2f\146\157\x6f\x74\145\x72\56\160\150\160";
