<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-25 08:48:31
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 goto UCDax; tAOrr: include "\155\x6f\x64\x75\154\145\x73\57\x69\146\x72\x61\155\x65\56\160\150\160"; goto JgElo; JgElo: echo "\x3c\x70\x3e\345\217\xaa\xe8\203\xbd\346\211\x8b\345\212\250\346\xb7\xbb\xe5\212\xa0\xe6\x8f\222\344\xbb\xb6\xe5\x93\xa6\x3c\57\160\76\xd\xa"; goto TAC2J; UCDax: $title = "\346\226\xb0\345\242\x9e\xe6\x8f\222\344\xbb\266"; goto tAOrr; TAC2J: include "\x6d\157\x64\165\x6c\145\x73\x2f\146\x6f\157\x74\145\162\x2e\x70\x68\160";
