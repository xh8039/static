<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-25 08:48:31
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 use system\admin\Form; use system\admin\View; goto LrkrZ; u2wrJ: $aJINm = \system\admin\Admin::info(); goto YRSHn; q47vJ: View::form($title, "\165\x70\144\141\164\x65\124\141\x62\x6c\145", ["\164\x61\x62\154\145" => $u0EPk], $wC5IS); goto v1QU1; yygrR: include "\155\157\144\x75\x6c\145\163\57\150\x65\141\144\x65\162\x2e\x70\150\x70"; goto EUg3_; LrkrZ: $title = "\346\233\xb4\xe6\226\260\350\xb4\xa6\345\217\267\xe4\277\xa1\346\x81\257"; goto yygrR; EUg3_: $u0EPk = "\x61\144\x6d\151\156"; goto u2wrJ; YRSHn: $wC5IS = [Form::hidden("\151\x64", $aJINm["\x69\144"]), Form::input("\347\224\xa8\346\x88\267\xe5\x90\215", "\x75\163\x65\x72", $aJINm["\x75\163\x65\162"], "\x74\x65\x78\x74", null, ["\162\x65\x71\165\151\162\145\144" => true]), Form::input("\346\230\xb5\347\xa7\260", "\x6e\x61\155\x65", $aJINm["\156\x61\x6d\x65"]), Form::input("\xe9\x82\256\347\256\261", "\x65\x6d\141\x69\x6c", $aJINm["\x65\x6d\141\151\154"]), Form::input("\121\121\xe5\217\xb7", "\161\161", $aJINm["\161\x71"])]; goto q47vJ; v1QU1: include "\x6d\x6f\144\x75\x6c\x65\163\57\146\x6f\157\164\x65\162\56\160\150\x70";
