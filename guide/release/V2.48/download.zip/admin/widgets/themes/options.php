<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-25 08:48:31
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 use system\admin\View; use system\theme\Manager; goto xmQSa; D5wsi: include "\155\x6f\144\165\x6c\145\163\57\146\157\157\164\145\162\56\x70\150\x70"; goto bJG4L; whaKa: $PI602 = Manager::getInfo(); goto xEOMM; xmQSa: $title = "\xe4\xb8\273\351\xa2\x98\350\xae\276\347\275\256"; goto D1CkT; xEOMM: View::card($PI602["\164\151\164\154\145"] . $title, function () { goto TyJJB; M3MXt: d2Gu3: goto RfUTJ; RfUTJ: define("\124\x48\x45\115\105\x5f\123\x45\124", true); goto P7a40; TyJJB: if (Manager::needFile("\x70\x75\x62\154\151\x63\x2f\x66\x75\x6e\143\164\151\157\156\163") && function_exists("\x74\150\x65\155\145\x5f\x63\157\x6e\x66\151\x67")) { goto d2Gu3; } goto OdVr1; P7a40: echo "\x9\11\x3c\x66\157\162\155\x20\141\143\x74\151\x6f\x6e\x3d\42\141\160\151\56\160\x68\160\x3f\x61\x63\164\x69\157\156\75\164\150\x65\x6d\145\x53\145\x74\x22\40\155\x65\x74\x68\157\x64\x3d\x22\x70\157\x73\x74\x22\x20\143\x6c\x61\163\x73\x3d\x22\164\x68\x65\155\x65\123\x65\x74\42\x3e\15\xa\11\11\x9"; goto EsBxn; EsBxn: theme_config(new \system\theme\Form()); goto lSYZk; sOhOQ: g6DF7: goto kJMnW; lSYZk: echo "\x9\x9\11\x3c\x64\151\166\40\x63\154\x61\163\x73\x3d\42\x64\x2d\147\162\x69\x64\x22\x3e\xd\12\x9\x9\11\11\74\x62\165\x74\x74\x6f\156\40\164\171\160\x65\x3d\42\163\x75\x62\155\151\164\x22\x20\x63\154\141\163\x73\x3d\42\142\x74\x6e\x20\x62\x74\x6e\x2d\x70\x72\151\155\141\x72\x79\x22\x3e\xe4\277\235\xe5\255\x98\344\xb8\xbb\351\242\x98\350\xae\xbe\xe7\xbd\xae\x3c\x2f\x62\x75\164\x74\x6f\x6e\x3e\xd\xa\11\x9\11\74\x2f\144\x69\x76\76\xd\12\11\11\74\x2f\146\x6f\x72\x6d\76\15\xa"; goto sOhOQ; OdVr1: echo "\xe6\234\xac\xe4\270\273\351\xa2\x98\xe6\232\x82\xe6\x97\240\xe8\207\252\xe5\xae\x9a\344\271\211\xe8\256\xbe\xe7\xbd\256"; goto hEreZ; hEreZ: goto g6DF7; goto M3MXt; kJMnW: }); goto D5wsi; D1CkT: include "\155\x6f\x64\165\x6c\145\163\57\x68\145\141\x64\x65\x72\56\160\x68\160"; goto whaKa; bJG4L: echo system\admin\Form::script("\164\x68\x65\155\145\123\145\x74", "\xe4\xbf\x9d\345\255\x98\344\270\xbb\xe9\xa2\230\xe8\xae\276\xe7\xbd\256");
