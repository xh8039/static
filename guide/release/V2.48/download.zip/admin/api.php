<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-25 08:48:31
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 use system\library\Json; goto fF0uW; iixXx: if (is_string($h65Y8)) { goto atFA2; } goto INsIO; LSwAt: system\admin\Api::init(); goto nko0G; yr9zX: $YqgXr = isset($_GET["\141\143\164\151\157\156"]) ? $_GET["\141\x63\164\x69\x6f\156"] : "\151\156\144\x65\170"; goto LSwAt; B8b_f: atFA2: goto duWRp; duWRp: echo $h65Y8; goto clK5v; nko0G: $h65Y8 = system\admin\Api::$YqgXr(); goto iixXx; fF0uW: require_once $_SERVER["\x44\x4f\x43\125\x4d\x45\116\124\x5f\x52\117\x4f\x54"] . "\x2f\x70\165\142\154\151\x63\x2f\143\157\x6d\x6d\157\156\56\160\x68\x70"; goto yr9zX; c2G6N: goto lI00m; goto B8b_f; INsIO: Json::echo($h65Y8); goto c2G6N; clK5v: lI00m:
