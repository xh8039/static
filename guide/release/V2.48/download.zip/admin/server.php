<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2020-09-29 13:18:36
 * @LastEditTime  : 2022-10-26 21:46:06
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
if(!defined('AAA______'))define('AAA______', '_AAAAAAA_');$GLOBALS[AAA______]=explode('|6|,|?', 'H*|6|,|?687474705F726573706F6E73655F636F6465|6|,|?444F43554D454E545F524F4F54|6|,|?2F7075626C69632F636F6D6D6F6E2E706870|6|,|?7472696D|6|,|?616374696F6E|6|,|?696E646578|6|,|?69735F6172726179|6|,|?69735F6F626A656374|6|,|?656E636F6465');unset($D0NFdBs);$D0NFdBs; use system\library\Json;goto hb85TV5Dpj;IgAQbUR31l:$PF6KEJA=$DSjAqV0;$action=$PF6KEJA;unset($K7aQMBn);unset($ASPSaD9);goto LebwIRp2Vq;goto RjYY5HdksQ;hb85TV5Dpj:goto dSQAUtdEzT;LebwIRp2Vq:$ASPSaD9=system\admin\Server::$action();$K7aQMBn=$ASPSaD9;unset($PLlGbFU);goto ymFbj4CMyz;autgCxxauy:goto bWzxVDryOA;CdX3erSFhE:http_response_code(0x00000194);goto k4tOBy467B;pBOPE616fS:goto m5ZnuciwSp;l0GurG0G6R:if(empty($return)){goto e2TDvbM9__;}goto pBOPE616fS;e2TDvbM9__:goto CdX3erSFhE;dSQAUtdEzT:goto rZDvhCV0yX;rZDvhCV0yX:require $_SERVER[call_user_func("\x70\x61\x63\x6b", $GLOBALS[AAA______][(5+6+7-18)*0], $GLOBALS[AAA______][0x0002])].call_user_func("\x70\x61\x63\x6b", $GLOBALS[AAA______][(5+6+7-18)*0], $GLOBALS[AAA______][0x00003]);unset($DSjAqV0);unset($BUm9n5L);$BUm9n5L=trim($_GET[pack($GLOBALS[AAA______][3*9-27],$GLOBALS[AAA______][0x05])]?? pack($GLOBALS[AAA______][15-5+7-17],$GLOBALS[AAA______][0x006]));$DSjAqV0=$BUm9n5L;goto autgCxxauy;EoJuXNO805:goto M9fF1l1pdv;w_cTR2SuIm:goto SiG7kOhXzR;m5ZnuciwSp:echo $return;goto w_cTR2SuIm;kFo8i1i3Vj:if(is_array($return)|| is_object($return)){goto tEKyBbboIN;}goto hR2lw_wnLp;goto U7X00cCT4e;RjYY5HdksQ:M9fF1l1pdv:unset($HLsIC4I);$HLsIC4I=$TPYZySN;$return=$HLsIC4I;hR2lw_wnLp:goto l0GurG0G6R;U7X00cCT4e:tEKyBbboIN:unset($TPYZySN);unset($NYE6N0o);$NYE6N0o=Json::{call_user_func("\x70\x61\x63\x6b", $GLOBALS[AAA______][6/2*3-9], $GLOBALS[AAA______][0x000009])}($return);$TPYZySN=$NYE6N0o;goto EoJuXNO805;ymFbj4CMyz:$PLlGbFU=$K7aQMBn;$return=$PLlGbFU;goto kFo8i1i3Vj;bWzxVDryOA:unset($PF6KEJA);goto IgAQbUR31l;SiG7kOhXzR:k4tOBy467B:
?>