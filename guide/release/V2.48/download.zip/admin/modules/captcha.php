<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-25 08:48:31
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 goto I4uit; GV4JU: require $_SERVER["\x44\x4f\x43\x55\x4d\x45\x4e\x54\137\122\117\117\124"] . "\x2f\163\x79\163\x74\145\155\x2f\154\x69\142\x72\x61\162\x79\57\x43\x61\160\x74\143\150\x61\56\x70\150\160"; goto Pu3Pm; I4uit: session_start(); goto GV4JU; nv3n6: $lfxDk->doimg(); goto l5ETH; Pu3Pm: $lfxDk = new system\library\Captcha(); goto nv3n6; l5ETH: $_SESSION["\141\x64\155\151\x6e\137\x63\141\x70\164\143\150\141"] = $lfxDk->getCode();
