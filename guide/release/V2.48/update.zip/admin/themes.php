<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-25 06:19:05
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 $GyART = isset($_GET["\x6d\157\144"]) ? $_GET["\x6d\x6f\144"] : "\151\156\x64\x65\170"; require "\167\x69\x64\147\x65\x74\163\x2f\164\x68\145\155\145\x73\57" . $GyART . "\x2e\160\x68\x70";
