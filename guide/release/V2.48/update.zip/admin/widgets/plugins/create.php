<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-25 06:19:05
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 goto hfK1K; PLF3y: include "\x6d\157\144\165\154\145\x73\57\x69\146\162\141\155\145\x2e\160\x68\160"; goto uZmrx; uZmrx: echo "\x3c\x70\x3e\xe5\x8f\252\350\203\xbd\346\x89\x8b\xe5\212\xa8\346\xb7\273\xe5\x8a\240\xe6\217\222\xe4\xbb\xb6\xe5\223\xa6\x3c\x2f\x70\x3e\15\12"; goto rcwOr; hfK1K: $title = "\xe6\226\260\xe5\xa2\236\346\x8f\x92\344\273\xb6"; goto PLF3y; rcwOr: include "\x6d\157\x64\165\x6c\x65\163\x2f\x66\x6f\157\x74\145\x72\x2e\160\150\x70";
