<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-25 06:19:05
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 use system\admin\Form; use system\plugin\Manager; goto mqBOl; V7XPn: if (empty($WtzHp)) { goto J85OL; } goto tDit2; Bnxwa: echo Form::form("\x70\x6c\165\x67\151\x6e\x53\x65\164", ["\x70\x6c\x75\x67\151\156" => $_GET["\156\141\x6d\145"]], $WtzHp); goto YsM9I; NQb8L: $WtzHp = (function () use($fuE_D) { goto gkz_f; AS7Y_: if (!is_file($ul2gZ)) { goto x91tI; } goto KGfiu; KGfiu: include_once $ul2gZ; goto cqD5V; P78qx: $WtzHp = empty($WtzHp->html) ? [] : $WtzHp->html; goto DEzfo; RAErM: $ul2gZ = PLUGINS_ROOT . $fuE_D["\156\x61\155\x65"] . DIR_SEP . "\x50\x6c\x75\147\x69\156\x2e\160\150\x70"; goto AS7Y_; ioE20: return $WtzHp; goto QbIuf; cqD5V: if (!method_exists($fuE_D["\x63\154\141\x73\x73"], "\x63\157\156\146\151\147")) { goto mSe8p; } goto O_GBj; DEzfo: mSe8p: goto BLNb7; gkz_f: $WtzHp = []; goto RAErM; O_GBj: $WtzHp = $fuE_D["\143\154\x61\163\x73"]::config(new system\plugin\Form($fuE_D["\x6e\x61\155\145"])); goto P78qx; BLNb7: x91tI: goto ioE20; QbIuf: })(); goto TZYBz; IXXMP: echo "\346\x8f\x92\xe4\xbb\xb6\40" . $fuE_D["\164\151\164\154\145"] . "\40\xe6\232\x82\346\x97\240\xe8\x87\252\xe5\xae\x9a\xe4\271\211\xe8\256\276\347\xbd\256"; goto OSC16; bXBSS: $B26nm = "\x70\x6c\165\147\151\x6e\123\x65\164"; goto xJxa8; mqBOl: $title = "\xe6\x8f\x92\xe4\xbb\xb6\350\xae\xbe\347\xbd\xae"; goto VbDtL; VbDtL: include "\155\x6f\144\x75\x6c\145\163\x2f\x69\x66\x72\141\x6d\x65\56\x70\150\x70"; goto StXVr; StXVr: include_once ROOT . "\163\x79\x73\164\145\155\57\x70\154\165\147\x69\156\57\x46\162\x6f\x6d\56\x70\x68\160"; goto bXBSS; xJxa8: $fuE_D = Manager::getInfo($_GET["\x6e\141\x6d\145"], true); goto NQb8L; YsM9I: goto tAqNf; goto YfGxG; TZYBz: $title = $fuE_D["\164\x69\x74\154\145"] . $title; goto V7XPn; tDit2: $WtzHp = implode(PHP_EOL, $WtzHp); goto Bnxwa; YfGxG: J85OL: goto IXXMP; OSC16: tAqNf: goto UUlcs; UUlcs: include "\x6d\x6f\144\165\x6c\x65\163\57\x66\x6f\x6f\x74\145\162\56\x70\x68\x70";
