<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-25 06:19:05
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 use system\admin\View; use system\theme\Manager; goto mFBUz; TK53R: include "\x6d\x6f\x64\165\154\x65\163\x2f\146\157\157\164\x65\x72\56\160\150\160"; goto gPDAV; WpkoX: View::card($o3oZe["\x74\151\x74\x6c\145"] . $title, function () { goto oprzL; LXyWi: echo "\x9\x9\74\x66\157\162\x6d\40\x61\143\x74\151\x6f\156\x3d\x22\141\160\x69\x2e\x70\150\160\x3f\141\143\164\x69\x6f\156\75\164\x68\x65\x6d\x65\123\145\x74\x22\x20\155\x65\164\150\157\144\75\x22\160\157\163\164\42\40\x63\154\141\x73\163\x3d\42\164\150\145\x6d\145\123\x65\x74\42\x3e\xd\xa\x9\x9\x9"; goto Tm8_7; bcpSv: goto oIbPv; goto lkAXG; yM0Y2: echo "\xe6\234\xac\344\xb8\273\xe9\242\x98\xe6\232\202\xe6\227\xa0\350\x87\252\xe5\256\232\344\271\211\350\xae\xbe\xe7\xbd\256"; goto bcpSv; KI4NY: oIbPv: goto wvzcR; O_gwP: define("\x54\x48\105\x4d\105\137\x53\x45\x54", true); goto LXyWi; oprzL: if (Manager::needFile("\x70\x75\x62\154\151\x63\x2f\x66\x75\x6e\143\x74\x69\x6f\x6e\163") && function_exists("\x74\150\145\155\145\137\x63\x6f\156\x66\151\147")) { goto L1jcg; } goto yM0Y2; lkAXG: L1jcg: goto O_gwP; Tm8_7: theme_config(new \system\theme\Form()); goto ihw_O; ihw_O: echo "\x9\11\x9\x3c\144\151\166\x20\143\154\141\x73\163\75\42\144\x2d\147\x72\x69\x64\42\76\15\12\11\x9\11\x9\x3c\x62\165\164\164\x6f\x6e\40\x74\171\x70\x65\75\42\163\x75\x62\x6d\151\x74\42\x20\x63\154\141\x73\163\x3d\42\142\x74\156\x20\x62\164\x6e\55\x70\x72\x69\x6d\141\162\171\x22\x3e\xe4\xbf\x9d\xe5\xad\x98\xe4\270\xbb\351\242\230\xe8\256\xbe\xe7\275\256\74\x2f\x62\165\164\x74\x6f\x6e\x3e\15\12\x9\11\x9\x3c\57\144\x69\x76\x3e\15\12\11\x9\x3c\57\x66\x6f\162\x6d\x3e\xd\xa"; goto KI4NY; wvzcR: }); goto TK53R; mFBUz: $title = "\344\270\xbb\xe9\xa2\x98\xe8\xae\276\347\xbd\xae"; goto aA8Rf; aA8Rf: include "\155\x6f\144\165\x6c\x65\x73\57\150\145\141\x64\145\162\x2e\x70\150\x70"; goto U3CCs; U3CCs: $o3oZe = Manager::getInfo(); goto WpkoX; gPDAV: echo system\admin\Form::script("\164\150\x65\x6d\145\123\x65\164", "\xe4\xbf\235\345\xad\x98\344\xb8\xbb\351\xa2\x98\350\xae\276\xe7\275\256");
