<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-25 06:19:05
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 use system\admin\Form; use system\admin\View; goto J_b6g; LXeps: View::form($title, "\165\160\144\141\x74\145\124\x61\142\x6c\145", ["\x74\141\x62\x6c\x65" => $B26nm], $WtzHp); goto DxS3N; Sefs2: $B26nm = "\x61\144\155\x69\x6e"; goto s00o2; s00o2: $ysiu0 = \system\admin\Admin::info(); goto zOZ9g; J_b6g: $title = "\346\233\264\346\226\xb0\350\xb4\246\345\217\267\xe4\277\xa1\346\x81\257"; goto Cw7rC; zOZ9g: $WtzHp = [Form::hidden("\x69\x64", $ysiu0["\151\x64"]), Form::input("\347\x94\250\346\x88\xb7\xe5\220\215", "\165\163\x65\162", $ysiu0["\x75\x73\145\162"], "\164\145\x78\x74", null, ["\x72\x65\x71\x75\x69\x72\145\x64" => true]), Form::input("\xe6\x98\xb5\xe7\xa7\260", "\x6e\x61\155\145", $ysiu0["\x6e\x61\x6d\x65"]), Form::input("\xe9\x82\xae\xe7\xae\261", "\x65\x6d\x61\x69\x6c", $ysiu0["\x65\155\x61\151\x6c"]), Form::input("\x51\121\345\x8f\267", "\161\161", $ysiu0["\161\x71"])]; goto LXeps; Cw7rC: include "\x6d\x6f\144\x75\154\x65\x73\57\150\x65\x61\x64\145\162\56\x70\x68\x70"; goto Sefs2; DxS3N: include "\x6d\157\x64\x75\x6c\145\x73\57\x66\157\x6f\x74\x65\162\x2e\160\x68\160";
