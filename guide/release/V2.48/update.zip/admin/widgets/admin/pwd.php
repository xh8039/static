<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-25 06:19:05
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 use system\admin\Form; use system\admin\View; goto NqLXX; r75U0: $WtzHp = [Form::input("\xe6\x97\xa7\345\xaf\x86\xe7\240\201", "\x6f\x6c\x64\160\x77\144", null, "\160\141\163\x73\167\x6f\162\x64", null, ["\162\145\161\165\x69\162\x65\144" => true, "\x63\154\x61\x73\x73" => "\x66\x6f\x72\155\55\143\x6f\156\x74\x72\x6f\x6c"]), Form::input("\346\226\xb0\345\xaf\x86\347\240\201", "\156\x65\167\160\x77\x64", null, "\160\141\x73\163\x77\157\x72\144", null, ["\x72\145\x71\165\x69\x72\x65\144" => true, "\x63\x6c\141\163\x73" => "\x66\157\x72\155\x2d\143\157\156\x74\x72\157\x6c"]), Form::input("\xe7\xa1\256\350\xae\xa4\xe6\x96\xb0\xe5\xaf\206\347\240\x81", "\143\x6f\x6e\146\x69\x72\155\x70\x77\x64", null, "\x70\x61\163\163\x77\157\x72\x64", null, ["\162\x65\161\x75\x69\x72\145\x64" => true, "\x63\154\141\x73\163" => "\x66\x6f\162\x6d\x2d\x63\157\x6e\x74\x72\157\154"])]; goto uq2Bq; Yo4aY: include "\155\157\x64\165\154\145\x73\x2f\x68\145\x61\x64\x65\162\56\160\x68\x70"; goto r75U0; uq2Bq: View::form($title, "\x65\144\151\164\120\x57\104", null, $WtzHp); goto T40Xa; NqLXX: $title = "\344\xbf\256\xe6\224\271\xe5\257\206\347\xa0\x81"; goto Yo4aY; T40Xa: include "\x6d\157\x64\x75\x6c\x65\x73\x2f\146\x6f\x6f\164\145\x72\x2e\x70\150\160";
