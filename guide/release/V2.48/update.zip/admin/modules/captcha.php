<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-25 06:19:05
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 goto Vmwat; XSHW1: $d2uez = new system\library\Captcha(); goto TWzV6; Q7PDM: require $_SERVER["\x44\x4f\103\x55\115\x45\116\x54\137\122\117\x4f\x54"] . "\x2f\163\171\x73\164\145\155\57\x6c\x69\x62\x72\x61\162\171\57\x43\x61\x70\x74\143\x68\141\x2e\160\x68\x70"; goto XSHW1; Vmwat: session_start(); goto Q7PDM; TWzV6: $d2uez->doimg(); goto i6Clx; i6Clx: $_SESSION["\x61\x64\155\x69\156\x5f\143\141\x70\164\143\x68\141"] = $d2uez->getCode();
