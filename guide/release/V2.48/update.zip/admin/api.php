<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-25 06:19:05
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 use system\library\Json; goto dL43n; H3hnC: $DXxrd = system\admin\Api::$TqJq5(); goto bX6I0; dL43n: require_once $_SERVER["\104\x4f\x43\x55\115\x45\x4e\124\x5f\x52\117\x4f\x54"] . "\x2f\x70\165\142\x6c\151\143\x2f\143\157\155\x6d\157\156\56\x70\150\x70"; goto XUEn3; dLQwa: system\admin\Api::init(); goto H3hnC; bX6I0: if (is_string($DXxrd)) { goto y0BpX; } goto Tpex1; Tpex1: Json::echo($DXxrd); goto jby_a; dewaU: echo $DXxrd; goto XK_Mi; yWnce: y0BpX: goto dewaU; XUEn3: $TqJq5 = isset($_GET["\x61\x63\164\151\x6f\x6e"]) ? $_GET["\141\143\164\x69\157\x6e"] : "\151\x6e\x64\145\x78"; goto dLQwa; jby_a: goto kHMDJ; goto yWnce; XK_Mi: kHMDJ:
