<?php

// 重命名表 link 为 site
rename(CONTENT_ROOT . 'JsonDb' . DIR_SEP . 'link.json',CONTENT_ROOT . 'JsonDb' . DIR_SEP . 'site.json');

// 删除旧背景壁纸
$background = CONTENT_ROOT . 'static' . DIR_SEP . 'images' . DIR_SEP . 'background' . DIR_SEP;
unlink($background . 'mobile' . DIR_SEP . '06.jpg');
unlink($background . 'mobile' . DIR_SEP . '07.jpg');