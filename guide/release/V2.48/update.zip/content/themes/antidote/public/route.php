<?php

use JsonDb\JsonDb\Db;
use system\library\Json;
use system\library\Route;
use system\theme\Method;

// 注册主题API路由
$route = Route::rule('/api/[{action}]', function ($param) {
	Api::initialize();
	$return = call_user_func(['Api', $param['action']]);
	Json::echo($return);
});

// 注册站点分类路由
$route = Route::rule('/sort/[{id}]', function ($param) {
	(new Method)->__load('sort', ['id' => $param['id']]);
	exit;
});

// 注册站点详情路由
$route = Route::rule('/site/[{id}]', function ($param) {
	(new Method)->__load('site', ['site_id' => $param['id']]);
	exit;
});

// 注册站点进入路由
$route = Route::rule('/goto/[{id}]', function ($param) {
	(new Method)->__load('goto', ['site_id' => $param['id']]);
	exit;
});

// 注册搜索路由
$route = Route::rule('/search/[{keyword}]', function ($param) {
	(new Method)->__load('search', ['keyword' => $param['keyword']]);
	exit;
});

class Api
{
	/**
	 * @var \system\theme\Method
	 */
	public static $theme;

	public static function initialize()
	{
		self::$theme = new \system\theme\Method;
	}

	public static function getLinks()
	{
		return self::$theme->getSites();
	}

	public static function site_love()
	{
		$id = $_POST['id'];
		$find = Db::name('site')->find($id)['fields'][THEME];
		$love = ($find['love'] ?? 0) + 1;
		$update = Db::name('site')->merge('fields')->where('id', $id)->update([
			'fields' => [
				THEME => ['love' => $love]
			]
		]);
		return $update ? [
			'code' => 200,
			'love' => $love
		] : ['code' => 201];
	}

	public static function json($code, $message)
	{
		return [
			'code' => $code,
			'msg' => $message,
			'message' => $message
		];
	}

	/**
	 * 给无http://或https://前缀的链接加上默认http://
	 */
	public static function addProtocol($url, $protocol = null)
	{
		if (!empty($url)) {
			$protocol = $protocol ? $protocol : 'http://';
			if (!preg_match("/^(http:\/\/|https:\/\/)/i", $url)) {
				return $protocol . $url;
			}
		}
		return $url;
	}

	/**
	 * 检测是否外链到本站
	 */
	public static function checkExternalLink($url)
	{
		$text = \network\http\get($url);
		return stripos($text, $_SERVER['HTTP_HOST']);
	}

	public static function apply_add()
	{
		if (!self::$theme->options->apply) {
			return self::json(500, '本站已关闭申请收录权限');
		}
		if (strtolower($_POST['captcha']) != strtolower($_SESSION['captcha'])) {
			return self::json(400, '验证码错误');
		}
		$name = $_POST['name'];
		$sortId = $_POST['sortId'];
		$qq = $_POST['qq'];
		$domain = trim($_POST['domain']);
		$url = self::addProtocol($domain, $_POST['protocol']);
		if (!$name || !$sortId || !$domain) {
			return self::json(400, '名称、分类、域名缺一不可');
		}
		$find = Db::name('site')->where(['url' => $url, 'status' => 1])->find();
		if ($find) {
			return self::json(400, '该站点已存在');
		}
		$find = Db::name('site')->where(['url' => $url])->find();
		if ($find) {
			return self::json(400, '该站点已提交过申请');
		}
		if (self::$theme->options->auto_apply && self::checkExternalLink($url)) {
			$result = Db::name('site')->insert([
				'title' => $_POST['name'],
				'sort_id' => $_POST['sortId'],
				'qq' => $_POST['qq'],
				'url' => $url,
			]);
			$tip = '，检测到贵站有本站友链，审核通过！';
		} else {
			$result = Db::name('site')->insert([
				'title' => $_POST['name'],
				'sort_id' => $_POST['sortId'],
				'qq' => $_POST['qq'],
				'url' => $url,
				'status' => 0
			]);
			$tip = '，请添加本站友链，等待审核！';
		}
		if ($result) {
			if (self::$theme->options->email_notice) {
				send_email('站点申请', self::$theme->site->title, '<p>收到站点申请，请登录管理后台查看详情</p><p>站点链接：<a href="' . $url . '" target="_blank">' . $url . '</a></p><p>申请者QQ：<a href="http://wpa.qq.com/msgrd?v=3&uin=' . $qq . '&site=qq&menu=yes" target="_blank">' . $qq . '</a></p>');
			}
			return self::json(200, '申请成功' . $tip);
		}
		return self::json(400, '申请失败，请联系站长');
	}
}
