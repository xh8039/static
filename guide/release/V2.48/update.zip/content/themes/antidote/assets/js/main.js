/*
  作者：OUZERO
  官网：https://www.ouzero.com
  演示：https://nav.ouzero.com
  ＱＱ：81389321
  Ｑ群：14979283
  邮箱：admin@ouzero.com
*/

const qqReg = /^([1-9]\d{4,9}$)|^暂无$/ //验证QQ号
const urlReg =
	/^(?=^.{3,255}$)(http(s)?:\/\/)?(www\.)?[a-zA-Z0-9][-a-zA-Z0-9]{0,62}(\.[a-zA-Z0-9][-a-zA-Z0-9]{0,62})+(:\d+)*(\/([-\w]+)*(\.[-\w]+)*)*([#?&]\w+=\w*)*$/i //验证url

$(function () {
	let timer
	$(window).on('scroll', function () {
		const scrollTop = $(window).scrollTop()
		const backTopDom = $('.back-top')

		//监听顶部置顶
		headerFixed()

		//监听懒加载渲染
		timer && clearTimeout(timer)
		timer = setTimeout(function () {
			lazyRender()
		}, 300)

		//监听分类激活
		sortActive()

		//监听返回顶部显示/隐藏
		scrollTop >= 100 ? backTopDom.addClass('show') : backTopDom.removeClass('show')
	})

	//导航高亮
	highLight()

	//懒加载
	const bannerDom = $('.banner')
	bannerDom.css('background-image', 'url("' + bannerDom.attr('data-src') + '")')
	lazyRender()

	//分类激活
	sortActive()

	//顶部置顶
	headerFixed()

	//移动端侧栏显示/隐藏
	$('.nav-bar').on('click', function () {
		if ($(this).hasClass('active')) {
			$(this).removeClass('active')
			$('.nav').removeClass('show')
			$('.transparent-mark').remove()
		} else {
			$(this).addClass('active')
			$('.nav').addClass('show')
			$('.header').append('<div class="transparent-mark"></div>')
		}
	})

	//点击遮罩层隐藏
	$(document).on('click', '.transparent-mark', function () {
		$('.nav-bar').removeClass('active')
		$('.nav').removeClass('show')
		$('.transparent-mark').remove()
	});

	$('.search-form').submit(function (event) {
		if ($('.search-type .item.active').attr('data-type') == 'this') {
			let keyword = $('.search-input').val();
			event.preventDefault();
			location.href = '/search/' + keyword;
			return false;
		}
	});

	//切换搜索方式
	const searchInputDom = $('.search-input'),
		searchFormDom = $('.search-form'),
		searchBtnDom = $('.search-btn')
	searchInputDom.focus()
	$('.search-type .item').on('click', function () {
		$('.search-type .item').removeClass('active')
		$(this).addClass('active')
		searchInputDom.focus()
		searchFormDom.attr('target', '_blank')
		switch ($(this).attr('data-type')) {
			case 'this':
				searchFormDom.attr('action', '../').attr('target', '_self')
				searchInputDom.attr('name', 'keyword')
				searchBtnDom.text('本站搜索');
				break
			case 'baidu':
				searchFormDom.attr('action', 'https://www.baidu.com/s?tn=none')
				searchInputDom.attr('name', 'wd')
				searchBtnDom.text('百度一下')
				break
			case 'sogou':
				searchFormDom.attr('action', 'https://www.sogou.com/sogou?pid=none')
				searchInputDom.attr('name', 'query')
				searchBtnDom.text('搜狗搜索')
				break
			case '360':
				searchFormDom.attr('action', 'https://www.so.com/s?ls=none')
				searchInputDom.attr('name', 'q')
				searchBtnDom.text('360搜索')
				break
			case 'bing':
				searchFormDom.attr('action', 'https://cn.bing.com/search?from=none')
				searchInputDom.attr('name', 'q')
				searchBtnDom.text('必应搜索')
				break
		}
	})

	//点击分类滚动
	$('.sort .move').on('click', function (e) {
		e.preventDefault()
		const href = $(this).attr('href'),
			pos = $(href).offset().top - ($(window).width() <= 767 ? 52 : 62)
		$('html').animate(
			{
				scrollTop: pos
			},
			500
		)
	});

	$('.lazy-load').on('error', function () {
		$(this).attr('src', 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAAAXNSR0IArs4c6QAAIABJREFUeF7tXQl4VFWW/u9L2BQXtFvbXRQUCakKiq2g3aJjIyq4F6mwKEpSAW27xd6mW3vGnt5m2ullerqBekFBtrwy2IIgNtgqYouEhKUqRJGwZWHflD2Qemd8FWCSEJJ7q+6relV13/f5+X3hP+ee85/3f6fedi6DOhQDioEzMsAUN4oBxcCZGVACUWeHYqANBpRA1OmhGFACUeeAYiA6BlQHiY43ZZUmDCiBpEmhVZrRMaAEEh1vyipNGFACSZNCqzSjY0AJJDrelFWaMKAEkiaFVmlGx4ASSHS8Kas0YUAJJE0KrdKMjgElkOh4U1ZpwoASSJoUWqUZHQNKINHxpqzShAElkDQptEozOgaUQKLjTVmlCQNKIGlS6GRM0zN+aRd2uOvNGtFdjLDTZGwXM8O7jMl9F8crHyWQeDGt1uFiwOcrP+sAOntMMocxhm8D6Hq6Ia0DUAyN5hqTclZxOY4SpAQSJXHKTC4D3sKKfkTkYaBhALua0/thgF42dPdLnHhhmBKIMGXKQBYDnvG1XToc/tJjgjwgGhKtX8bYwmJ/9uBo7duyUwKxg1Xls00GhueHbjIz4CGiYQysuwy6iDAyUOSaKcNXUx9KILIZVf5aZWD06E2dj3Y46GEMHgINtYcmutXQ3aUyfSuByGRT+TqNgVxf8EYNzENgHoCutZMiBpQU665hMtdQApHJpvIVYeDeZ6s6nX/sqPUTygPggXjSEj7ecFHJlBt3yVpTCUQWk8oPvGNX9wUxD0izukWPRFDCiJ4pLnJPkLW2EogsJtPUj8dT2VE7P+xhgAcMDyaaBgL+FNBd42XFoQQii8k08+MpWJWTwTKtn1BWt+jpoPRnGbprhKx4lEBkMZkGfny+8g770dFDgNUxHnJkyoR3jSLXIFmxKYHIYjKF/eQWrnRr1MG6PWt1jOscnSqj3xp+989kxagEIovJFPMzcOAHmZf0uMBDGdZFNx5ORHoXfL1z1d5dR4V+vplkDn69KGehrHiVQGQxmSJ+8vIrXMToxAM9XJ+AtDYzsJLBD19x7ppVewtrNx8UCWFXRqcuPWb+b8/9IkZtYZVAZDGZxH5eeom0z7aErLdnPQB7JBGpEGGB9aCvw1EqefaXrufr6g79x+vTNoqFQjTJKHKPEzNqG60EIpPNJPOVO/bTPsxssJ48W9cWvRIQfqRbmMRKAkV9yqz1l9fQiwB+uXjRNqxcvlssJEZ3G373e2JGSiAy+Up+X0Qsb9waj2ma1ouCjyYioabdYvp096GTMZTW0AsM+FX90TBe06twcP9xkfCWGrrrNhEDHqzqIDwspQAmr6Ayy0R42IkHejckIKXTukXTGMpq6GcE/Nr625rV+7Bofp1oiM8buuuPokbt4ZVA2mMoyf891xfyMKJhYOyxRKRypm7RNJbl1fRTMPzm5N/eNDZj0/oDIuEeDONYVoner0bEiAerBMLDUpJhRhRW9g6TaT23sDpG7wSE32a3aCGOfwXDb0/+bfvWI5j16nqxkBmmGn7Xk2JGfGglED6ekgLlLQw+BmjW13lSX/nmTZ6nWzT1VVpLP2GE/2z6tyXvb0f5UrGXcYnY0EBR9nzeOEVwSiAibDkQm5tfcYOWQZHXP0Dok4AQubtFs2uOWvoxEf6r6d8aGkxM19dj3956gTRolaG7bxQwEIIqgQjR5RxwXkHwUWJa42erDHGvo2i3aCGOHxHhdy3Z/KziC7wzt1aQZPaCoWefun4RNG4XHndi241IAc7IQJ4v1OvEi4JWx8hOAFVRdYtmP6s204+Ydro4LMxbs6uxfq3IQ3AKhxuQVfKq+3O7uFACsYtZiX5zCyse0SjyLbf1QC9DomsuV7F0i6YLLK+hHwJ4ubVFd+04gulFghfnYAFDz/ZyJRElSAkkSuLsNvOMC16fYUZeFLRE4bJ7vVb8x9wtWojjB18NgfvvM+XxyZId+GTJTqE0CRgW0F0lQkaCYCUQQcLshnsLKh6G1Sm0yEV3pt3rtfQvq1s0+1lVQ88z4PdnyoUImKavw55dIhfnWGv4s3uDMbKTIyUQO9nl9J1bsPo6MOZhkckfcHOayYRJ7RZNAyurofEE/KGtYNet/RLzZws+4yP8yihy/VwmCa35UgKxm+E2/Of5Qg9Fbs82/tch3qHY0S2aiaOaniOGdl//WPBmDdZWfimUPjEtJ+DvExQyigKsBBIFabGYDC9c1dMk7cRnqywnFl9R2trWLZpdc9TS90H4U3sx7ttTj2l6FcJhoV9Kbxm6Ky4DIpRA2qugpH/PzQ89qEXGbUa6RUdJbrnd2N0tWojjeyD8D09wpR/vxMcf7OCBnsKQSU8EJrunCRlFCVYCiZI4HjPPmBU9MrVMD7HItUVfHhvJmLh0i2biqKbvgfGJw7Kb8cp67Nx2RCTtzefiWJau9zssYhQtVgkkWubasPMWBB+wLrpPXFt0smGJNl3Gs1s0DaS0mp5lDH/mzXdD1X7MDVTzwiM4Av0+oLut5ylxOZRAJNE8fFzomnDY+gjJmioI294NaiPcuHeLZuKope8ywv+K0LlwXh0qg/tETEAZ1D8w0b1MyCgGsBJIDORZprljK4Yw07Q2fbGE0TlGd8LmieoWTQMtq6FnCPiLSPD79x/Ha/51OF5v8ptJnnnFs7ASCA9LLTCe/GD3TC3j5DZhN0XhIlaThHaLpsEvr6GnAfxVNKEVpbvx4bvbhMwI5tiAnuMXMooRrAQiQKDXV3E/Ne6dZ03/6CJgKgXqhG7RQhzWBJGoBkUbUzdga53QdfaOjh06ZE376w17pJDJ6UQJpB2ivGNXXc3MzMjXeQD6cfIqE+aYbtE0qfIaGmsCE6NJtHrTQbwxc5OQKRFNCBS5nxEykgBWAjkDicMLQ/eZOLVN2FkSuBZy4bRu0eyao44KycQkoYSagP+xYAtCK/cKmWvQ7pql9/lAyEgCWAmkCYnDx3x6lamFPUyLCOObEvgVdeHIbtHsZ1Ut+UCI+jrg8KGGyJNz6//8B/unoWd/ix8vD6kEYt2JKgjdq0X2zotsE9bKvtzyCG/Nk5O7RdN4l1WTT2PRi8Pytbp8D97/+1YhQomx5wL+bK4n80KOOcBpKxCPr/LKTEQmf1i3Z2/h4Eo2xPHdolnnqKYCMOixklAyYxPE5u2y/RmmmTVzslt4UFassVr2aSeQvMLgYKLGV8u/eip7jgwSRXwkS7domlPpZspnGopE8mwNu6X2MAKvbRByQ8CUgO56SshIIjgtBOJ9uuIKClPjNmGEWyXyx+sqqbpFM3HU0hhGmMybaFu4aObtagz3z/K7FshYPxofKS2QYQWr79GQYe2dZ11bnBsNQbHYJGO3aJpvWQ09RcArsXBw0ra+Phy5OD/wJf+8XQJWBHRXIm6tn0o55QQyIj94eVg79aJgfxnFFfSRtN2i2TVHDVmTCl8VzP2M8DWr92LR/C1C7hjw02Ld1WywnJADCeCUEUiub/UgIMPDGi+6z5PAjZCLZO8WLcQxGsAUIQLaAc8JbMbGKqF5u8c1Fs6a5e9bJTMOUV9JLRDP2NWXZZrWxXakYwwQTV4CPiW6RVMeyuvoCdPEVAncnHKxfcthzJoidnEOhmLD7xouM45ofCWlQPLyK75D1rhNiuy2en40icdik0rdoikPpdX0BGNyxWH5/+j97SgTnLfLiB4rLnK/EUudZNgmjUBG+j695DgdP7G/BZO+UQoHmSnXLVqI43HG8BoHD0KQhjBhun8d9u09xm331byrT7+ad5XFbWAj0PECGVYQutt6yn3i67xuNnLRqutU7RZNky2rplHEYMs33mvXfIEFc8Tm7TKG/yj2u/493rVubT1HCsTzdOU3MhpO7p3Hbk8AUSndLZpdkFfTSDBMt4tj8Xm7ADOZu3hydsiumET8OkogeWMr7zLNE9uEAReIJCIDmw7dopk4amkECDNkcNeaj907jmCa4LxdBswp1l0J2ZfdkR0kL7/iYlOjk9uEJeKNzbTpFs2uOWppOCPMtEsclt+lS3ZgmeC8XcbYqGJ/tm2iFc03YR1kuG/NnWbkmUXkQ6QLRQOPFZ9u3aLZNUcN5REwK1YO27O3npzv3nm0PdipfyfQpi7Hzu09dWp3fiNu79EB4yqQUWODFx2PPLeAdTfq29GFHJNVWnaLFuLwElAcE4scxtHM22VgLxfr2T/mcB83SFwE4h1bMZBZ+1tQZPrH1+KW3YmF0rlbNLvm2EK5CMOIB//WnSvrDpbYQbcaurtUzMZetK0CyS0MPcnAHgfRQHvTaNV72neLZuKooVwgPuL4Yu+xyEgfkXm7jLGFxf7swQk4T9pc0haB5I4N9tFM7QUC2br7T2uZqW5xOivLq6190hGI18m3fOku/PP97WLLEXxGkSvmb07EFm0fLV0gkY3rwSYBFM/btKpbnKHWpdXkYQyvt38qyEPMmLweO7fzz9tlYNtYBmXNmugSG7MoL+QzepIqkEZxxK8Yqlu0fYaUVdNjxGDrFmUtI9hYtR9zBOftAviLobuejcP5LryENIHkFqwewpg2TzgCcQPVLTg4K6ulR4kwmwMqFbLwrTpUhsQaASMMLC5yfSg1EEnOpAkkzxd6/cRuSZJCa+5GdQt+WpfX0iMgxP1N2APWvN1JVTh2LMwdLAOWFOuuO7gN4gyUIpC8wlB/Iiy1IXbVLQRJLa2lhxnhb4JmUuArlu3Gh/8Qm7cL0PcN3c29ZYKUQAWcSBGI1xf8NcB+JrBum1DVLaJjsryGHjKBN6Ozjt0qMHUjttQd4nbEgC+ooSHLePVGsUFZ3CvEDpQkkJA1ac8XYziqW8RAYGkNPcQSKI5o5u2C6BWjyJ0fQ9q2m0oSSPANgD0STbSqW0TDWnObZTX0oAbMid1T9B6imbfLGN1b7Hf/PfpV7beUI5CC0AdgiPVp+VuMsZJO9V1nO+llNftLENsKZTX0AAFzY/MSm3Vk3q5/HQ4f5r84B1Bm6K5EzD8WSlaOQHzBlwAm8Qsw9pklFpNpJYFJvdcIZZRG4OXVNBQMbyU65WD5HrwnOG+XQftJsd7nd4mOvb31pQgkslUA4e32Fovu3ynMgBKTUUmX+vMWqO7SyGJpNQ1hDPF47tRu2Uqmb0RtNf/FOYB6AssK6NmCo07aDUU6QIpARvrKL2lAx7jciWDACuvpMCPMLdZda6UzkgQOy+voftPEfCeEuqX2EAKvbRQNZZahu0aIGiUCL0UgVuC5BaE/M4a4vi5AwAGruzBGJZ3qz12cDt2lrJbuI9u6tfgpuHjhVqwsE9wVjdgjRlF2wm5Hi2QpTSAjn67s0dAQtt7lj+dLis1zZfiIgZWA6N1U7C5ltXTvCXFIq5vIydISa+1QO9W/DtYTdIFjjaG7sgXwCYVKJdor/WI9Jm52oLG7vJ0K3eWTzXRvpob5BGgxsSLReM3qfVg0X3TbDvaSoWf/QmIYtrqSKhArUoeJ5BR51gc5ZIbnMKYtTrbusnwTDUYm5oOQYevZIOj8TWMzNq0XmrcL0ig7MMmdNHcmpQukiUisb4vjvlUyZ403EVCiMfrA6d2ltIbuYSwijkzO3OIC27HtMGa+IngTivCmUeSK6oFyXJJqZRFbBBK5aPdVXAuYXgZmfVXYJ1EJcq3L2Jsww4uc1l2W1dAgDZHb544Sh8XpR+9tR9knu7jobQIaYegu26epiAbVFt42gTRd1BraANMcCDDrabtjX21ujJkqGTLmgYU/TGR3Kaum75AlDoYOMgsuw5dpEqZOqsIXe+tF3G0IX5rRu+SlLP4hvSLebcLGRSBNY/fkB7trGWygZtJAYhHBXGlTbjLcHmNgfyMKfxjP7lJWTXcTi3SOjjKSkO0jmnm7IPyXUeT6V9mx2O0v7gJpmpDPV97hgNnhW6SxgZF3uQiJmKwownEZg/aend1leR39C8yIODqJBBZP7LzZNaha+6XQkkThbwaK+pYJGTkAnFCBtMzfM6ayRwZruAOWYBB5+fFyB3DUagjWtwwA+7vM7rKiju4KN4qjs1PztiYlWhMTBY93DN11n6CNI+COEkhTRob6ys/qQh0HMEZWZxnIWEL2BOEvEsMyRtriaLtLeR3daTaKw6l3/iJcfLJkJz5ZYj1iEjgY5Rt+t5TNQAVWlQJ1rEBaZpebX3EDY3Q7LMGAWRf6l0lhwB4n2xnYYt7usmwz3alpkXerzrInHHlep/mrsHuXwOhcoq1h1rV3iX6t2G8yeSHH5ClpBNI0S4+v/LxM1qE/kWZdswwEKBH7E/ITz7AMxIq1DJrecvbTJ5toYGYm5hPhbH6HiUFa1x3W9YfYQX82dPf3xWycg05KgbSkLy+/wgWN+hPDHSDr+oUucQ7FzSKpBWO/MfzZk6y/Lq+lO9D44qHjxWHFu+DNWqytFJu3azLc8brftcSh9Wg3rJQQSNMs83zlXwPr0B/EBlDjnbFb22Uh7gD6xfMvut63nnMwoGvcl49iwS/2HcO0SVVoCJv81oTFRpHrTn4D5yFTTiAtKfbkh27SNPRnoNtPPKi82AlluOeBy49mubo59m5VS46sXWqt3WpFDgKeDeiuv4jYOA2b8gJpSvgjvvJLOrDM/gysP0zt22CU0G+ihzx6Ja674TynnROtxjPzlfXYsY1/3i7A9oYztaySCVliqnIYG2klkJbc5+YHb2Ua68+A/tT43OXr8azPOed2wOO+nujU2VEv6Z5Gwcb1BzDH2CxGDUOR4XfFOgpKbE0b0GktkKZ8ep+uuALh8ACruxBFnrn0s4Hv01zeec+l6Htz3HegE0pt0bw6rAmKzdslsHsCevYioYUcCFYCaaUoHg9lZHb7tD8QHmDCun6JvAJjy1l8yeVnIW/0tQ48NRpDOnjgOKZOXIdjxwQuzoFSQ3c58OaIOM1KIBycDR8XuoZMc4Bpsv5ffXjVH0BfDjNuyBOFPXHh1515vb5y+W4sXiQ2b5dAPw7o7pe5CXAwUAlEsDijR2/qfKzjof5hNP4cA2A9pOwm6KYZ/K57LkWOQ39mBaZuwJa6w/zpMRwJhymrZLJ7E7+Rc5FKIDHWZuS44PUNxPojjAFgsAQj/HFYj17n4YHHnPfWf+3mgyiZIXyezzB016gYaXWMuRKIxFI89dTacw5lHu/PYA4QmTTZqVMGxnz3enTu4qy7WdHM2yWGhwJ+V0JHoUosKZRAZLJ5wldeYcV3iEjoDs6Qx67Edb2c80zk6JEwpkxchyOHG0QYChm6yy1i4HSsEogNFRo1Knj28S7sYwDcJ0tOvwtx1+BLbYgmOpehlXthdRDB498M3fVLQRtHw5VAbCqP1xecALBxvO4vuLATRo+7jhduO272jE2o2XxQaJ0wy8gq8Wd9KmTkcLASiE0FGj42NMI0MUPEfe7oa3DZ5Yl/sXdr3SEYU8Xm7RLojYDufkwk32TAKoHYVCVrOEWGFvmZxf3q/W0Dv4Fbbo/r2y6tZm8997Cef4gcRFpeoKiPIWKTDFglEBurlOsLzmZgj/IuccXVXeEZ2Z0Xbgvu+DETUyeJztulqnNxPEvX+wkN6bUlAclOlUAkE9rUndcXGg/gDyJLFHyvF6yXGBN1VAb3YeE8wXm7jP3W8GdL28Q1Ubm3tq4SiI3V8PqCtwD4GGDcDzi+c/9lyO6buAH50czb1Uz0mzXZtcJGKhPmWgnEZuq9BcElYIx73levPufjvoeusDmq1t3v2H4EMyevF1rb2oQ1UOS6X8goicBKIDYXK88X+i0B3BMFzz47E4Xjb7A5qtbdW18MWl8OihzE8FTA75oiYpNMWCUQm6uVV7hmKJEptNHmw96r0L3HuTZH1tw9mYQp4vN2685q6Nj71Vd7ie2BENfMYltMCSQ2/tq19vg2nKfhUCkDrm8XfAJw061fwx13c98d5nXbJs6aVmJNLRE5CPhTQHdZNyJS9lACiUNpvb6KVwB6inepiy7ugpEFPXjhUnDzZlejau1+IV8M5reK9Zx/ChklGVgJJA4F8xZWjAHRZJGlRo/tiQu+Fp+PqPbuqY98NSh0MLxv+F3/ImSThGAlkDgULbfgs+sYO75M5MMq6yeW9VMrHseyj3Zi6Ydi83YZ0TPFRe4J8YgvkWsogcSJfW9hxTwQDeFdrnuPc/Cw92peeEy4af512L1LaDOcPR006j19kntnTAsngbESSJyKlFdQ8VNi9Bve5TIyGZ79cRY0zd4Sbfh8P+aWVPOGFcER4A/orrFCRkkKtpf9JCXFjrCHFYa+rRE+FPF938NXoFfW+SImwtgFc2ph7RglcjAzPKh4ct93RWySFasEEsfK5RVWlBLxT3Psk9MNg4bYt4fQ/i+ORS7OG8IkwsInhu5y9jR9kWzawSqBSCSzPVe5vtAfv9qZ6rn2cCf//bzzO0a+VbfrKF+6C0sE5+0ymD8s1nN+b1dMTvOrBBLHiuT6Qh4GvC6y5IgxPXDxJfZsOiU+bxeHtHBm1qxXeotdtIgk7DCsEkgcC/LwM6UXdjrWeQUYu4p32Vtuvwi3DZQ/kH7zhgP4W7HYvF1GbFpxUfYTvLGnAk4JJM5V9PpCMwEM51320svPgteG0aSL5tdhzWqxebuMaQ8U+/vM4409FXBKIHGuotcXegaA0J4Zz/woC506adIiPXSwIXJxXl8f5vZJYKsDerbUkavciycQqAQSZ/JHFFb2DlNDOcC4LywG3X85+vSNabppsyxXle3BBwu3imVO+LlR5PqVmFHyo5VAElDDPF/oXQLu5l265w3nYuij3Jct7boNvLYRW2oPtYv7fwAzGSirWHetFTBKCagSSALKmFcY+gUR/o136c5dMvH0D+R8RBXNvF0GlBTrrmG88aYSTgkkAdUc7ltzpwnzfZGlh426BpdfFfvMrPfe2Yrgij0iS4NpLLd4UrbQ7WmhBRwMVgJJUHG8vlAQgIt3eWsXKms3qliO+qNhvDpBbN4uAz5v2Lc2q6RkGP8VfSxBOsxWCSRBBfEWBCeCMe4X/qwNdqyNdmI5Qqv24h9vi83bZWC/LtazX4xl3WS2VQJJUPXy8oN5pLFZIsv7vt8LXc+JfmbWGzM3oXqT2LxdaOaNxqScVSJxphJWCSRB1Rw1NnjRcdKCIPoGbwgDB12CG78Z3UdU2+oOo3jqBt6lGnFE840i91Axo9RCK4EksJ5eX8UbAD3CG8JV3bvi0RHRjSb98N1tWFEqNm+XgUYX6+7XeONLRZwSSAKrmucLPkdgf+QNgTFg/AvZvPBTuIYGE1MnVmH/l8dEbGvCmRlZJROyBH+TiSzhfKwSSAJrlJdf4SINqwDifo/E+gzX+hxX5Pi0Yh/+Plds3i5j+EOx3/UDkXVSEasEkuCqen0VHwF0O28YvV3dMPgBsY+o5gQ2Y2OV4Gw3YrcZRdlLeeNKVZwSSIIrKzqa1LqLZd3N4j12bj+CGYLzdgF6z9Dd3K/C8MaSjDglkARXLZoNP58cdx26XdiJK/KPP9iO0o/F5u2CsXGGP3sS1wIpDlICSXCBPZ7XMzK69bL29ePeoND6gMr6kKq9gwiYMvFzfLFX4OKcaFe4IZxVMuVGQVW1F01y/rsSiAPqlucLvUrAk7yhWJ/gWp/itnes+/RLzP9bTXuwFv/OJhp69tOCRikLVwJxQGnzCitGEtF0kVDGv5jd7ib382fXYN3aL0XcAozuNvzu98SMUhetBOKA2nqfWnkpy8ys/GpaOvcQrCGPXonrbjjvjNHv21OPKcLzdtnHhj+b+46aA6izPQQlENsp5lsgtyD0NmO4jw+NiDgskZzpKP3nLny8eDuvu5O45w3dxf3gUtR5MuKVQBxStTxfxQ8I9N+84XToqEVGk57pmFZUhd07jvK6s3AHkcl6GxOyxTYJEVkhCbFKIA4pmndsZV+Y4ZUi4Yws6ImLLj59i4QN6/Zj7uuCo6sYphp+F/eNApE4kxmrBOKg6nl9oTIA/XhD+uZtF+H2O0+fmfXO3Fp8ViE2b5fIHBooypnPu3a64JRAHFRpb0HwZTD2Q96Qul3QEU8+3Xw06f79xzHlr58jLDZvd6Whu27iXTedcEogDqp2XmHlYKLwOyIhffdHvdGx0/9vw16+bDeW/GObiAvrw48XDN3NvTWDoPOkhiuBOKh8npcqO2ZsDVcBOPPtqRbxDhpyGfrkXHDqr7OmbMD2LYf5s2JoINPMChTlCO7Bxr9EMiOVQBxWPa8vOA1go3jDuvrarngkr/EjquqNB/DGLLF5uwAFDN3t5V0v3XBKIA6ruLcgNBoMU0TCev7Fxo+oFr29BWtW7RUxBViGx/BnzRYzSh+0EojDau3xlV+ZgU6fA8S9xW3u49dE3u6dMuFz1NebIhl9ZujZWdb7JSJG6YRVAnFgtb2+ioUADeINLefmC9Htgk7RzNv9lVHk+jnvOumIUwJxYNW9haGfgPCfvKGdfXZmpIPU1YjM2wWIaTkBfx9rgJ06zsCAEogDT43cglU3M5ax3ObQ3jJ014M2r5H07pVAHFpCr69iNUBu28Ij9rhRlC30ir1tsTjYsRKIQ4vj9YX+AGC8TeFtPoRjWfP0fgIPTGyKxOFulUAcWqDcgoohjJEt250R6PcB3c39SotDKYpLWEogcaFZfJGhvvKzzkbHjQCk7+BJJvUPTHYvE48q/SyUQBxcc29BcBYYy5MaIuFdo8jFfQtZ6tpJ6EwJxMFF8xZWjAHRZJkhElAY0F26TJ+p7EsJxMHV9eQHu2dozPqZJevYUX/0SNab024R22JK1upJ6EcJxOFFy/NVFBNI1suEfzV013cdnrKjwlMCcVQ5Tg8mtzD0ICPMiT1MOsLMhluLJ98Uit1X+nhQAkmCWnt9FcsBujmWUAnm7wJ6zk9i8ZGOtkogSVD1EYWVvcMUtnaZPfMYk7byIITCGeZ9JZNyxDYoTAJu7A5RCcRuhiX5j14kbBE6dnjS+EuvrZJCSSs3SiBJVO7Ekt0SAAAA90lEQVThY1ZeZWZmvgBCQfth0xEQXgt3PfR8yR8HHGkfrxCtMaAEkoTnhTc/+BiY9hwYrgeo6a6e1rtVnzOwBSaFp6nvzGMvrhJI7Bwm1INn7OrLMhqoZ2bHjnUzJmStT2gwKbi4EkgKFlWlJI8BJRB5XCpPKciAEkgKFlWlJI8BJRB5XCpPKciAEkgKFlWlJI8BJRB5XCpPKciAEkgKFlWlJI8BJRB5XCpPKciAEkgKFlWlJI8BJRB5XCpPKciAEkgKFlWlJI8BJRB5XCpPKciAEkgKFlWlJI8BJRB5XCpPKciAEkgKFlWlJI8BJRB5XCpPKcjA/wGeBL5uZFWi/wAAAABJRU5ErkJggg==');
	});
});



//导航高亮
function highLight() {
	const urlStr = location.pathname
	$('.nav > li > a').each(function () {
		const href = $(this).attr('href');
		if (urlStr == href) {
			$(this).parent('li').addClass('active')
		} else {
			$(this).parent('li').removeClass('active')
		}
	})
}

//懒加载
function lazyRender() {
	$('.lazy-load').each(function () {
		const scrollTop = $(window).scrollTop(),
			windowHeight = $(window).height(),
			offsetTop = $(this).offset().top
		if (
			offsetTop < scrollTop + windowHeight &&
			offsetTop > scrollTop &&
			$(this).attr('data-src') !== $(this).attr('src')
		) {
			$(this).animate({ opacity: 'toggle' }, 300, function () {
				$(this).attr('src', $(this).attr('data-src'))
				$(this).animate({ opacity: 'toggle' }, 300)
			})
		}
	})
}

//顶部置顶
function headerFixed() {
	const headerDom = $('.header')
	if (headerDom.next('.banner').length === 0) {
		return
	}
	$(window).scrollTop() > 0 ? headerDom.addClass('fixed') : headerDom.removeClass('fixed')
}

//分类激活
function sortActive() {
	if ($('.sort').length === 0) {
		return
	}
	$('.sort .move')
		.removeClass('active')
		.each(function () {
			const href = $(this).attr('href'),
				scrollTop = $(window).scrollTop(),
				windowHeight = $(window).height(),
				offsetTop = $(href).offset().top
			if (offsetTop < scrollTop + windowHeight && offsetTop > scrollTop) {
				$(this).addClass('active')
				return false
			}
		})
}

//返回顶部
function backTop() {
	$('html,body').animate(
		{
			scrollTop: '0'
		},
		500
	)
}

//检测输入
function checkInput(options) {
	for (const item of options) {
		const dom = $('#' + item.id)
		const value = dom.val()
		if (dom.attr('disabled') || (item.optional && !value)) {
			continue
		}
		let result
		if (item.reg) {
			result = item.reg.test(value)
		} else if (item.minLength) {
			result = value.length >= item.minLength
			item.msg = '长度不可少于' + item.minLength + '位'
		} else {
			result = !!value
		}
		if (!result) {
			layer.msg(item.msg, {
				anim: 6,
				time: 500
			})
			dom.focus()
			return false
		}
	}
	return true
}

//申请收录
function addApply() {
	if (
		checkInput([
			{
				id: 'name',
				msg: '请输入名称'
			},
			{
				id: 'sortId',
				msg: '请选择分类'
			},
			{
				id: 'sortId',
				msg: '请选择分类'
			},
			{
				id: 'qq',
				msg: '请输入正确的QQ号',
				reg: qqReg,
				optional: true
			},
			{
				id: 'domain',
				msg: '请输入正确的域名',
				reg: urlReg
			},
			{
				id: 'captcha',
				msg: '请输入验证码'
			}
		])
	) {
		$.ajax({
			type: 'POST',
			url: '/include/api.php?act=apply_add',
			data: $('#apply-add').serialize(),
			beforeSend: () => {
				layer.load(2)
			},
			success: result => {
				layer.closeAll('loading')
				setTimeout(() => {
					if (result.code !== 200) {
						return layer.alert('错误代码：' + result.code + '<br/>错误信息：' + result.msg, {
							anim: 6
						})
					}
					layer.msg(
						result.msg,
						{
							time: 1000
						},
						() => {
							location.reload()
						}
					)
				}, 250)
			},
			error: () => {
				layer.closeAll('loading')
				setTimeout(() => {
					layer.msg('系统错误，请检查网络或联系管理员', {
						anim: 6,
						time: 1000
					})
				}, 250)
			}
		})
	}
}

//点赞功能
function addLove(dom, id) {
	$.ajax({
		type: 'POST',
		url: '/include/api.php?act=site_love',
		data: { id },
		success: result => {
			if (result.code !== 200) {
				return layer.msg(result.msg, {
					anim: 6,
					time: 500
				})
			}
			layer.msg('点赞成功', {
				time: 500
			})
			$(dom).html(
				'<i class="fa fa-thumbs-up fa-fw active" aria-hidden="true"></i>&nbsp;已赞&nbsp;[' + result.data.love + ']'
			)
		},
		error: () => {
			layer.msg('系统错误，请检查网络或联系管理员', {
				anim: 6,
				time: 1000
			})
		}
	})
}
