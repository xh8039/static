<!--头部导航条-->
<header>
	<div class="container" style="padding-right:0;padding-left:0">
		<div class="main">
			<h1 class="logo">
				<a href="<?= $this->buildUrl('index') ?>">
					<img src="<?= $this->site->logo ?>">
					<span><?= $this->site->title ?></span>
				</a>
			</h1>
		</div>
	</div>
</header>