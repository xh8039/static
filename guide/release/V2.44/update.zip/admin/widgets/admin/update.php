<?php

use system\admin\Form;
use system\admin\View;

$title = '更新账号信息';
include 'modules/header.php';
$table = 'admin';
$admin = \system\admin\Admin::info();;
$form = [
	Form::hidden('id', $admin['id']),
	Form::input('用户名', 'user', $admin['user'], 'text', null, ['required' => true]),
	Form::input('昵称', 'name', $admin['name']),
	Form::input('邮箱', 'email', $admin['email']),
	Form::input('QQ号', 'qq', $admin['qq']),
	// Form::select('账号状态', 'status', [
	// 	'1' => '正常',
	// 	'0' => '禁用'
	// ], $admin['status'])
];
View::form($title, 'updateTable', ['table' => $table], $form);
include 'modules/footer.php';