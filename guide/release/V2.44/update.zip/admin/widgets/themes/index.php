<?php
$title = '首页主题管理';
include 'modules/header.php';

use system\theme\Manager;
use system\library\Statics;

?>
<link href="https://cdn.bootcdn.net/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.css" rel="stylesheet">
<div class="row">
	<div class="col-lg-12">
		<div class="card" id="card">
			<header class="card-header d-flex justify-content-between">
				<div class="card-title"><?= $title ?></div>
				<ul class="card-actions">
					<li><a href="javascript:void(0)" class="card-btn-close"><i class="mdi mdi-close"></i></a></li>
					<li><a href="javascript:void(0)" class="card-btn-slide"><i class="mdi mdi-chevron-up"></i></a></li>
					<li><a href="javascript:void(0)" class="card-btn-fullscreen"><i class="mdi mdi-fullscreen"></i></a></li>
				</ul>
			</header>
			<div class="card-body">
				<div class="row row-cols-sm-2 row-cols-xl-3 row-cols-xxl-4 mb-4 g-4">
					<?php
					$list = Manager::getList(true);
					foreach ($list as $key => $value) {
						$screenshot = isset($value['screenshot']) ? $value['screenshot'] : '/content/themes/' . $value['name'] . '/screenshot.jpg?version=' . $value['version'];
					?>
						<div class="col">
							<div class="card h-100">
								<a href="<?= $screenshot ?>" data-fancybox="theme" data-caption="<b><?= $value['title'] ?></b>">
									<img referrer="no-referrer" src="<?= $screenshot ?>" class="card-img-top" title="点击预览大图" data-bs-toggle="tooltip" data-bs-placement="top" onerror='this.src="<?= Statics::gitee("admin/assets/images/ThemeNoImg.jpg", false) ?>"' />
								</a>
								<div class="card-body">
									<h5 class="card-title"><?= $value['title'] ?></h5>
									<div class="card-text">
										<span style="display:block;margin-bottom:5px">
											<span style="margin-right:15px">
												作者：<a href="<?= $value['link'] ?>" target="_blank"><?= $value['author'] ?></a>
											</span>
											<span>版本：<?= $value['version'] ?></span>
										</span>
										<span>简介：<?= $value['description'] ?></span>
									</div>
								</div>
								<footer class="card-footer text-end">
									<div style="display: flex;justify-content: center;">
										<?php
										if ($options['current_theme'] == $value['name']) {
										?>
											<button disabled class="btn btn-primary btn-round btn-w-lg">正在使用</button>
										<?php
										} else {
										?>
											<button class="btn btn-primary btn-round btn-w-lg" onclick="SetTheme('<?= $value['name'] ?>', <?= $value['options'] ? 'true' : 'false' ?>)">启用</button>
										<?php
										}
										?>
									</div>
								</footer>
							</div>
						</div>
					<?php
					}
					?>
				</div>
				<div class="alert alert-primary" role="alert">
					部分主题来自网络收集，含有作者信息的易航已添加作者信息和版权，如有问题请<a class="alert-link" href="http://wpa.qq.com/msgrd?v=3&uin=2136118039&site=qq&menu=yes"> 联系易航</a>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include 'modules/footer.php' ?>
<script src="https://cdn.bootcdn.net/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js"></script>
<script>
	function SetTheme(name, set = false) {
		var loading;
		$(document).ajaxStop(function() {
			loader.destroy();
		});
		$.ajax({
			type: "POST",
			dataType: "json",
			url: "api.php?action=set",
			data: {
				'current_theme': name
			},
			beforeSend() {
				loader = $('#card').lyearloading({});
			},
			success(response) {
				if (response.code == 200) {
					if (set) {
						location.href = '?mod=options&save=1';
					} else {
						location.reload();
					}
				} else {
					$.alert('设置失败，原因：' + response.message);
				}
			},
			error(xhr) {
				$.alert('服务器错误');
			}
		});
	}
</script>