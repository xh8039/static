<?php

use system\admin\Form;
use system\admin\View;
use system\theme\Manager;

$title = '创建导航链接';
include 'modules/header.php';
$table = 'link';
$select = system\library\System::getSort();
$sort = [];
foreach ($select as $key => $value) {
	$sort[$value['id']] = $value['title'];
}
$linkConfig = false;
$functions = Manager::getFile('theme/functions');
if ($functions) {
	include_once $functions;
	$linkConfig = function_exists('linkConfig') ? true : false;
}
View::card($title, function () use ($table, $sort, $linkConfig) {
?>
	<ul class="nav nav-tabs">
		<li class="nav-item">
			<button class="nav-link active" data-bs-toggle="tab" data-bs-target="#pane-basic" type="button">基本信息</button>
		</li>
		<?php
		if ($linkConfig) {
			$theme_info = Manager::getInfo();
		?>
			<li class="nav-item">
				<button class="nav-link" data-bs-toggle="tab" data-bs-target="#pane-theme" type="button"><?= $theme_info['title'] ?>主题设置</button>
			</li>
		<?php
		}
		?>
	</ul>
	<form action="api.php?action=insertTable&table=<?= $table ?>" method="post" class="insertTable">
		<div class="tab-content">
			<div class="tab-pane fade show active" id="pane-basic" aria-labelledby="basic-site">
				<?php
				echo Form::select('链接分类', 'cid', $sort);
				echo Form::text('链接标题', 'title', null, null, ['required' => true]);
				echo Form::input('链接地址', 'url', null, 'url', null, ['required' => true]);
				echo Form::input('rel属性', 'rel', 'nofollow', 'text', '例如：nofollow（注释：不传递搜索引擎权重）');
				echo Form::input('链接排序', 'order', 0, 'number', '排序越高优先级越高', ['required' => true]);
				echo Form::hidden('status', 1)
				?>
			</div>
			<?php
			if ($linkConfig) {
			?>
				<div class="tab-pane fade" id="pane-theme" aria-labelledby="basic-site">
					<?php
					linkConfig(new \system\theme\Fields([]), new \system\theme\Method);
					?>
				</div>
			<?php
			}
			?>
		</div>
		<div class="d-grid">
			<button type="submit" class="btn btn-primary">创建链接</button>
		</div>
	</form>
<?php
});
include 'modules/footer.php';
?>
<script type="text/javascript">
	new PublicAjax('.insertTable', '创建链接')
</script>