<?php

use system\admin\Form;
use system\plugin\Manager;

$title = '插件设置';
include 'modules/iframe.php';
include_once ROOT . 'system/plugin/From.php';
$table = 'pluginSet';
$plugin = Manager::getInfo($_GET['name'], true);
$form = (function () use ($plugin) {
	$form = [];
	$plugin_file = PLUGINS_ROOT . $plugin['name'] . DIRECTORY_SEPARATOR . 'Plugin.php';
	if (is_file($plugin_file)) {
		include_once $plugin_file;
		if (method_exists($plugin['class'], 'config')) {
			$form = $plugin['class']::config(new system\plugin\Form($plugin['name']));
			$form = empty($form->html) ? [] : $form->html;
		}
	}
	return $form;
})();
$title = $plugin['title'] . $title;
if (empty($form)) {
	echo '插件 ' . $plugin['title'] . ' 暂无自定义设置';
} else {
	$form = implode(PHP_EOL, $form);
	echo Form::form('pluginSet', ['plugin' => $_GET['name']], $form);
	// View::form($title, 'pluginSet', ['plugin' => $_GET['name']], $form);
}
include 'modules/footer.php';