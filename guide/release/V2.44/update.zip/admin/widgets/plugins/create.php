<?php

use system\admin\View;

$title = '新增插件';
include 'modules/header.php';
echo View::card($title, '只能手动添加插件哦');
include 'modules/footer.php';