<?php
$title = '插件管理';
include 'modules/header.php';
system\admin\View::table();
?>
<script>
	BootstrapTable.act = 'getPlugin';
	BootstrapTable.table_options.search = false;
	BootstrapTable.table_options.uniqueId = 'name'; //唯一字段
	BootstrapTable.table_options.idField = 'name'; //每行的唯一标识字段
	BootstrapTable.status_api = 'pluginStatus';
	BootstrapTable.columns = [{
			field: 'title',
			align: 'center',
			title: '名称',
			titleTooltip: '插件名称'
		},
		{
			field: 'description',
			align: 'center',
			title: '描述',
		},
		{
			field: 'author',
			align: 'center',
			title: '作者',
			formatter: function(value, row) {
				value = `<a target="_blank" href="${row.link}">${value}</a>`
				return value;
			}
		},
		{
			field: 'version',
			align: 'center',
			title: '版本',
			sortable: true,
		}
	]
	BootstrapTable.init();
</script>