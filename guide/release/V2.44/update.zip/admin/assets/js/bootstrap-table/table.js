class BootstrapTable {

	static loading = null;
	static table;
	static act = 'getTable';
	static status_api = 'fieldStatus';
	static options = {};

	/**
	 * 表格相关的配置
	 **/
	static table_options = window.bootstrap_table_options;

	/**
	 * 用于演示的列信息
	 **/
	static columns;

	static init() {
		// 请求地址
		this.initColumns();
		this.table_options.url = `api.php?action=${this.act}${this.table ? '&table=' + this.table : ''}`;
		this.table_options.columns = this.columns;
		this.bootstrapTable = $('table').bootstrapTable({
			...this.table_options,
			onLoadSuccess: function (data) {
				$('.tooltip').remove() // 删除提示
				if ($("[data-bs-toggle='tooltip']").tooltip) $("[data-bs-toggle='tooltip']").tooltip(); // 提示初始化
				if (this.loading) this.loading.destroy();
			}
		});
	}

	/**
	 * 删除函数
	 */
	static delete(row) {
		var loading;
		var uniqueId = this.table_options.uniqueId;
		$.ajax({
			'url': 'api.php?action=deleteTable',
			'type': 'get',
			'data': {
				table: this.table,
				[uniqueId]: row[uniqueId]
			},
			beforeSend: () => {
				loading = this.bootstrapTable.lyearloading({
					spinnerSize: 'lg'
				});
			},
			success: (data) => {
				loading.destroy();
				if (data.code == 200) {
					this.loading = this.bootstrapTable.lyearloading({});
					$('table').bootstrapTable('refresh', {
						silent: true//静态刷新
					})
				} else {
					$.alert(data.message);
				}
			}
		})
	}

	/**
	 * 调整状态函数
	 * @param {object} row
	 */
	static status(row) {
		var loading;
		var uniqueId = this.table_options.uniqueId;
		$.ajax({
			'url': 'api.php?action=' + this.status_api,
			'type': 'post',
			'data': {
				table: this.table,
				[uniqueId]: row[uniqueId]
			},
			beforeSend: () => {
				loading = this.bootstrapTable.lyearloading({
					spinnerSize: 'lg'
				});
			},
			success: (data) => {
				loading.destroy();
				if (data.code == 200) {
					this.loading = this.bootstrapTable.lyearloading({});
					$('table').bootstrapTable('refresh', {
						silent: true//静态刷新
					});
				} else {
					$.alert(data.message);
				}
			}
		})
	}

	/**
	 * 编辑列函数
	 * @param {object} row
	 */
	static update(row) {
		var uniqueId = this.table_options.uniqueId;
		//iframe 层
		layer.open({
			type: 2,
			title: row.title ? row.title : '编辑',
			// shadeClose: true,
			// shade: false,
			maxmin: true, //开启最大化最小化按钮
			area: ['90%', '90%'],
			content: location.href + `?mod=update&${uniqueId}=${row[uniqueId]}`,
			success: function (res, index) {
				var iframe = $(res).find('iframe');
				var titleHeight = $(res).find('.layui-layer-title').height();
				var iframeHeight = iframe[0].contentDocument.body.scrollHeight;
				var height = iframeHeight + titleHeight + 1;
				if (window.innerHeight * 0.9 > height) {
					$(res).css('height', height);
					iframe.css('height', iframeHeight);
				} else {
					$(res).css('height', '90%');
					iframeHeight = $(res).height() - titleHeight;
					iframe.css('height', iframeHeight);
				}
				res.css('top', (window.innerHeight - height) / 2);
			},
			...this.options.iframe
		});
	}

	static initColumns() {
		this.columns.unshift(
			{
				checkbox: true,
				// 列的宽度
				width: 5,
				// 宽度单位
				widthUnit: 'rem'
			},
			{
				field: this.table_options.uniqueId,
				title: '编号',
				// 使用[align]，[halign]和[valign]选项来设置列和它们的标题的对齐方式。
				// h表示横向，v标识垂直
				align: 'center',
				// 是否作为排序列
				sortable: true,
				// 当列名称与实际名称不一致时可用
				sortName: this.table_options.uniqueId,
				// switchable: false,
				// 是否可视(默认 - true)
				visible: false,
				// 列的宽度
				width: 5,
				// 宽度单位
				widthUnit: 'rem'
			}
		)
		this.columns.push(
			{
				field: 'status',
				title: '状态',
				sortable: true,
				// 列的宽度
				width: '70',
				// 宽度单位
				widthUnit: 'px',
				align: 'center',
				formatter: function (value, row, index) {
					var value = "";
					if (row.status == '0') {
						value = '<span style="cursor: pointer;user-select:none;" class="badge bg-danger" title="点击激活" data-bs-toggle="tooltip" data-bs-placement="top">禁用</span>';
					} else if (row.status == '1') {
						value = '<span style="cursor: pointer;user-select:none;" class="badge bg-success" title="点击禁用" data-bs-toggle="tooltip" data-bs-placement="top">正常</span>';
					} else {
						value = row.pType;
					}
					return value;
				},
				events: {
					'click span': (event, value, row, index) => {
						this.status(row, event);
					}
				}
			},
			{
				title: '操作',
				// 列的宽度
				width: '95',
				// 宽度单位
				widthUnit: 'px',
				align: 'center',
				formatter: (value, row) => {
					var uniqueId = this.table_options.uniqueId;
					let html = `<span style="margin-right:5px" data-bs-toggle="tooltip" data-bs-placement="top" href="?mod=update&${uniqueId}=${row[uniqueId]}" class="btn btn-sm btn-teal edit-btn" title="编辑"><i class="mdi mdi-pencil"></i></span>` +
						'<span class="btn btn-sm btn-danger del-btn" title="删除" data-bs-toggle="tooltip" data-bs-placement="top"><i class="mdi mdi-window-close"></i></span>';
					return html;
				}, // 自定义方法
				events: {
					'click .edit-btn': (event, value, row, index) => {
						this.update(row, event);
					},
					'click .del-btn': (event, value, row, index) => {
						this.delete(row, event);
					}
				}
			}
		)
	}

}