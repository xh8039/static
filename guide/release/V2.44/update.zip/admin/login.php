<?php

/*
 * @Author        : 易航
 * @Url           : blog.bri6.cn
 * @Date          : 2020-09-29 13:18:36
 * @LastEditTime  : 2022-10-26 21:46:06
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址引导系统
 * @Description   : 一款极其优雅的易航网址引导系统
 * @Read me       : 感谢您使用易航网址引导系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/

use JsonDb\JsonDb\Db;
use system\library\Json;
use system\library\Statics;

include $_SERVER['DOCUMENT_ROOT'] . '/public/common.php';
if (isset($_GET['logout'])) {
	unset($_SESSION['admin']);
	header('Content-Type: text/html; charset=UTF-8');
	exit("<script language='javascript'>alert('您已成功注销本次登陆！');window.location.href='./login.php';</script>");
}
if (isset($_POST['user']) && isset($_POST['pwd'])) {
	if (is_image()) {
		if (empty($_POST['captcha'])) Json::echo(['message' => '验证码不能为空']);
		$captcha = strtolower(addslashes(trim($_POST['captcha'])));
		if (empty($_SESSION['admin_captcha'])) {
			Json::echo([
				'message' => '验证码过期，请重新获取验证码'
			]);
		}
		if ($_SESSION['admin_captcha'] != $captcha) {
			unset($_SESSION['admin_captcha']);
			Json::echo([
				'message' => '验证码错误'
			]);
		}
		unset($_SESSION['admin_captcha']);
	}
	$user = addslashes(trim($_POST['user']));
	$pwd = addslashes(trim($_POST['pwd']));
	$find_array = ['user' => $user, 'pwd' => $pwd, 'status' => 1];
	$find = Db::name('admin')->where($find_array)->find();
	if (empty($find)) {
		Json::echo(['message' => '账号或密码错误']);
	}
	// $login_date = date_time();
	// Db::name('admin')->where($find_array)->update([
		// 'login_date' => $login_date,
		// 'login_count' => $find['login_count'] + 1
	// ]);
	$_SESSION['admin'] = $find;
	Json::echo(['code' => 200]);
} else {
	$location = empty($_GET['referrer']) ? 'index.php' : $_GET['referrer'];
}
?>
<!DOCTYPE html>
<html lang="zh">

<head>
	<meta name="referrer" content="no-referrer" />
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
	<meta name="keywords" content="<?= $site['keywords'] ?>">
	<meta name="description" content="<?= $site['description'] ?>">
	<meta name="author" content="易航">
	<title>后台登录 - <?= $site['title'] ?></title>
	<link rel="shortcut icon" type="image/x-icon" href="favicon.ico">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-touch-fullscreen" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="default">
	<link rel="stylesheet" type="text/css" href="assets/css/materialdesignicons.min.css?version=<?= VERSION ?>">
	<link rel="stylesheet" type="text/css" href="<?= cdn('twitter-bootstrap/5.1.3/css/bootstrap.min.css') ?>">
	<link rel="stylesheet" type="text/css" href="<?= cdn('animate.css/4.1.1/animate.min.css') ?>">
	<link rel="stylesheet" type="text/css" href="<?= LightYear('css/style.min.css') ?>">
	<script type="text/javascript" src="<?= cdn('jquery/3.6.1/jquery.min.js') ?>"></script>
	<script type="text/javascript" src="<?= cdn('popper.js/2.11.2/umd/popper.min.js') ?>"></script>
	<script type="text/javascript" src="<?= cdn('twitter-bootstrap/5.1.3/js/bootstrap.min.js') ?>"></script>
	<script type="text/javascript" src="<?= LightYear('js/lyear-loading.js') ?>"></script>
	<script type="text/javascript" src="<?= LightYear('js/bootstrap-notify.min.js') ?>"></script>
	<style>
		.signin-form .has-feedback {
			position: relative;
		}

		.signin-form .has-feedback .form-control {
			padding-left: 36px;
		}

		.signin-form .has-feedback .mdi {
			position: absolute;
			top: 0;
			left: 0;
			right: auto;
			width: 36px;
			height: 36px;
			line-height: 36px;
			z-index: 4;
			color: #dcdcdc;
			display: block;
			text-align: center;
			pointer-events: none;
		}

		.signin-form .has-feedback.row .mdi {
			left: 15px;
		}
	</style>
</head>
<img referrer="no-referrer" style="display: none;" src="<?= $options['admin']['background'] ?>">

<body class="center-vh" style="background-image: url(<?= $options['admin']['background'] ?>); background-size: cover;">
	<div class="card card-shadowed p-5 mb-0 mr-2 ml-2">
		<div class="text-center mb-3">
			<a target="_blank" href="http://<?= DOMAIN ?>"> <img referrer="no-referrer" alt="<?= $site['title'] ?>" src="<?= Statics::gitee('admin/assets/images/logo-sidebar.png') ?>"> </a>
		</div>

		<form action="" method="post" class="signin-form needs-validation" novalidate>
			<div class="mb-3 has-feedback">
				<span class="mdi mdi-account" aria-hidden="true"></span>
				<input type="text" class="form-control" name="user" placeholder="用户名" required>
			</div>

			<div class="mb-3 has-feedback">
				<span class="mdi mdi-lock" aria-hidden="true"></span>
				<input type="password" class="form-control" name="pwd" placeholder="密码" required>
			</div>

			<?php
			if (is_image()) {
			?>
				<div class="mb-3 has-feedback row">
					<div class="col-7">
						<span class="mdi mdi-check-all form-control-feedback" aria-hidden="true"></span>
						<input type="text" name="captcha" class="form-control" placeholder="验证码" required>
					</div>
					<div class="col-5 text-right">
						<img src="modules/captcha.php" class="pull-right" id="captcha" style="cursor: pointer;max-height: 38px;" onclick="this.src=this.src+'?d='+Math.random();" title="点击刷新" alt="captcha">
					</div>
				</div>
			<?php
			}
			?>

			<div class="mb-3">
				<div class="form-check">
					<input type="checkbox" class="form-check-input" id="rememberme">
					<label class="form-check-label not-user-select" for="rememberme">5天内自动登录</label>
				</div>
			</div>

			<div class="mb-3 d-grid">
				<button class="btn btn-primary" type="submit">立即登录</button>
			</div>
		</form>

		<div style="color: #999;line-height: 1.8;text-align: center;" role="contentinfo">
			<span class="copyright"><?= base64_decode('5pys57O757uf55SxIDxhIHRhcmdldD0iX2JsYW5rIiByZWw9ImNvcHlyaWdodCBhdXRob3IgY2Fub25pY2FsIGZyaWVuZCIgaHJlZj0iaHR0cDovL2d1aWRlLmJyaTYuY24iPuaYk+iIque9keWdgOW8leWvvOezu+e7nzwvYT4g5by65Yqb6amx5YqoLCDniYjmnKwg') ?><?= VERSION ?></span>
			<div class="resource" style="color: #CCC;">
				<?= base64_decode('PGEgc3R5bGU9ImNvbG9yOiAjOTk5OyIgaHJlZj0iaHR0cDovL2RvYy5icmk2LmNuL0BndWlkZSIgdGFyZ2V0PSJfYmxhbmsiIHJlbD0ibm9vcGVuZXIgbm9yZWZlcnJlciI+5biu5Yqp5paH5qGjPC9hPiDigKIKCQkJCTxhIHN0eWxlPSJjb2xvcjogIzk5OTsiIGhyZWY9Imh0dHA6Ly9ibG9nLmJyaTYuY24iIHRhcmdldD0iX2JsYW5rIiByZWw9Im5vb3BlbmVyIG5vcmVmZXJyZXIiPuaUr+aMgeiuuuWdmzwvYT4g4oCiCgkJCQk8YSBzdHlsZT0iY29sb3I6ICM5OTk7IiBocmVmPSJodHRwczovL2dpdGVlLmNvbS95aF9JVC9ndWlkZS9pc3N1ZXMiIHRhcmdldD0iX2JsYW5rIiByZWw9Im5vb3BlbmVyIG5vcmVmZXJyZXIiPuaKpeWRiumUmeivrzwvYT4g4oCiCgkJCQk8YSBzdHlsZT0iY29sb3I6ICM5OTk7IiBocmVmPSJodHRwczovL2dpdGVlLmNvbS95aF9JVC9ndWlkZSIgdGFyZ2V0PSJfYmxhbmsiIHJlbD0ibm9vcGVuZXIgbm9yZWZlcnJlciI+6LWE5rqQ5LiL6L29PC9hPg==') ?>
			</div>
		</div>
	</div>
	<script type="text/javascript">
		var loader;
		$(document).ajaxStart(function() {
			$("button:submit").html('登录中...').attr("disabled", true);
			loader = $('button:submit').lyearloading({
				opacity: 0.2,
				spinnerSize: 'nm'
			});
		}).ajaxStop(function() {
			loader.destroy();
			$("button:submit").html('立即登录').attr("disabled", false);
		});
		$('.signin-form').on('submit', function(event) {
			if ($(this)[0].checkValidity() === false) {
				event.preventDefault();
				event.stopPropagation();
				$(this).addClass('was-validated');
				return false;
			}
			var $data = $(this).serialize();
			$.post($(this).attr('action'), $data, function(res) {
				if (res.code == 200) {
					$.notify({
						message: '登录成功，页面即将跳转~',
					}, {
						type: 'success',
						placement: {
							from: 'top',
							align: 'content'
						},
						z_index: 10800,
						delay: 1500,
						animate: {
							enter: 'animate__animated animate__fadeInUp',
							exit: 'animate__animated animate__fadeOutDown'
						}
					});
					setTimeout(function() {
						location.href = '<?= $location ?>';
					}, 1500);
				} else {
					if (res.message == '验证码错误') {
						$('input[name=captcha]').val('');
					}
					$.notify({
						message: '登录失败：' + res.message,
					}, {
						type: 'danger',
						placement: {
							from: 'top',
							align: 'right'
						},
						z_index: 10800,
						delay: 1500,
						animate: {
							enter: 'animate__animated animate__shakeX',
							exit: 'animate__animated animate__fadeOutDown'
						}
					});
					$('#password').val('');
					$("#captcha").click();
				}
			}).fail(function() {
				$.notify({
					message: '服务器错误',
				}, {
					type: 'danger',
					placement: {
						from: 'top',
						align: 'right'
					},
					z_index: 10800,
					delay: 1500,
					animate: {
						enter: 'animate__animated animate__shakeX',
						exit: 'animate__animated animate__fadeOutDown'
					}
				});
			});
			return false;
		});
	</script>
</body>

</html>