				</div>
				<div role="contentinfo" class="copyright">
					<span><?= base64_decode('5pys57O757uf55SxIDxhIHRhcmdldD0iX2JsYW5rIiBocmVmPSJodHRwOi8vZ3VpZGUuYnJpNi5jbiI+5piT6Iiq572R5Z2A5byV5a+857O757ufPC9hPiDlvLrlipvpqbHliqgsIOeJiOacrCA=') ?><?= VERSION ?></span>
					<div class="resource">
						<?= base64_decode('PGEgaHJlZj0iaHR0cDovL2RvYy5icmk2LmNuL0BndWlkZSIgdGFyZ2V0PSJfYmxhbmsiPuW4ruWKqeaWh+ahozwvYT4g4oCiCjxhIGhyZWY9Imh0dHA6Ly9ibG9nLmJyaTYuY24iIHRhcmdldD0iX2JsYW5rIj7mlK/mjIHorrrlnZs8L2E+IOKAogo8YSBocmVmPSJodHRwczovL2dpdGVlLmNvbS95aF9JVC9ndWlkZS9pc3N1ZXMiIHRhcmdldD0iX2JsYW5rIj7miqXlkYrplJnor688L2E+IOKAogo8YSBocmVmPSJodHRwczovL2dpdGVlLmNvbS95aF9JVC9ndWlkZSIgdGFyZ2V0PSJfYmxhbmsiPui1hOa6kOS4i+i9vTwvYT4=') ?>
					</div>
				</div>
				<script>
					if (self.frameElement && self.frameElement.tagName == "IFRAME") {
  						$('.copyright').hide();
					}
				</script>
			</main>
			<!--End 页面主要内容-->
		</div>
	</div>
	<!-- <script type="text/javascript" src="<?= cdn('mouse0270-bootstrap-notify/3.1.3/bootstrap-notify.min.js') ?>"></script> -->
	<!--时间日期选择器js-->
	<!-- <script type="text/javascript" src="assets/js/momentjs/moment.min.js"></script> -->
	<!-- <script type="text/javascript" src="assets/js/bootstrap-datetimepicker/bootstrap-datetimepicker.min.js"></script> -->
	<!-- <script type="text/javascript" src="assets/js/momentjs/locale/zh-cn.min.js"></script> -->
	<script type="text/javascript" src="<?= LightYear('js/main.min.js') ?>"></script>
	<script type="text/javascript" src="<?= system\library\Statics::gitee('admin/assets/js/server/v2.4.min.js') ?>"></script>
	<script>
		setTimeout(function () {
			$("#loading-animation").fadeOut(500);
		}, 15000);
	</script>
</body>

</html>
<?php system\admin\Server::autoUpdate() ?>