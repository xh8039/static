<?php

use system\library\Statics;
use system\theme\Manager;

?>
<aside class="lyear-layout-sidebar">
	<!-- logo -->
	<div id="logo" class="sidebar-header">
		<a href="http://guide.bri6.cn" target="_blank"><img referrer="no-referrer" src="<?= Statics::gitee('admin/assets/images/logo-sidebar.png') ?>" title="易航后台管理系统" alt="易航后台管理系统" /></a>
	</div>
	<div class="lyear-layout-sidebar-info lyear-scroll">
		<nav class="sidebar-main">
			<ul class="nav-drawer">
				<li class="nav-item">
					<a href="index.php">
						<svg class="icon" aria-hidden="true">
							<use xlink:href="#icon--"></use>
						</svg>
						<span>后台首页</span>
					</a>
				</li>
				<li class="nav-item nav-item-has-subnav">
					<a href="javascript:void(0)">
						<svg class="icon" aria-hidden="true">
							<use xlink:href="#icon-peizhi"></use>
						</svg>
						<span>系统管理</span>
					</a>
					<ul class="nav nav-subnav">
						<li class="nav-item"><a href="set.php?mod=options">系统配置</a></li>
						<li class="nav-item"><a href="set.php?mod=tool">自助工具</a></li>
					</ul>
				</li>
				<li class="nav-item nav-item-has-subnav">
					<a href="javascript:void(0)">
						<svg class="icon" aria-hidden="true">
							<use xlink:href="#icon-biaoqianA01_fenlei-52"></use>
						</svg>
						<span>分类管理</span>
					</a>
					<ul class="nav nav-subnav">
						<li class="nav-item"><a href="sort.php">分类列表</a></li>
						<li class="nav-item"><a href="sort.php?mod=create">新增分类</a></li>
					</ul>
				</li>
				<li class="nav-item nav-item-has-subnav">
					<a href="javascript:void(0)">
						<svg class="icon" aria-hidden="true">
							<use xlink:href="#icon-daohang"></use>
						</svg>
						<span>链接管理</span>
					</a>
					<ul class="nav nav-subnav">
						<li class="nav-item"><a href="link.php">链接列表</a></li>
						<li class="nav-item"><a href="link.php?mod=create">新增链接</a></li>
					</ul>
				</li>
				<li class="nav-item nav-item-has-subnav">
					<a href="javascript:void(0)">
						<svg class="icon" aria-hidden="true">
							<use xlink:href="#icon-changyonglianjie"></use>
						</svg>
						<span>友链管理</span>
					</a>
					<ul class="nav nav-subnav">
						<li class="nav-item"><a href="friends.php">友链列表</a></li>
						<li class="nav-item"><a href="friends.php?mod=create">新增友链</a></li>
					</ul>
				</li>
				<li class="nav-item nav-item-has-subnav">
					<a href="javascript:void(0)">
						<svg class="icon" aria-hidden="true">
							<use xlink:href="#icon-43_zhuti"></use>
						</svg>
						<span>主题管理</span>
					</a>
					<ul class="nav nav-subnav">
						<li class="nav-item"><a href="themes.php">选择主题</a></li>
						<?= Manager::getInfo(THEME, false)['options'] ? '<li class="nav-item"><a href="themes.php?mod=options">主题设置</a></li>' : null ?>
					</ul>
				</li>
				<li class="nav-item">
					<a href="plugins.php">
						<svg class="icon" aria-hidden="true">
							<use xlink:href="#icon-qitachajianqu"></use>
						</svg>
						<span>插件管理</span>
					</a>
				</li>
				<li class="nav-item">
					<a href="update.php">
						<svg class="icon" aria-hidden="true">
							<use xlink:href="#icon-xitonggengxin"></use>
						</svg>
						<span>检查更新</span>
					</a>
				</li>
			</ul>
			<script>
				(function() {
					var pathname = window.location.pathname;
					var search = window.location.search;
					var path = search ? pathname + search : pathname;
					$('.nav-drawer').find('a').each(function() {
						temp_path = '/admin/' + $(this).attr('href');
						if (path == temp_path) {
							$('.nav-drawer').find('.nav-item').removeClass('active').removeClass('open');
							$('.nav-drawer').find('.nav-subnav:visible').slideUp(500);
							$(this).parent('li').addClass('active');
							$(this).parents('.nav-subnav').slideDown(500);
							$(this).parents('.nav-item').addClass('open');
							$(this).parents('.nav-item').last().addClass('active');
						}
					});
				}())
			</script>
		</nav>
		<div class="sidebar-footer">
			<div class="copyright">
				<span role="contentinfo"><?= base64_decode('55SxIDxhIHRhcmdldD0iX2JsYW5rIiBocmVmPSJodHRwOi8vZ3VpZGUuYnJpNi5jbiI+5piT6Iiq572R5Z2A5byV5a+857O757ufPC9hPiDlvLrlipvpqbHliqg=') ?></span>
				<div class="resource">
					<?= base64_decode('PGEgaHJlZj0iaHR0cDovL2RvYy5icmk2LmNuL0BndWlkZSIgdGFyZ2V0PSJfYmxhbmsiPuW4ruWKqeaWh+ahozwvYT4g4oCiIDxhIGhyZWY9Imh0dHA6Ly9ibG9nLmJyaTYuY24iIHRhcmdldD0iX2JsYW5rIj7mlK/mjIHorrrlnZs8L2E+CjxiciAvPgo8YSBocmVmPSJodHRwczovL2dpdGVlLmNvbS95aF9JVC9ndWlkZS9pc3N1ZXMiIHRhcmdldD0iX2JsYW5rIj7miqXlkYrplJnor688L2E+IOKAoiA8YSBocmVmPSJodHRwczovL2dpdGVlLmNvbS95aF9JVC9ndWlkZSIgdGFyZ2V0PSJfYmxhbmsiPui1hOa6kOS4i+i9vTwvYT4=') ?>
				</div>
			</div>
		</div>
	</div>
</aside>