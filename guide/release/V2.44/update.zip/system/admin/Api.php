<?php

namespace system\admin;

use JsonDb\JsonDb\Db;
use system\library\Json;

class Api
{

	/**
	 * 初始化
	 * @access public
	 */
	public static function init()
	{
		Admin::check('json');
	}

	// 插件相关API
	public static function getPlugin()
	{
		$plugins = \system\plugin\Manager::getList(true);
		foreach ($plugins as $key => $value) {
			$value['id'] = $value['name'];
			unset($value[0]);
			$plugins[$key] = $value;
		}
		$plugins = array_values($plugins);
		$total = count($plugins);
		Json::echo([
			'rows' => $plugins,
			'total' => $total
		]);
		Json::echo($plugins);
	}
	public static function pluginSet()
	{
		DEMO_MODE ? Json::echo(['message' => '演示站']) : null;
		if (empty($_POST)) {
			return [
				'message' => '配置项为空'
			];
		}
		if (empty($_GET['plugin'])) {
			return [
				'message' => '请输入要设置的插件目录名称'
			];
		}
		$plugin_name = $_GET['plugin'];
		$options = $_POST;
		\system\plugin\Manager::saveSet($plugin_name, $options);
		Json::echo(['code' => 200]);
	}
	public static function pluginStatus()
	{
		DEMO_MODE ? Json::echo(['message' => '演示站']) : null;
		$plugin_info = \system\plugin\Manager::getInfo($_POST['name'], false);
		$plugin_name = $_POST['name'];
		$message = '未知操作';
		if ($plugin_info['status']) {
			Db::name('plugins')->where('plugin', $plugin_name)->update(['status' => 0]);
			$message = '禁用';
		} else {
			$plugin_file = PLUGINS_ROOT . $plugin_name . DIRECTORY_SEPARATOR . 'Plugin.php';
			if (is_file($plugin_file)) {
				include_once $plugin_file;
				if (method_exists($plugin_info['class'], 'config')) {
					include_once ROOT . 'system/plugin/From.php';
					$form = new \system\plugin\Form($plugin_info['name']);
					$plugin_info['class']::config($form);
					if (!empty($form->active)) {
						\system\plugin\Manager::saveSet($plugin_name, $form->active);
					}
				}
			}
			Db::name('plugins')->save(['plugin' => $plugin_name, 'status' => 1], 'plugin');
			$message = '激活';
		}
		$data = [
			'code' => 200,
			'message' => '插件' . $message . '成功'
		];
		Json::echo($data);
	}

	/**
	 * 更新系统设置
	 * @access public
	 */
	public static function set()
	{
		DEMO_MODE ? Json::echo(['message' => '演示站']) : null;
		foreach ($_POST as $k => $v) {
			options($k, $v);
		}
		Json::echo(['code' => 200]);
	}

	public static function themeSet()
	{
		DEMO_MODE ? Json::echo(['message' => '演示站']) : null;
		$_POST['theme'] = THEME;
		\system\theme\Manager::saveSet($_POST) ? Json::echo(['code' => 200]) : Json::echo(['message' => 'JsonDb保存主题设置失败']);
	}

	/**
	 * 获取指定表格信息
	 * @access public
	 */
	public static function getTable()
	{
		$table = $_GET['table'];
		$DB = Db::name($table);
		$rows = $DB->select();
		if (empty($rows)) {
			$rows = $DB->selectAll();
		}
		$total = $DB->count();
		return [
			'rows' => $rows,
			'total' => $total
		];
	}

	/**
	 * 对表格进行更新操作
	 * @access public
	 */
	public static function updateTable($table = null)
	{
		DEMO_MODE ? Json::echo(['message' => '演示站']) : null;
		$table = $table ? $table : @$_GET['table'];
		if (empty($table)) {
			Json::echo(['message' => '没有收到要操作的表']);
		}
		if (isset($_POST['fields']) && is_array($_POST['fields'])) {
			$fields = Db::name($table)->find($_REQUEST['id'])['fields'];
			if (is_array($fields)) {
				$_POST['fields'] = array_merge($fields, $_POST['fields']);
			}
		}
		$update = Db::name($table)->where('id', $_REQUEST['id'])->update($_POST);
		Json::echo($update ? ['code' => 200] : ['message' => '更新失败']);
	}

	/**
	 * 对表格进行插入操作
	 * @access public
	 */
	public static function insertTable($table = null)
	{
		DEMO_MODE ? Json::echo(['message' => '演示站']) : null;
		$table = $table ? $table : $_GET['table'];
		$insert = Db::name($table)->insert($_POST);
		Json::echo($insert ? ['code' => 200] : ['message' => '创建失败']);
	}

	/**
	 * 对表格指定字段进行删除
	 * @access public
	 */
	public static function deleteTable($table = null, $id = null)
	{
		DEMO_MODE ? Json::echo(['message' => '演示站']) : null;
		$table = $table ? $table : @$_GET['table'];
		$id = is_null($id) ? @$_GET['id'] : $id;
		if (empty($table) || !isset($id)) {
			Json::echo(['message' => '缺少有效参数']);
		}
		$delete = Db::name($table)->where('id', $id)->deleteAll();
		Json::echo($delete ? ['code' => 200, 'message' => '删除成功'] : ['message' => 'JsonDb删除失败']);
	}

	/**
	 * 对表格指定字段状态调整
	 * @access public
	 */
	public static function fieldStatus($table = null, $id = null)
	{
		DEMO_MODE ? Json::echo(['message' => '演示站']) : null;
		$table = $table ? $table : @$_POST['table'];
		$id = is_null($id) ? @$_POST['id'] : $id;
		if (empty($table) || !isset($id)) {
			Json::echo(['message' => '缺少有效参数']);
		}
		$status = isset(Db::name($table)->find($id)['status']) ? Db::name($table)->find($id)['status'] : 0;
		if ($status) {
			$update = Db::name($table)->where('id', $id)->update(['status' => 0]);
			$message = '禁用';
		} else {
			$update = Db::name($table)->where('id', $id)->update(['status' => 1]);
			$message = '激活';
		}
		Json::echo($update ? ['code' => 200, 'message' => $message . '成功'] : ['message' => 'JsonDb' . $message . '失败']);
	}

	/**
	 * 获取友链列表
	 * @access public
	 */
	public static function getLink()
	{
		$table = $_GET['table'];
		$DB = Db::name($table);
		$total = $DB->count();
		if (isset($_GET['class']) && $_GET['class'] != 'all') {
			$DB->where('cid', $_GET['class']);
			$total = count($DB->filterResult);
		}
		$rows = $DB->select();
		foreach ($rows as $key => $value) {
			$sort = Db::name('sort')->where('id', $value['cid'])->find();
			$rows[$key]['sort'] = empty($sort) ? '暂无分类' : $sort['title'];
		}
		Json::echo([
			'rows' => $rows,
			'total' => $total
		]);
	}

	/**
	 * 修改当前登录管理员密码
	 * @access public
	 */
	public static function editPWD()
	{
		DEMO_MODE ? Json::echo(['message' => '演示站']) : null;
		$oldpwd = $_POST['oldpwd'];
		$newpwd = $_POST['newpwd'];
		$confirmpwd = $_POST['confirmpwd'];
		if ($newpwd !== $confirmpwd) {
			Json::echo([
				'message' => '新旧密码不一'
			]);
		}
		$admin = Admin::info();
		if ($oldpwd !== $admin['pwd']) {
			Json::echo([
				'message' => '旧密码错误'
			]);
		}
		$update = Db::name('admin')->where('id', $admin['id'])->update([
			'pwd' => $newpwd
		]);
		Json::echo($update ? ['code' => 200, 'message' => '修改密码成功，请从新登录'] : ['message' => 'JsonDb修改密码失败']);
	}
}
