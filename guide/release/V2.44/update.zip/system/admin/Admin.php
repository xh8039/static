<?php

namespace system\admin;

use JsonDb\JsonDb\Db;

class Admin
{

	private static $admin_info = [];

	/**
	 * 系统管理员检测
	 * @access public
	 * @return bool
	 */
	public static function auth()
	{
		if (empty($_SESSION['admin'])) return false;
		$info = Db::name('admin')->where([
			'user' => $_SESSION['admin']['user'],
			'pwd' => $_SESSION['admin']['pwd'],
			'status' => 1
		])->find();
		if (empty($info)) return false;
		return $info;
	}

	/**
	 * 获取当前管理员信息
	 * @access public
	 * @return array|null 成功则以数组形式返回管理员信息
	 */
	public static function info()
	{
		$user = $_SESSION['admin']['user'];
		$pwd = $_SESSION['admin']['pwd'];
		if (empty(self::$admin_info[$user])) {
			self::$admin_info[$user] = Db::name('admin')->where([
				'user' => $user,
				'pwd' => $pwd,
				'status' => 1
			])->find();
		}
		return self::$admin_info[$user];
	}

	/**
	 * 后台admin页面检查是否为管理员
	 * @access public
	 * @return string|true 不是管理员则返回跳转到登录页面的JS代码
	 */
	public static function check($type = 'html')
	{
		if (APP_DEBUG) {
			$_SESSION['admin'] = current(Db::name('admin')->select());
			return true;
		}
		function error()
		{
			sysmsg('<span style="color: red;">' . base64_decode('5qOA5rWL5Yiw5oKo55uu5YmN5L2/55So55qE57O757uf5a2Y5Zyo5q6L57y65oOF5Ya177yM5pWw5o2u5rOE6Zyy44CB5o2f5aSx44CB5ZKMQlVH5ryP5rSe562J5Lil6YeN6Zeu6aKY5Lya6auY5qaC546H5oyB57ut5a2Y5Zyo77yM5bm25LiU5p6B5piT6KKr5LiN5rOV6buR5a6i5YWl5L615pyN5Yqh5Zmo6YCg5oiQ5oKo55qE6LSi5Lqn5o2f5aSx77yM6K+35bC95b+rIDxhIGhyZWY9Imh0dHA6Ly9ndWlkZS5icmk2LmNuIiB0YXJnZXQ9Il9ibGFuayI+5YmN5b6A5a6Y572RPC9hPiDkuIvovb3mmJPoiKrnvZHlnYDlvJXlr7zns7vnu5/lrpjmlrnmraPniYjnqIvluo8=') . '</span>');
		}
		function md5_files($file_list)
		{
			foreach ($file_list as $file => $md5) {
				if (!file_exists($file)) error();
				// halt(md5_file($file));
				if (md5_file($file) !== $md5) error();
			}
		}
		md5_files(options('files_md5:' . VERSION));
		if (DEMO_MODE) $_SESSION['admin'] = current(Db::name('admin')->select());
		if (!self::auth()) {
			if ($type == 'html') {
				$referrer = urlencode($_SERVER['REQUEST_URI']);
				exit("<script language='javascript'>window.location.href='./login.php?referrer=$referrer';</script>");
			}
			if ($type == 'json') {
				\system\library\Json::echo(['message' => '请先登录后再进行操作']);
			}
		}
		return true;
	}
}
