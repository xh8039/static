<?php

namespace system\theme;

use system\admin\Server;
use system\library\System;
use system\library\Statics;

class Method
{

	private $__options = [];

	public $site;

	public string $domain = DOMAIN;

	public $options;

	public $system;

	public string $themeUrl;

	public function __construct($theme = THEME)
	{
		global $site;
		global $options;
		$this->__options['theme'] = $theme;
		$this->system = System::arrayToObject($options);
		$this->site = System::arrayToObject($site);
		$this->site->url = 'http://' . DOMAIN;
		$this->site->background = $options['theme']['background'];
		$this->options = $this->options();
		$this->themeUrl = '//' . DOMAIN . '/content/themes/' . $theme;
	}

	/**
	 * 加载主题文件
	 * @param string $mod
	 */
	public function __load(string $mod)
	{
		$theme_file = Manager::getFile($mod, $this->__options['theme']);
		if ($theme_file) {
			$this->__options['mod'] = $mod;
			// 注册插件
			\system\plugin\Manager::register();
			// 触发插件默认实现方法
			\system\plugin\Manager::trigger('render');
			// 获取主题公共文件
			$public_file = Manager::getFile('public/common', $this->__options['theme']);
			// 引入主题公共文件
			if ($public_file) include_once $public_file;
			// 引入请求的主题文件
			return include_once $theme_file;
		} else {
			System::response404();
		}
	}

	public function is($name)
	{
		if ($this->__options['mod'] == $name) {
			return true;
		}
		return false;
	}

	/**
	 * 生成前台主题URL
	 * @param $name URL名称
	 * @param $param URL参数
	 */
	public function buildUrl($name, $param = null)
	{
		global $options;
		if ($this->__options['theme'] != THEME) {
			$param['theme'] = $this->__options['theme'];
		}
		$name = urlencode($name);
		if ($options['rewrite']) {
			$url = 'http://' . DOMAIN . '/' . $name . '.html';
		} else {
			$url = 'http://' . DOMAIN . '/index.php?s=/' . $name;
		}
		if ($param) {
			$param = http_build_query($param);
			$url = strstr($url, '?') ? trim($url, '&') . '&' .  $param : $url . '?' .  $param;
		}
		return $url;
	}

	/**
	 * 通过自有函数输出HTML头部信息
	 */
	public function header()
	{
		// 触发插件header方法
		\system\plugin\Manager::trigger('header');
		$header = <<<HTML
		<meta charset="UTF-8">
		<meta name="referrer" content="no-referrer" />
		<meta http-equiv="content-language" content="zh-cn" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<link rel="shortcut icon" href="{$this->site->favicon}" />
		<meta name="keywords" content="{$this->site->keywords}" />
		<meta name="description" content="{$this->site->description}" />
		<link rel="icon" href="{$this->site->favicon}" type="images/ico">
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<link rel="icon" href="{$this->site->favicon}" type="image/x-icon">
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		HTML;
		return $header . PHP_EOL;
	}

	public function footer()
	{
		// 触发插件footer方法
		\system\plugin\Manager::trigger('footer');
		return null;
	}

	public function options($value = null)
	{
		$options = Manager::options($this->__options['theme']);
		if (is_null($value)) {
			return (object) $options;
		}
		return isset($options[$value]) ? $options[$value] : null;
	}

	public function getSort($id = null)
	{
		$sort = System::getSort($id);
		foreach ($sort as $key => $value) {
			$sort[$key]['fields'] = isset($value['fields'][$this->__options['theme']]) ? $value['fields'][$this->__options['theme']] : (object) [];
		}
		return System::arrayToObject($sort);
	}

	public function getLink($cid = null)
	{
		$link = System::getLink($cid);
		foreach ($link as $key => $value) {
			$link[$key]['fields'] = isset($value['fields'][$this->__options['theme']]) ? $value['fields'][$this->__options['theme']] : (object) [];
		}
		return System::arrayToObject($link);
	}

	public function getSortLink()
	{
		$list = $this->getSort();
		foreach ($list as $key => $value) {
			$value->link = $this->getLink($value->id);
		}
		return $list;
	}

	public function getFriend()
	{
		$friend = System::getFriend();
		return System::arrayToObject($friend);
	}

	public function include($path)
	{
		include_once THEME_PATH . $this->__options['theme'] . DIRECTORY_SEPARATOR . $path;
	}

	/**
	 * 输出CDN
	 *
	 * @param string|null $path 子路径
	 * @return string
	 */
	public function cdn($path)
	{
		return cdn($path);
	}

	/**
	 * 输出主题资源路径
	 *
	 * @param string|null $path 子路径
	 * @return string
	 */
	public function themeUrl($path, $version = true)
	{
		if ($version) {
			$version = $this->info('version');
			$version = "?version=$version";
		} else {
			$version = '';
		}
		$url = '//' . DOMAIN . '/content/themes/' . $this->__options['theme'] . "/$path" . $version;
		return $url;
	}

	public function load($file, $attr = [])
	{
		return Statics::load($file, $attr);
	}

	public function jsdelivr($path)
	{
		$version = $this->info('version');
		$theme = $this->__options['theme'];
		$url = "content/themes/$theme/$path";
		return jsdelivr($url, $version);
	}

	public function gitee($path, $version = null)
	{
		$theme = $this->__options['theme'];
		$url = "content/themes/$theme/$path";
		if (is_null($version)) {
			$version = $this->info('version');
		}
		return Statics::gitee($url, $version);
	}

	public function auth()
	{
		return Server::auth();
	}

	public function info($name = null)
	{
		static $info = null;
		if (is_null($info)) {
			$info = Manager::getInfo($this->__options['theme']);
		}
		if (is_null($name)) {
			return $info;
		}
		if (isset($info[$name])) {
			return $info[$name];
		}
		return null;
	}
}
