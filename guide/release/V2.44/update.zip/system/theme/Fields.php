<?php

namespace system\theme;

use system\admin\Form as AdminForm;

class Fields
{

	private $options;

	private $fields;

	public function __construct(array $options)
	{
		$this->options = $options;
		$this->fields = isset($this->options['fields'][THEME]) ? $this->options['fields'][THEME] : [];
	}

	private function field(&$name, &$value)
	{
		$theme = THEME;
		if (preg_match('/(\w+)\[(\w+)\]/', $name, $match)) {
			$sort = $match[1];
			$sort_name = $match[2];
			$value = isset($this->fields[$sort][$sort_name]) ? $this->fields[$sort][$sort_name] : $value;
			$name = "fields[$theme][$sort][$sort_name]";
		} else {
			$value = isset($this->fields[$name]) ? $this->fields[$name] : $value;
			$name = "fields[$theme][$name]";
		}
		$value = $value ? htmlentities($value) : $value;
	}

	public function input($title, $name, $value = null, $type = 'text', $tip = null, $options = [])
	{
		$this->field($name, $value);
		echo AdminForm::input($title, $name, $value, $type, $tip, $options);
	}

	public function color($title, $name, $value = null, $tip = null, $options = [])
	{
		$this->field($name, $value);
		echo AdminForm::color($title, $name, $value, $tip, $options);
	}

	public function select($title, $name, $list = [], $value = null, $tip = null, $options = [])
	{
		$this->field($name, $value);
		echo AdminForm::select($title, $name, $list, $value, $tip, $options);
	}

	public function textarea($title, $name, $value = null, $tip = null, $options = [])
	{
		$this->field($name, $value);
		echo AdminForm::textarea($title, $name, $value, $tip, $options);
	}

	public function addInput($input)
	{
		// echo $input;
	}
}
