<?php

namespace system\library;

class Statics
{
	public static function load($file, $attr = [])
	{
		$file_url = explode('?', $file, 2)[0];
		$extension = pathinfo($file_url)['extension'];
		$html = null;
		$attr['referrer'] = 'no-referrer';
		if ($extension == 'css') {
			$link = element('link');
			$attr['rel'] = isset($attr['rel']) ? $attr['rel'] : 'stylesheet';
			$attr['href'] = $file_url;
			$link->attr($attr);
			$html = $link->get(false);
		}
		if ($extension == 'js') {
			$script = element('script');
			$attr['src'] = $file_url;
			$script->attr($attr);
			$html = $script->get();
		}
		// print_r($html);exit;
		return $html . PHP_EOL;
	}

	public static function version($url, $version = VERSION)
	{
		if ($version && (strstr($url, 'version=') !== false)) {
			return $url .= '?version=' . $version;
		}
		return $url;
	}

	public static function gitee($path, $version = VERSION)
	{
		$url = 'https://gitee.com/yh_IT/static/raw/master/guide/' . $path;
		return self::version($url, $version);
	}

	public static function LightYear($path, $version = VERSION)
	{
		$url = (Request::isSsl() ? 'https://gitee.com/yinqi/Light-Year-Admin-Template-v5/raw/master/' : 'http://lyear.itshubao.com/v5/') . $path;
		return self::version($url, $version);
	}

	public static function github()
	{
		static $github = null;
		if (is_null($github)) $github = new class()
		{
			private $url_list = [
				'https://github.com/xh8039/static/',
				'https://cdn.jsdelivr.net/gh/xh8039/static/',
				'https://cdn.staticaly.com/gh/xh8039/static/master/',
				'https://cdn.statically.io/gh/xh8039/static/master/',
			];
			private function path($path = null)
			{
				return $this->url_list[1] . $path;
			}
			public function LightYear($path, $version = VERSION)
			{
				return $this->version($this->path('template/light-year/v5/' . $path), $version);
			}
			public function guide($path, $version = VERSION)
			{
				return $this->version($this->path('guide/' . $path), $version);
			}
			public function url($path, $version = VERSION)
			{
				return $this->version($this->path($path), $version);
			}
			private function version($path, $version = VERSION)
			{
				return \system\library\Statics::version($path, $version);
			}
		};
		return $github;
	}

	public static function image($url, $attr = [])
	{
		$attr['referrer'] = 'no-referrer';
		$attr['src'] = $url;
		return element('img')->attr($attr);
	}
}
