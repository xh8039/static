<?php

namespace system\library;

use JsonDb\JsonDb\Db;

class Options
{
	private static $options = null;

	public static function initialize()
	{
		if (is_null(self::$options)) {
			$select = Db::name('options')->select();
			self::$options = [];
			foreach ($select as $value) {
				self::$options[$value['name']] = $value['value'];
			}
		}
	}

	public static function get($name)
	{
		return isset(self::$options[$name]) ? self::$options[$name] : null;
	}

	public static function all()
	{
		return self::$options;
	}

	public static function save(string $name, $value)
	{
		// 保存虚拟模型数据
		self::model($name, $value);
		return Db::name('options')->save(['name' => $name, 'value' => $value], 'name');
	}

	public static function insert(string $name, $value)
	{
		// 插入虚拟模型数据
		self::model($name, $value);
		// 插入数据库数据
		return Db::name('options')->insert(['name' => $name, 'value' => $value]);
	}

	/**
	 * 设置虚拟模型数据
	 */
	public static function model(string $name, $value)
	{
		global $options;
		$options[$name] = $value;
		self::$options[$name] = $value;
		return true;
	}

	public static function update(string $name, $value)
	{
		// 更新虚拟模型数据
		self::model($name, $value);
		// 更新数据库数据
		return Db::name('options')->where('name', $name)->update(['value' => $value]);
	}
}
