<?php

namespace system\library;

class Json
{

	/** 筛选后的结果 */
	public static $filterResult;

	/** 要操作的Json文件 */
	public static $jsonFile;

	/**
	 * 校验JSON字符串
	 * @param string $stringData
	 * @return bool
	 */
	public static function isJsonString($stringData)
	{
		if (empty($stringData)) return false;
		try {
			//校验json格式
			json_decode($stringData, true);
			return JSON_ERROR_NONE === json_last_error();
		} catch (\Exception $e) {
			return false;
		}
	}

	/**
	 * 保存数据
	 * @access public
	 * @param array $array 要保存或更新的数据
	 * @return integer 返回保存或更新的数据数量
	 */
	public static function save(array $array)
	{
		if (!file_exists(self::$jsonFile)) {
			return self::arrayFile($array);
		}
		$file = self::jsonFile();
		$update = 0;
		foreach ($array as $key => $value) {
			$update++;
			$file[$key] = $value;
		}
		self::arrayFile($file);
		self::$filterResult = false;
		return $update;
	}

	/**
	 * 查询多条数据
	 * @access public
	 * @return array
	 */
	public static function select()
	{
		$where = self::$filterResult ? self::$filterResult : self::jsonFile();
		self::$filterResult = false;
		if (empty($where)) {
			return [];
		}
		return $where;
	}

	/**
	 * 获取JSON格式的数据表
	 * @access public
	 * @param string $option 默认为空 值为id时返回包括ID的数组数据
	 * @return array|false
	 */
	public static function jsonFile()
	{
		if (!file_exists(self::$jsonFile)) {
			return [];
		}
		$data = file_get_contents(self::$jsonFile);
		$data = json_decode($data, true);
		return $data;
	}

	/**
	 * 将数组数据存储到JSON数据表中
	 * @access private
	 * @param array $array 要存储的数组数据
	 * @return int|false 成功则返回存储数据的总字节，失败则返回false
	 */
	private static function arrayFile(array $array)
	{
		$data = self::encode($array);
		if (!file_exists(self::$jsonFile)) {
			$dir = preg_replace('/\\[\w,\.]+$/', self::$jsonFile, '');
			print_r($dir);
			// mkdir(self::$jsonFile, 0755, true);
		}
		return file_put_contents(self::$jsonFile, $data);
	}

	/**
	 * 根据字段条件过滤数组中的元素
	 * @access public
	 * @param string $field_name 字段名
	 * @param mixed  $field_value 字段值
	 * @return self
	 */
	public static function where($field_name, $field_value = null)
	{
		$file = self::$filterResult ? self::$filterResult : self::jsonFile();
		if (!is_array($file)) {
			self::$filterResult = [];
			return self::class;
		}
		$data = [];
		foreach ($file as $key => $value) {
			if (@$value[$field_name] == $field_value) {
				$data[$key] = $file[$key];
			} else {
				unset($data[$key]);
			}
		}
		self::$filterResult = $data;
		return self::class;
	}

	public static function encode($data)
	{
		/**
		 * JSON_NUMERIC_CHECK 将所有数字字符串编码成数字
		 * JSON_PRETTY_PRINT 用空白字符格式化返回的数据
		 * JSON_UNESCAPED_UNICODE 以字面编码多字节 Unicode 字符（默认是编码成 \uXXXX）
		 * JSON_UNESCAPED_SLASHES 不要编码 /
		 */
		return json_encode($data, JSON_NUMERIC_CHECK | JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
	}

	public static function decode($data, $type = true)
	{
		try {
			//校验json格式
			$decode = json_decode($data, $type);
			return json_last_error() === JSON_ERROR_NONE ? $decode : false;
		} catch (\Exception $e) {
			return false;
		}
	}

	public static function echo($data)
	{
		header('Content-type: application/json');
		echo self::encode($data);
		exit;
	}
}
