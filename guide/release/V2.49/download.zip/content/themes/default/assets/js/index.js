$(document).ready(() => {
	$('.yqlj a').attr({
		'target': '_blank'
	})
	$('#gb-ts').click(() => {
		$('.tishi').fadeOut('slow')
	})
})