<?php
$title = '编程资源 - ' . $this->site->title;
?>
<!DOCTYPE html>
<html lang="zh-cn">

<head>
    <title><?= $title ?></title>
    <?php $this->include('modules/head.php'); ?>
    
</head>

<body data-new-gr-c-s-check-loaded="14.980.0">
    <?php $this->include('modules/header.php'); ?>
    <div id="content" data-customize="true" data-CustomTheme="true" class="default-bg">
        <!--内容-->
        <div class="main-index">
            <div class="container content-box link-page">
                <h1 class="h1-resource" style="padding-top: 0">镜像网站</h1>
                <div>阿里云镜像: <a target="_blank" href="https://developer.aliyun.com/mirror/">https://developer.aliyun.com/mirror/</a></div>

                <h1 class="h1-resource">工具网站</h1>
                <div>大数分解: <a target="_blank" href="http://factordb.com/index.php">http://factordb.com/index.php</a></div>
                <div>MonoCloud: <a target="_blank" href="https://mymonocloud.com/">https://mymonocloud.com/</a></div>
                <div>资源管理器 PDF 拓展: <a target="_blank" href="https://coolsoft.altervista.org/en/pdfpropertyextension">https://coolsoft.altervista.org/en/pdfpropertyextension</a></div>
                <div>Mathematica 激活: <a target="_blank" href="https://tiebamma.github.io/InstallTutorial/">https://tiebamma.github.io/InstallTutorial/</a></div>
                <div>方正字体: <a target="_blank" href="https://www.foundertype.com/">https://www.foundertype.com/</a></div>

                <h1 class="h1-resource" style="padding-top: 0">终端美化</h1>
                <div>Oh-My-Posh: <a target="_blank" href="https://ohmyposh.dev/">https://ohmyposh.dev/</a></div>


                <h1 class="h1-resource">编程技术</h1>
                <h2 class="h2-resource">Git</h2>
                <div class="h2-resource">
                    <div>文档: <a target="_blank" href="https://git-scm.com/book/zh/v2">https://git-scm.com/book/zh/v2</a></div>
                    <div>交互学习: <a target="_blank" href="https://learngitbranching.js.org/?locale=zh_CN">https://learngitbranching.js.org/?locale=zh_CN</a></div>
                </div>

                <h2 class="h2-resource">Latex</h2>
                <div class="h2-resource">
                    <div>在线编辑: <a target="_blank" href="http://latex.codecogs.com/eqneditor/editor.php">http://latex.codecogs.com/eqneditor/editor.php</a></div>
                    <div>手写识别: <a target="_blank" href="http://detexify.kirelabs.org/classify.html">http://detexify.kirelabs.org/classify.html</a></div>
                    <div>Tikz 示例: <a target="_blank" href="http://www.texample.net/tikz/examples/">http://www.texample.net/tikz/examples/</a></div>
                    <div>Tikz 入门: <a target="_blank" href="http://cremeronline.com/LaTeX/minimaltikz.pdf">http://cremeronline.com/LaTeX/minimaltikz.pdf</a></div>
                    <div>入门文档: <a target="_blank" href="https://liam0205.me/2014/09/08/latex-introduction/">https://liam0205.me/2014/09/08/latex-introduction/</a></div>
                </div>

                <h2 class="h2-resource">Bash</h2>
                <div class="h2-resource">
                    <div>高级 Bash 脚本教程: <a target="_blank" href="http://www.tldp.org/LDP/abs/html/index.html">http://www.tldp.org/LDP/abs/html/index.html</a></div>
                </div>

                <h2 class="h2-resource">Jekyll</h2>
                <div class="h2-resource">
                    <div>中文教程: <a target="_blank" href="http://jekyllcn.com/docs/home/">http://jekyllcn.com/docs/home/</a></div>
                    <div>在 Windows 上安装: <a target="_blank" href="http://jekyll-windows.juthilo.com/">http://jekyll-windows.juthilo.com/</a></div>
                    <div>Liquid 模板语言: <a target="_blank" href="https://shopify.github.io/liquid/">https://shopify.github.io/liquid/</a></div>
                </div>

                <h2 class="h2-resource">前端</h2>
                <div class="h2-resource">
                    <div>ZUI HTML5 框架: <a target="_blank" href="https://www.openzui.com/">https://www.openzui.com/</a></div>
                    <div>Vue.js: <a target="_blank" href="https://learning.dcloud.io/#/?vid=3">https://learning.dcloud.io/#/?vid=3</a></div>
                    <div>highlight.js: <a target="_blank" href="https://highlightjs.org/">https://highlightjs.org/</a></div>
                    <div>图标字体库: <a target="_blank" href="https://fontawesome.dashgame.com/">https://fontawesome.dashgame.com/</a></div>
                    <div>图标字体库: <a target="_blank" href="https://fontawesome.com/start">https://fontawesome.com/start</a></div>
                    <div>highlight.js: <a target="_blank" href="https://highlightjs.org/">https://highlightjs.org/</a></div>
                    <div>表格转换: <a target="_blank" href="https://tableconvert.com/">https://tableconvert.com/</a></div>
                    <div>Google js 风格规范: <a target="_blank" href="https://google.github.io/styleguide/jsguide.html">https://google.github.io/styleguide/jsguide.html</a></div>

                </div>

                <h1 class="h1-resource">系统工具</h1>
                <h2 class="h2-resource">Linux</h2>
                <div class="h2-resource">
                    <div>Ubuntu 18.04 美化: <a target="_blank" href="https://www.cnblogs.com/feipeng8848/p/8970556.html">https://www.cnblogs.com/feipeng8848/p/8970556.html</a></div>
                    <div>Gnome-look: <a target="_blank" href="https://www.opendesktop.org/s/Gnome/browse/">https://www.opendesktop.org/s/Gnome/browse/</a></div>
                    <div>Linux 工具快速教程: <a target="_blank" href="https://linuxtools-rst.readthedocs.io/zh_CN/latest/index.html#">https://linuxtools-rst.readthedocs.io/zh_CN/latest/index.html#</a></div>
                    <div>systemd 入门: <a target="_blank" href="http://www.ruanyifeng.com/blog/2016/03/systemd-tutorial-commands.html">http://www.ruanyifeng.com/blog/2016/03/systemd-tutorial-commands.html</a></div>
                    <div>screen 命令: <a target="_blank" href="http://www.cnblogs.com/mchina/archive/2013/01/30/2880680.html">http://www.cnblogs.com/mchina/archive/2013/01/30/2880680.html</a></div>
                    <div>sftp 命令: <a target="_blank" href="https://blog.csdn.net/jesseyoung/article/details/42523903">https://blog.csdn.net/jesseyoung/article/details/42523903</a></div>
                    <div>wget 命令: <a target="_blank" href="http://blog.csdn.net/chenbang110/article/details/7854384">http://blog.csdn.net/chenbang110/article/details/7854384</a></div>
                </div>

                <h1 class="h1-resource">公开API</h1>
                <div>搜索引擎智能提示: <a target="_blank" href="https://blog.51cto.com/1095221645/1916022">https://blog.51cto.com/1095221645/1916022</a></div>
                <div>每日一句: <a target="_blank" href="https://developer.hitokoto.cn/sentence/#%E7%AE%80%E4%BB%8B">https://developer.hitokoto.cn/sentence/#%E7%AE%80%E4%BB%8B</a></div>
            </div>
        </div>
    </div>
    <?php $this->include('modules/footer.php'); ?>
</body>

</html>