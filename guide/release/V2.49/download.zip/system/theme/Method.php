<?php

namespace system\theme;

use JsonDb\JsonDb\Db;
use system\admin\Server;
use system\library\Statics;

class Method
{

	private $__options = [];

	public $site;

	public $options;

	public $system;

	public string $themeUrl;

	public string $themeName;

	public function __construct($theme = THEME)
	{
		$this->themeName = $theme;
		$this->system = array_to_object(options());
		$this->site = array_to_object(options('site'));
		$this->site->domain = DOMAIN;
		$this->site->url = 'http://' . DOMAIN;
		$this->site->background = (empty(options('theme.background')) ? Statics::background_image() : options('theme.background'));
		$this->options = $this->options();
		$this->themeUrl = '//' . DOMAIN . '/content/themes/' . $theme;
	}

	/**
	 * 加载主题文件
	 * @param string $mod
	 */
	public function __load(string $mod, array $params = [])
	{
		$theme_file = Manager::getFile($mod, $this->themeName);
		if ($theme_file) {
			$this->__options['mod'] = $mod;
			if ($this->auth()) {
				// 注册插件
				\system\plugin\Manager::register();
				// 触发插件默认实现方法
				\system\plugin\Manager::trigger('render');
			}
			// 获取主题公共文件
			$public_file = Manager::getFile('public/common', $this->themeName);
			// 引入主题公共文件
			if ($public_file) include_once $public_file;
			$theme = $this;
			$GLOBALS['theme_method'] = $this;
			// 赋值变量
			foreach ($params as $key => $value) {
				if (empty($key) || is_numeric($key)) continue;
				${$key} = $value;
			}
			// 引入请求的主题文件
			$require = require_once $theme_file;
			// 统计访问量
			$visits = options('visits');
			if (!is_array($visits)) {
				options('visits', [DATE => 1]);
			} else {
				empty($visits[DATE]) ? $visits[DATE] = 1 : $visits[DATE]++;
				options('visits', $visits);
			}
			return $require;
		} else {
			response404();
		}
	}

	public function is($name)
	{
		if ($this->__options['mod'] == $name) {
			return true;
		}
		return false;
	}

	/**
	 * 生成前台主题URL
	 * @param $name URL名称
	 * @param $param URL参数
	 */
	public function buildUrl($name, $param = null)
	{
		if ($this->themeName != THEME) {
			$param['theme'] = $this->themeName;
		}
		$name = urlencode($name);
		if (options('rewrite')) {
			$url = 'http://' . DOMAIN . '/' . $name . '.html';
		} else {
			$url = 'http://' . DOMAIN . '/index.php?s=/' . $name;
		}
		if ($param) {
			$param = http_build_query($param);
			$url = strstr($url, '?') ? trim($url, '&') . '&' .  $param : $url . '?' .  $param;
		}
		return $url;
	}

	/**
	 * 通过自有函数输出HTML头部信息
	 */
	public function header()
	{
		// 触发插件header方法
		\system\plugin\Manager::trigger('header');
		$header = <<<HTML
		<meta charset="UTF-8">
		<!-- <meta name="referrer" content="no-referrer" /> -->
		<meta http-equiv="content-language" content="zh-cn" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<link rel="shortcut icon" href="{$this->site->favicon}" />
		<meta name="keywords" content="{$this->site->keywords}" />
		<meta name="description" content="{$this->site->description}" />
		<link rel="icon" href="{$this->site->favicon}" type="images/ico">
		<link rel="apple-touch-icon" href="{$this->site->favicon}">
		<link rel="icon" href="{$this->site->favicon}" type="image/x-icon">
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		HTML;
		return $header . PHP_EOL;
	}

	public function footer()
	{
		// 触发插件footer方法
		\system\plugin\Manager::trigger('footer');
		return null;
	}

	public function options($value = null, $default = null)
	{
		$options = Manager::options($this->themeName);
		if (is_null($value)) {
			return (object) $options;
		}
		return isset($options[$value]) ? $options[$value] : $default;
	}

	public function optionMulti($name, $line = "\r\n", $separator = '||')
	{
		if (empty($this->options->$name)) {
			return null;
		}
		$option = $this->options->$name;
		$custom = [];
		$custom_arr = explode($line, $option);
		foreach ($custom_arr as $key => $value) {
			if ($separator) {
				$custom[] = explode($separator, $value);
			} else {
				$custom[] = $value;
			}
		}
		return $custom;
	}

	public function getSort($id = null)
	{
		$sort = get_sort($id);
		if (is_numeric($id)) {
			$sort['fields'] = isset($sort['fields'][$this->themeName]) ? $sort['fields'][$this->themeName] : (object) [];
		} else {
			foreach ($sort as $key => $value) {
				$sort[$key]['fields'] = isset($value['fields'][$this->themeName]) ? $value['fields'][$this->themeName] : (object) [];
			}
		}
		return array_to_object($sort);
	}

	public function getSite($id, $object = true)
	{
		$site = Db::name('site')->find($id);
		if ($object) {
			$site['fields'] = $site['fields'][$this->themeName] ?? (object) [];
		} else {
			$site['fields'] = $site['fields'][$this->themeName] ?? [];
		}
		return $object ? array_to_object($site) : $site;
	}

	public function getSites($sort_id = null, $fields = [], $object = true)
	{
		$site = get_sites($sort_id);
		return $this->convertFields($site, $fields, $object);
	}

	/**
	 * 通过关键词获取站点
	 */
	public function getLikeSites(string $keyword, array $fields = ['title', 'url'], int $length = null, int $offset = 0)
	{
		$fields = implode('|', $fields);
		$select = Db::name('site')->where('status', 1)->limit($offset, $length)->whereLike($fields, $keyword);
		$data = $select->select();
		return $this->convertFields($data);
	}

	public function convertFields(array $data, $fields = [], $object = true)
	{
		foreach ($data as $key => $value) {
			if ($object) {
				$data[$key]['fields'] = isset($value['fields'][$this->themeName]) ? $value['fields'][$this->themeName] : (object) [];
			} else {
				$data[$key]['fields'] = isset($value['fields'][$this->themeName]) ? $value['fields'][$this->themeName] : [];
			}
			if (!empty($fields) && is_array($fields)) {
				foreach ($fields as $field_key => $field_value) {
					if (!isset($value['fields'][$this->themeName][$field_key]) || $value['fields'][$this->themeName][$field_key] != $field_value) {
						unset($data[$key]);
					}
				}
			}
		}
		return $object ? (array) array_to_object($data) : $data;
	}

	public function getSortSites()
	{
		$list = $this->getSort();
		foreach ($list as $key => $value) {
			$value->sites = $this->getSites($value->id);
		}
		return $list;
	}

	public function getFriend()
	{
		$friend = get_friend();
		return array_to_object($friend);
	}

	/**
	 * include引入主题文件
	 * @param string $path 文件路径
	 * @param array $params 赋值变量
	 */
	public function include(string $path, array $params = [])
	{
		foreach ($params as $key => $value) {
			if (empty($key) || is_numeric($key)) continue;
			${$key} = $value;
		}
		include_once THEME_PATH . $this->themeName . DIRECTORY_SEPARATOR . $path;
	}

	/**
	 * require引入主题文件
	 * @param string $path 文件路径
	 * @param array $params 赋值变量
	 */
	public function require(string $path, array $params = [])
	{
		// 赋值变量
		foreach ($params as $key => $value) {
			if (empty($key) || is_numeric($key)) continue;
			${$key} = $value;
		}
		require_once THEME_PATH . $this->themeName . DIRECTORY_SEPARATOR . $path;
	}

	/**
	 * 输出CDN
	 *
	 * @param string|null $path 子路径
	 * @return string
	 */
	public function cdn($path)
	{
		return cdn($path);
	}

	/**
	 * 输出主题资源路径
	 *
	 * @param string|null $path 子路径
	 * @return string
	 */
	public function themeUrl($path, $version = true)
	{
		if ($version) {
			$version = $this->info('version');
			$version = "?version=$version";
		} else {
			$version = '';
		}
		$url = '//' . DOMAIN . '/content/themes/' . $this->themeName . "/$path" . $version;
		return $url;
	}

	public function load($file, $attr = [])
	{
		return Statics::load($file, $attr);
	}

	public function auth()
	{
		return Server::isAuth();
	}

	public function info($name = null)
	{
		static $info = null;
		if (is_null($info)) $info = Manager::getInfo($this->themeName);
		if (is_null($name)) return $info;
		if (isset($info[$name])) return $info[$name];
		return null;
	}
}
