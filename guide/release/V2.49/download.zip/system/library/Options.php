<?php

namespace system\library;

use JsonDb\JsonDb\Db;

class Options
{
	private static $options = null;

	public static function initialize()
	{
		if (is_null(self::$options)) {
			$select = Db::name('options')->select();
			self::$options = [];
			foreach ($select as $value) {
				self::$options[$value['name']] = $value['value'];
			}
		}
	}

	public static function get($name)
	{
		if (strpos($name, 'files_md5:') === 0) return isset(self::$options[$name]) ? self::$options[$name] : null;
		$name_list = explode('.', $name); // 将路径分解成键名数组
		$value = self::$options; // 初始化$value为数组的根
		// 遍历键名数组，逐级深入到数组中
		foreach ($name_list as $name_value) {
			if (isset($value[$name_value])) {
				$value = $value[$name_value]; // 如果键存在，更新$value
			} else {
				return null; // 如果键不存在，返回null或者你可以选择抛出异常
			}
		}
		return $value; // 返回最终找到的值
	}

	public static function all()
	{
		return self::$options;
	}

	public static function save(string $name, $value)
	{
		// 保存虚拟模型数据
		self::model($name, $value);
		return Db::name('options')->save(['name' => $name, 'value' => $value], 'name');
	}

	public static function insert(string $name, $value)
	{
		// 插入虚拟模型数据
		self::model($name, $value);
		// 插入数据库数据
		return Db::name('options')->insert(['name' => $name, 'value' => $value]);
	}

	/**
	 * 设置虚拟模型数据
	 */
	public static function model(string $name, $value)
	{
		self::$options[$name] = $value;
		return true;
	}

	public static function update(string $name, $value)
	{
		// 更新虚拟模型数据
		self::model($name, $value);
		// 更新数据库数据
		return Db::name('options')->where('name', $name)->update(['value' => $value]);
	}
}
