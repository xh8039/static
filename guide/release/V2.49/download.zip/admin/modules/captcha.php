<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-29 01:22:42
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 goto vaQeN; SvW3Z: require $_SERVER["\104\x4f\x43\x55\x4d\105\x4e\124\137\122\x4f\117\124"] . "\x2f\x73\x79\x73\x74\x65\155\x2f\x6c\x69\142\x72\141\x72\x79\57\x43\141\x70\164\x63\150\x61\x2e\160\x68\x70"; goto wV24n; C8ssl: $D7aLN->doimg(); goto ea8kE; wV24n: $D7aLN = new system\library\Captcha(); goto C8ssl; vaQeN: session_start(); goto SvW3Z; ea8kE: $_SESSION["\x61\144\x6d\151\x6e\137\143\141\160\164\143\x68\x61"] = $D7aLN->getCode();
