<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-29 01:22:42
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 use system\admin\View; use system\theme\Manager; goto XhSB3; r2Wgf: View::card($kQuCe["\x74\x69\164\x6c\145"] . $title, function () { goto p7hTa; kXuMq: echo "\x9\11\74\x66\157\x72\155\40\141\143\x74\151\x6f\x6e\x3d\42\x61\160\151\56\160\x68\x70\x3f\141\143\x74\x69\157\156\x3d\x74\x68\x65\x6d\x65\x53\145\x74\x22\x20\x6d\145\164\x68\157\x64\x3d\42\160\x6f\163\164\42\x20\x63\x6c\x61\x73\163\75\x22\164\150\x65\x6d\145\x53\x65\164\42\76\xd\12\x9\11\x9"; goto dVi5f; p7hTa: if (Manager::needFile("\x70\165\142\x6c\151\143\x2f\x66\x75\156\143\164\151\157\x6e\163") && function_exists("\x74\x68\x65\x6d\145\137\143\x6f\x6e\x66\151\147")) { goto Jjv3Z; } goto sEf1_; YkZ8k: define("\x54\110\105\115\x45\x5f\x53\x45\124", true); goto kXuMq; n5JgS: UBgxg: goto K5If5; nsaNH: echo "\11\x9\11\74\144\151\x76\40\143\x6c\141\x73\x73\x3d\x22\x64\x2d\x67\x72\151\x64\42\x3e\15\xa\x9\11\x9\11\74\142\165\164\x74\x6f\156\x20\x74\x79\x70\x65\75\42\163\x75\x62\155\151\164\42\x20\143\154\141\163\x73\75\42\x62\x74\x6e\x20\142\x74\156\x2d\160\x72\151\155\x61\x72\171\42\76\344\277\235\xe5\255\230\xe4\xb8\xbb\xe9\242\x98\350\256\xbe\347\275\256\x3c\x2f\x62\165\164\x74\x6f\156\x3e\15\xa\x9\x9\11\x3c\57\144\x69\166\x3e\15\xa\x9\11\x3c\x2f\146\x6f\x72\x6d\76\xd\xa"; goto n5JgS; dVi5f: theme_config(new \system\theme\Form()); goto nsaNH; jdsCW: goto UBgxg; goto W5pWS; W5pWS: Jjv3Z: goto YkZ8k; sEf1_: echo "\346\234\254\344\270\xbb\xe9\242\230\xe6\232\202\xe6\x97\240\350\207\xaa\345\xae\x9a\344\xb9\x89\350\xae\276\xe7\275\256"; goto jdsCW; K5If5: }); goto F343v; XhSB3: $title = "\344\270\xbb\xe9\242\x98\350\xae\xbe\xe7\xbd\xae"; goto ASsb4; F343v: include "\x6d\x6f\x64\x75\154\x65\x73\x2f\x66\x6f\x6f\164\x65\x72\x2e\x70\150\x70"; goto KRL4S; chlbr: $kQuCe = Manager::getInfo(); goto r2Wgf; ASsb4: include "\155\x6f\144\x75\154\x65\163\57\x68\x65\141\144\x65\162\56\160\150\160"; goto chlbr; KRL4S: echo system\admin\Form::script("\x74\x68\145\155\145\123\145\x74", "\344\277\x9d\345\xad\x98\xe4\270\273\xe9\xa2\x98\350\xae\xbe\xe7\275\256");
