<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-29 01:22:42
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 use system\admin\Form; use system\plugin\Manager; goto pKIxN; AXjM_: $bwtIL = "\x70\154\x75\x67\x69\156\x53\145\164"; goto VWKuR; U0BBf: include "\x6d\x6f\144\x75\154\145\x73\x2f\151\x66\x72\x61\155\145\x2e\x70\x68\160"; goto IRsu9; IRsu9: include_once ROOT . "\163\x79\x73\164\x65\x6d\x2f\160\154\x75\147\x69\156\x2f\106\x72\157\x6d\56\160\150\x70"; goto AXjM_; wFmtR: $A2nx4 = (function () use($iDxng) { goto vHFys; GgM2x: $RmZO7 = PLUGINS_ROOT . $iDxng["\156\x61\155\145"] . DIR_SEP . "\x50\x6c\165\147\x69\x6e\x2e\x70\150\160"; goto vJbIl; JIZMZ: include_once $RmZO7; goto P_xHo; uQ7Z_: return $A2nx4; goto TmMFD; SAy5H: ztamt: goto tAJ8d; P_xHo: if (!method_exists($iDxng["\x63\x6c\x61\x73\163"], "\143\x6f\x6e\x66\151\x67")) { goto ztamt; } goto cswlv; vJbIl: if (!is_file($RmZO7)) { goto NFUbK; } goto JIZMZ; vHFys: $A2nx4 = []; goto GgM2x; cswlv: $A2nx4 = $iDxng["\x63\154\141\163\163"]::config(new system\plugin\Form($iDxng["\156\x61\155\x65"])); goto yurbB; yurbB: $A2nx4 = empty($A2nx4->html) ? [] : $A2nx4->html; goto SAy5H; tAJ8d: NFUbK: goto uQ7Z_; TmMFD: })(); goto phllT; Xx52_: $A2nx4 = implode(PHP_EOL, $A2nx4); goto Duf0T; phllT: $title = $iDxng["\x74\x69\x74\154\x65"] . $title; goto m1NmL; VWKuR: $iDxng = Manager::getInfo($_GET["\x6e\141\x6d\145"], true); goto wFmtR; g9Sfo: E_Jx7: goto MiueI; Gjs8j: goto E_Jx7; goto nLnQ1; m1NmL: if (empty($A2nx4)) { goto W_KCv; } goto Xx52_; nLnQ1: W_KCv: goto C2abO; pKIxN: $title = "\346\217\222\344\273\266\350\xae\xbe\xe7\xbd\256"; goto U0BBf; Duf0T: echo Form::form("\160\x6c\x75\x67\x69\156\x53\x65\164", ["\x70\x6c\165\147\151\156" => $_GET["\156\141\x6d\x65"]], $A2nx4); goto Gjs8j; C2abO: echo "\xe6\x8f\222\xe4\273\266\x20" . $iDxng["\x74\151\164\x6c\x65"] . "\40\xe6\232\202\xe6\x97\xa0\xe8\x87\252\345\xae\x9a\344\271\211\350\xae\xbe\xe7\275\xae"; goto g9Sfo; MiueI: include "\x6d\157\144\165\x6c\145\163\x2f\x66\157\157\x74\145\162\56\x70\150\x70";
