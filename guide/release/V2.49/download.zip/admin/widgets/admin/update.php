<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-29 01:22:42
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 use system\admin\Form; use system\admin\View; goto LQSMr; LQSMr: $title = "\346\x9b\xb4\346\226\xb0\350\xb4\246\345\217\267\xe4\277\xa1\346\x81\257"; goto W63Nj; prPWL: $LhJEG = \system\admin\Admin::info(); goto mT5Je; W63Nj: include "\x6d\x6f\x64\x75\154\x65\163\57\150\x65\141\144\145\162\56\160\x68\x70"; goto OITuv; mT5Je: $A2nx4 = [Form::hidden("\x69\x64", $LhJEG["\151\x64"]), Form::input("\xe7\x94\xa8\346\x88\xb7\345\x90\215", "\165\163\x65\162", $LhJEG["\x75\163\145\162"], "\x74\x65\x78\x74", null, ["\x72\x65\x71\165\151\162\x65\144" => true]), Form::input("\xe6\230\xb5\347\247\260", "\156\x61\x6d\145", $LhJEG["\156\x61\x6d\x65"]), Form::input("\351\202\256\xe7\xae\261", "\x65\x6d\141\x69\x6c", $LhJEG["\x65\155\141\x69\154"]), Form::input("\121\x51\xe5\x8f\xb7", "\161\x71", $LhJEG["\161\x71"])]; goto E5ilw; OITuv: $bwtIL = "\x61\144\155\151\x6e"; goto prPWL; E5ilw: View::form($title, "\165\x70\x64\x61\x74\x65\124\x61\142\x6c\x65", ["\x74\x61\x62\x6c\145" => $bwtIL], $A2nx4); goto UPKm7; UPKm7: include "\155\x6f\x64\x75\x6c\x65\163\57\x66\157\x6f\x74\145\x72\x2e\160\150\x70";
