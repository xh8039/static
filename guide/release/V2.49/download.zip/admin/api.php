<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-29 01:22:42
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 use system\library\Json; goto Km3JQ; KcjEu: Json::echo($wLSl2); goto El9FW; ExQnh: $wLSl2 = system\admin\Api::$WyHTR(); goto v5luj; Km3JQ: require_once $_SERVER["\x44\x4f\103\x55\115\105\x4e\x54\x5f\122\x4f\117\x54"] . "\x2f\160\x75\x62\154\x69\143\57\x63\x6f\155\155\x6f\x6e\x2e\160\150\x70"; goto MwchW; MwchW: $WyHTR = isset($_GET["\141\x63\x74\151\157\x6e"]) ? $_GET["\141\143\x74\x69\x6f\156"] : "\151\x6e\144\x65\170"; goto F2oTP; MX0x9: echo $wLSl2; goto p0m8V; v5luj: if (is_string($wLSl2)) { goto TuXFe; } goto KcjEu; El9FW: goto KvGV9; goto vpZ_B; F2oTP: system\admin\Api::init(); goto ExQnh; vpZ_B: TuXFe: goto MX0x9; p0m8V: KvGV9:
