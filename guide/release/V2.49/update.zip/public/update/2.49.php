<?php
delete_directory(THEME_PATH . 'liutongxu' . DIR_SEP . 'assets' . DIR_SEP . 'fonts' . DIR_SEP . 'font_1620678_7g0p3h6gbl-3.03029..css');
