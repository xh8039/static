<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-29 01:22:42
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 goto d0_bu; d0_bu: $title = "\xe6\226\xb0\345\xa2\x9e\xe6\x8f\222\344\xbb\266"; goto DMJhp; KOn2r: echo "\74\160\76\345\x8f\xaa\350\203\xbd\xe6\211\x8b\xe5\212\250\346\xb7\xbb\xe5\x8a\240\346\217\x92\xe4\273\xb6\xe5\223\xa6\x3c\x2f\x70\x3e\xd\xa"; goto uowCq; DMJhp: include "\x6d\157\x64\x75\x6c\145\163\57\x69\x66\x72\x61\x6d\145\x2e\x70\x68\160"; goto KOn2r; uowCq: include "\x6d\157\x64\165\154\x65\163\57\146\x6f\157\x74\x65\162\56\x70\x68\x70";
