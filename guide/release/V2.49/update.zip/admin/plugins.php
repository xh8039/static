<?php
/*
 * @Author        : 易航
 * @Url           : http://guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-29 01:22:42
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址导航系统
 * @Description   : 一款极其优雅的易航网址导航系统
 * @Read me       : 感谢您使用易航网址导航系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 $RhEik = isset($_GET["\x6d\x6f\x64"]) ? $_GET["\x6d\157\x64"] : "\x69\x6e\144\145\170"; require "\x77\151\x64\x67\x65\x74\x73\x2f\160\154\x75\x67\151\156\163\x2f" . $RhEik . "\56\160\150\x70";
