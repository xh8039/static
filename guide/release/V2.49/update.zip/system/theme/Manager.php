<?php

namespace system\theme;

use JsonDb\JsonDb\Db;

class Manager
{

	private static $theme_info = [];

	/**
	 * 获取前台主题列表
	 * @return array
	 */
	static public function getList($annotate = false)
	{
		$dir = THEME_PATH;
		$dirArray = [];
		if (false != ($handle = opendir($dir))) {
			$i = 0;
			while (false !== ($file = readdir($handle))) {
				if ($file != "." && $file != ".." && !strpos($file, ".")) {
					$data = self::getInfo($file, $annotate);
					$dirArray[$file] = $data;
					$i++;
				}
			}
			closedir($handle);
		}
		uksort($dirArray, function ($a, $b) {
			return strcasecmp($a, $b); // strcasecmp 函数比较两个字符串，不区分大小写
		});
		return $dirArray;
	}

	/**
	 * 获取指定主题注解
	 */
	static public function getInfo($theme = THEME, $annotate = true, $theme_config = false)
	{
		if (!empty(self::$theme_info[$theme])) {
			return self::$theme_info[$theme];
		}
		$theme_file = THEME_PATH . $theme . DIR_SEP . 'index.php';
		$options = false;
		if ($theme_config) {
			$functions = THEME_PATH . $theme . DIR_SEP . 'public' . DIR_SEP . 'functions.php';
			if (file_exists($functions)) {
				include_once $functions;
				if (function_exists('theme_config')) {
					$options = true;
				}
			}
		}
		$theme_info = [
			'name' => $theme,
			'options' => $options
		];
		if ($annotate && file_exists($theme_file)) {
			$theme_annotation = get_file_annotate($theme_file);
			if ($theme_annotation) {
				$theme_annotation = parse_annotate($theme_annotation);
				$theme_info = array_merge($theme_annotation, $theme_info);
				$theme_info['title'] = isset($theme_info['title']) ? $theme_info['title'] : (isset($theme_info['package']) ? $theme_info['package'] : null);
				$theme_info['description'] = isset($theme_info['description']) ? $theme_info['description'] : (isset($theme_info[0]) ? $theme_info[0] : null);
				if (empty(self::$theme_info[$theme])) {
					self::$theme_info[$theme] = $theme_info;
				}
			}
		}
		return $theme_info;
	}


	/**
	 * 获取主题文件
	 * @return string 返回当前主题文件名称
	 */
	static public function getFile($path, $theme = THEME, $suffix = '.php')
	{
		$path = str_replace(['\\', '/'], DIR_SEP, $path);
		$filename = THEME_PATH . $theme . DIRECTORY_SEPARATOR . $path . $suffix;
		// halt($filename);
		if (file_exists($filename)) {
			return $filename;
		}
		return false;
	}

	public static function needFile($mod, $theme = THEME)
	{
		$filename = self::getFile($mod, $theme);
		if ($filename) {
			// $dirname = dirname(__FILE__);
			// 切换当前工作路径为引入的文件目录路径
			// chdir(dirname($mod));
			$return = include_once $filename;
			// chdir($dirname); // 恢复路径
			return $return;
		}
		return false;
	}

	/**
	 * 更新主题设置
	 */
	public static function saveSet($data, $theme = THEME)
	{
		$data['theme'] = $theme;
		return Db::name('theme')->save($data, 'theme');
	}

	public static function options($theme = THEME)
	{
		$find = Db::name('theme')->where('theme', $theme)->find();
		if (is_null($find)) {
			if (self::needFile('public/functions', $theme) && function_exists('theme_config')) {
				$form = new \system\theme\Form;
				theme_config($form);
				self::saveSet($form->options, $theme);
				return $form->options;
			}
		}
		return $find ? $find : [];
	}
}
