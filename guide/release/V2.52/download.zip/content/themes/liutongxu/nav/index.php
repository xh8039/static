<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <base href="<?= $this->themeUrl ?>/nav/" />
    <title>新标签页 | <?= $this->site->title ?></title>
    <?= $this->header() ?>
    <meta name="baidu-site-verification" content="code-vIivd4QsAU">
    <link rel='stylesheet' id='iconfont-css' href='static/css/iconfont.css' type='text/css' media='all'>
    <link rel='stylesheet' id='bootstrap-css' href='static/css/bootstrap.min.css' type='text/css' media='all'>
    <link rel='stylesheet' id='style-css' href='static/css/style.min.css' type='text/css' media='all'>
    <script src='static/js/jquery.min.js' id='jquery-js'></script>
</head>

<body class="user-bookmark-body bookmark-default">

    <div class="page-container">
        <div class="bookmark-bg">
            <div class="img-bg" id="img-bg"></div>
            <div class="gradient-linear"></div>
        </div>
        <header class="navbar navbar-dark fixed-top">
            <div class="weather">
                <div id="he-plugin-simple" style="display: contents;"></div>
                <script>
                    WIDGET = {
                        "CONFIG": {
                            "modules": "02",
                            "background": "5",
                            "tmpColor": "FFFFFF",
                            "tmpSize": "20",
                            "cityColor": "FFFFFF",
                            "citySize": "16",
                            "aqiColor": "FFFFFF",
                            "aqiSize": "16",
                            "weatherIconSize": "30",
                            "alertIconSize": "18",
                            "padding": "0px 5px 0px 5px",
                            "shadow": "0",
                            "language": "auto",
                            "fixed": "false",
                            "vertical": "top",
                            "horizontal": "left",
                            "key": "257fe54e3a0b4cd29b399d2831bd56e0"
                        }
                    }
                </script>
                <script src="https://widget.qweather.net/simple/static/js/he-simple-common.js?v=2.0" defer=""></script>
            </div>
            <ul class="nav navbar-menu">
                <li class="nav-login ml-3"> <a href="/" class="text-light" title="主页"><i class="iconfont icon-home bookmark-ico icon-2x" style="font-size: 1.5em; position: relative; left: -10px; top: 0px;"></i></a> </li>
            </ul>
        </header>
        <div class="header-big mb-4">
            <div class="s-search">
                <div id="search" class="s-search mx-auto">
                    <div class="big-title text-center mb-3 mb-md-5 mt-2">
                        <p class="h1" style="letter-spacing: 6px;">所长导航</p>
                    </div>
                    <div id="search-list-menu" class="hide-type-list">
                        <div class="s-type text-center overflow-x-auto">
                            <div class="s-type-list big">
                                <div class="anchor" style="position: absolute; left: 50%; opacity: 0;"></div>
                                <label for="type-baidu1" class="active" data-id="group-b"><span>搜索</span></label>
                                <label for="type-br" data-id="group-c"><span>工具</span></label>
                                <label for="type-zhihu" data-id="group-d"><span>社区</span></label>
                                <label for="type-taobao1" data-id="group-e"><span>生活</span></label>
                                <label for="type-juhe" data-id="group-f"><span>影视</span></label>
                            </div>
                        </div>
                    </div>
                    <form action="/search.html?key=" method="get" target="_blank" class="super-search-fm">
                        <input type="text" id="search-text" class="form-control smart-tips search-key" zhannei="" placeholder="输入关键字搜索" style="outline:0" autocomplete="off">
                        <button type="submit"><i class="iconfont icon-search"></i></button>
                    </form>
                    <div id="search-list" class="hide-type-list">
                        <div class="search-group group-b s-current">
                            <ul class="search-type">
                                <li><input checked="checked" hidden="" type="radio" name="type" id="type-baidu1" value="https://www.baidu.com/s?wd=" data-placeholder="百度一下"><label for="type-baidu1"><span class="text-muted">百度</span></label></li>
                                <li><input hidden="" type="radio" name="type" id="type-google1" value="https://www.google.com/search?q=" data-placeholder="谷歌两下"><label for="type-google1"><span class="text-muted">谷歌</span></label></li>
                                <li><input hidden="" type="radio" name="type" id="type-sogo" value="https://www.sogou.com/web?query=" data-placeholder="搜狗搜索"><label for="type-sogo"><span class="text-muted">搜狗</span></label></li>
                                <li><input hidden="" type="radio" name="type" id="type-bing1" value="https://cn.bing.com/search?q=" data-placeholder="必应搜索"><label for="type-bing1"><span class="text-muted">必应</span></label></li>
                                <li><input hidden="" type="radio" name="type" id="type-kuake" value="https://quark.sm.cn/s?q=" data-placeholder="夸克搜索"><label for="type-kuake"><span class="text-muted">夸克</span></label></li>
                                <li><input hidden="" type="radio" name="type" id="type-toutiao" value="https://so.toutiao.com/search/?keyword=" data-placeholder="头条搜索"><label for="type-toutiao"><span class="text-muted">头条</span></label></li>
                            </ul>
                        </div>
                        <div class="search-group group-c ">
                            <ul class="search-type">
                                <li><input hidden="" type="radio" name="type" id="type-br" value="https://rank.chinaz.com/all/" data-placeholder="请输入网址(不带https://)"><label for="type-br"><span class="text-muted">权重查询</span></label></li>
                                <li><input hidden="" type="radio" name="type" id="type-links" value="https://link.chinaz.com/" data-placeholder="请输入网址(不带https://)"><label for="type-links"><span class="text-muted">友链检测</span></label></li>
                                <li><input hidden="" type="radio" name="type" id="type-icp" value="https://icp.aizhan.com/" data-placeholder="请输入网址(不带https://)"><label for="type-icp"><span class="text-muted">备案查询</span></label></li>
                                <li><input hidden="" type="radio" name="type" id="type-ping" value="https://ping.chinaz.com/" data-placeholder="请输入网址(不带https://)"><label for="type-ping"><span class="text-muted">PING检测</span></label></li>
                                <li><input hidden="" type="radio" name="type" id="type-404" value="https://tool.chinaz.com/Links/?DAddress=" data-placeholder="请输入网址(不带https://)"><label for="type-404"><span class="text-muted">死链检测</span></label></li>
                                <li><input hidden="" type="radio" name="type" id="type-ciku" value="https://www.ciku5.com/s?wd=" data-placeholder="请输入关键词"><label for="type-ciku"><span class="text-muted">关键词挖掘</span></label></li>
                            </ul>
                        </div>
                        <div class="search-group group-d ">
                            <ul class="search-type">
                                <li><input hidden="" type="radio" name="type" id="type-zhihu" value="https://www.zhihu.com/search?type=content&q=" data-placeholder="知乎"><label for="type-zhihu"><span class="text-muted">知乎</span></label></li>
                                <li><input hidden="" type="radio" name="type" id="type-wechat" value="https://weixin.sogou.com/weixin?type=2&query=" data-placeholder="微信"><label for="type-wechat"><span class="text-muted">微信</span></label></li>
                                <li><input hidden="" type="radio" name="type" id="type-weibo" value="https://s.weibo.com/weibo/" data-placeholder="微博"><label for="type-weibo"><span class="text-muted">微博</span></label></li>
                                <li><input hidden="" type="radio" name="type" id="type-douban" value="https://www.douban.com/search?q=" data-placeholder="豆瓣"><label for="type-douban"><span class="text-muted">豆瓣</span></label></li>
                                <li><input hidden="" type="radio" name="type" id="type-why" value="https://ask.seowhy.com/search/?q=" data-placeholder="SEO问答社区"><label for="type-why"><span class="text-muted">搜外问答</span></label></li>
                            </ul>
                        </div>
                        <div class="search-group group-e ">
                            <ul class="search-type">
                                <li><input hidden="" type="radio" name="type" id="type-taobao1" value="https://s.taobao.com/search?q=" data-placeholder="淘宝"><label for="type-taobao1"><span class="text-muted">淘宝</span></label></li>
                                <li><input hidden="" type="radio" name="type" id="type-jd" value="https://search.jd.com/Search?keyword=" data-placeholder="京东"><label for="type-jd"><span class="text-muted">京东</span></label></li>
                                <li><input hidden="" type="radio" name="type" id="type-12306" value="https://www.12306.cn/?" data-placeholder="12306"><label for="type-12306"><span class="text-muted">12306</span></label></li>
                                <li><input hidden="" type="radio" name="type" id="type-kd100" value="https://www.kuaidi100.com/?" data-placeholder="快递100"><label for="type-kd100"><span class="text-muted">快递100</span></label></li>
                                <li><input hidden="" type="radio" name="type" id="type-qunar" value="https://www.qunar.com/?" data-placeholder="去哪儿"><label for="type-qunar"><span class="text-muted">去哪儿</span></label></li>
                            </ul>
                        </div>
                        <div class="search-group group-f ">
                            <ul class="search-type">
                                <li><input hidden="" type="radio" name="type" id="type-juhe" value="https://soupian.one/search?key=" data-placeholder="影视资源聚合搜索"><label for="type-juhe"><span class="text-muted">聚合搜索</span></label></li>
                                <li><input hidden="" type="radio" name="type" id="type-555" value="https://www.o8tv.com/vodsearch/-------------.html?wd=" data-placeholder="在线影视搜索"><label for="type-555"><span class="text-muted">555电影</span></label></li>
                                <li><input hidden="" type="radio" name="type" id="type-dyxs" value="http://dyxs15.com/search--------------/?wd=" data-placeholder="在线影视搜索"><label for="type-dyxs"><span class="text-muted">电影先生</span></label></li>
                                <li><input hidden="" type="radio" name="type" id="type-dibi" value="https://www.mp4er.cc/search/" data-placeholder="在线及下载影视搜索"><label for="type-dibi"><span class="text-muted">哔嘀影视</span></label></li>
                            </ul>
                        </div>
                    </div>
                    <div class="card search-smart-tips" style="display: none">
                        <ul></ul>
                    </div>
                </div>
            </div>
        </div>

        <section class="quick-sites position-relative">
            <div class="container text-center px-5">
                <div class="row"> <a class="sites-btn col-3 col-md-2 text-center mb-4" target="_blank" href="https://github.com/" title="Github" rel=" noopener">
                        <div class="d-flex mb-2">
                            <div class="sites-icon mx-auto ub-blur-bg"> <img class="lazy" src="../assets/images/ico/github.png" data-src="../assets/images/ico/github.png" onerror="javascript:this.src='../assets/images/ico/github.png'" alt="Github"> </div>
                        </div>
                        <div class="sites-title ub-blur-bg px-2 text-xs overflowClip_1"><span>Github</span>
                        </div>
                    </a> <a class="sites-btn col-3 col-md-2 text-center mb-4" target="_blank" href="https://gitee.com/" title="Gitee" rel="external nofollow noopener">
                        <div class="d-flex mb-2">
                            <div class="sites-icon mx-auto ub-blur-bg"> <img class="lazy" src="../assets/images/ico/gitee.png" data-src="../assets/images/ico/gitee.png" onerror="javascript:this.src='../assets/images/ico/gitee.png'" alt="Gitee">
                            </div>
                        </div>
                        <div class="sites-title ub-blur-bg px-2 text-xs overflowClip_1"><span>Gitee</span></div>
                    </a> <a class="sites-btn col-3 col-md-2 text-center mb-4" target="_blank" href="http://www.52pojie.cn/" title="吾爱破解" rel="external nofollow noopener">
                        <div class="d-flex mb-2">
                            <div class="sites-icon mx-auto ub-blur-bg"> <img class="lazy" src="../assets/images/ico/52.png" data-src="../assets/images/ico/52.png" onerror="javascript:this.src='../assets/images/ico/52.png'" alt="吾爱破解"> </div>
                        </div>
                        <div class="sites-title ub-blur-bg px-2 text-xs overflowClip_1"><span>吾爱破解</span>
                        </div>
                    </a> <a class="sites-btn col-3 col-md-2 text-center mb-4" target="_blank" href="https://www.mpyit.com/" title="殁漂遥" rel="external nofollow noopener">
                        <div class="d-flex mb-2">
                            <div class="sites-icon mx-auto ub-blur-bg"> <img class="lazy" src="../assets/images/ico/mpy.png" data-src="../assets/images/ico/mpy.png" onerror="javascript:this.src='../assets/images/ico/mpy.png'" alt="殁漂遥"> </div>
                        </div>
                        <div class="sites-title ub-blur-bg px-2 text-xs overflowClip_1"><span>殁漂遥</span></div>
                    </a> <a class="sites-btn col-3 col-md-2 text-center mb-4" target="_blank" href="https://ibaotu.com/" title="包图网" rel="external nofollow noopener">
                        <div class="d-flex mb-2">
                            <div class="sites-icon mx-auto ub-blur-bg"> <img class="lazy" src="../assets/images/ico/baotu.png" data-src="../assets/images/ico/baotu.png" onerror="javascript:this.src='../assets/images/ico/baotu.png'" alt="包图网">
                            </div>
                        </div>
                        <div class="sites-title ub-blur-bg px-2 text-xs overflowClip_1"><span>包图网</span></div>
                    </a> <a class="sites-btn col-3 col-md-2 text-center mb-4" target="_blank" href="https://www.58pic.com/" title="千图网" rel="external nofollow noopener">
                        <div class="d-flex mb-2">
                            <div class="sites-icon mx-auto ub-blur-bg"> <img class="lazy" src="../assets/images/ico/qiantu.png" data-src="../assets/images/ico/qiantu.png" onerror="javascript:this.src='../assets/images/ico/qiantu.png'" alt="千图网">
                            </div>
                        </div>
                        <div class="sites-title ub-blur-bg px-2 text-xs overflowClip_1"><span>千图网</span></div>
                    </a> <a class="sites-btn col-3 col-md-2 text-center mb-4" target="_blank" href="https://mail.qq.com/" title="QQ邮箱" rel="external nofollow noopener">
                        <div class="d-flex mb-2">
                            <div class="sites-icon mx-auto ub-blur-bg"> <img class="lazy" src="../assets/images/ico/QQyx.png" data-src="../assets/images/ico/QQyx.png" onerror="javascript:this.src='../assets/images/ico/QQyx.png'" alt="QQ邮箱">
                            </div>
                        </div>
                        <div class="sites-title ub-blur-bg px-2 text-xs overflowClip_1"><span>QQ邮箱</span></div>
                    </a> <a class="sites-btn col-3 col-md-2 text-center mb-4" target="_blank" href="https://bbs.125.la/" title="精易论坛" rel="external nofollow noopener">
                        <div class="d-flex mb-2">
                            <div class="sites-icon mx-auto ub-blur-bg"> <img class="lazy" src="../assets/images/ico/jingyi.png" data-src="../assets/images/ico/jingyi.png" onerror="javascript:this.src='../assets/images/ico/jingyi.png'" alt="精易论坛">
                            </div>
                        </div>
                        <div class="sites-title ub-blur-bg px-2 text-xs overflowClip_1"><span>精易论坛</span></div>
                    </a> <a class="sites-btn col-3 col-md-2 text-center mb-4" target="_blank" href="https://www.bilibili.com/" title="哔哩哔哩" rel="external nofollow noopener">
                        <div class="d-flex mb-2">
                            <div class="sites-icon mx-auto ub-blur-bg"> <img class="lazy" src="../assets/images/ico/bilibili.png" data-src="../assets/images/ico/bilibili.png" onerror="javascript:this.src='../assets/images/ico/bilibili.png'" alt="哔哩哔哩"> </div>
                        </div>
                        <div class="sites-title ub-blur-bg px-2 text-xs overflowClip_1"><span>哔哩哔哩</span></div>

                    </a> <a class="sites-btn col-3 col-md-2 text-center mb-4" target="_blank" href="https://www.o8tv.com/" title="555电影" rel="external nofollow noopener">
                        <div class="d-flex mb-2">
                            <div class="sites-icon mx-auto ub-blur-bg"> <img class="lazy" src="../assets/images/ico/555dianying.png" data-src="../assets/images/ico/555dianying.png" onerror="javascript:this.src='../assets/images/ico/555dianying.png'" alt="555电影"> </div>
                        </div>
                        <div class="sites-title ub-blur-bg px-2 text-xs overflowClip_1"><span>555电影</span></div>
                    </a> <a class="sites-btn col-3 col-md-2 text-center mb-4" target="_blank" href="https://www.bd2020.com/" title="BD影视" rel="external nofollow noopener">
                        <div class="d-flex mb-2">
                            <div class="sites-icon mx-auto ub-blur-bg"> <img class="lazy" src="../assets/images/ico/BDyingshi.png" data-src="../assets/images/ico/BDyingshi.png" onerror="javascript:this.src='../assets/images/ico/BDyingshi.png'" alt="BD影视"> </div>
                        </div>
                        <div class="sites-title ub-blur-bg px-2 text-xs overflowClip_1"><span>BD影视</span></div>
                    </a> <a class="sites-btn col-3 col-md-2 text-center mb-4" target="_blank" href="https://www.ghxi.com/" title="果核剥壳" rel="external nofollow noopener">
                        <div class="d-flex mb-2">
                            <div class="sites-icon mx-auto ub-blur-bg"> <img class="lazy" src="../assets/images/ico/guohe.png" data-src="../assets/images/ico/guohe.png" onerror="javascript:this.src='../assets/images/ico/guohe.png'" alt="果核剥壳">
                            </div>
                        </div>
                        <div class="sites-title ub-blur-bg px-2 text-xs overflowClip_1"><span>果核剥壳</span></div>
                    </a> </div>
            </div>
        </section>
        <footer class="main-footer footer-type-1 position-relative text-xs">
            <div id="footer-tools" class="d-flex flex-column">
                <div id="footer-tools" class="d-flex flex-column"> <a href="javascript:" id="go-to-up" class="btn rounded-circle go-up m-1" rel="go-top" style="display: none;" one-link-mark="yes"> <i class="iconfont icon-to-up"></i> </a> </div>
            </div>
            <div class="footer-inner text-center text-light my-3" style="color: #f8f9fa45!important;">
                <div class="footer-text">
                    Copyright © <?= date('Y') ?> <?= $this->site->title ?> Design by LiuTongxu
                </div>
            </div>
        </footer>
    </div>
    <script src="static/js/bing.js"></script>
    <script src="static/js/popper.min.js"></script>
    <script src='static/js/bootstrap.min.js' id='bootstrap-js'></script>
    <script src="static/js/theia-sticky-sidebar.js"></script>
    <script src='static/js/lazyload.min.js' id='lazyload-js'></script>
    <script src='static/js/app.min.js' id='appjs-js'></script>

</body>

</html>