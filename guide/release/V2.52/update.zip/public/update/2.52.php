<?php

use JsonDb\JsonDb\Db;

$site_list = Db::name('site')->select();

foreach ($site_list as $key => $value) {
    if ($value['order'] > 0) continue;
    $order = strtotime($value['create_time']);
    JsonDb\JsonDb\Db::name('site')->where('id', $value['id'])->update(['order' => $order]);
}
