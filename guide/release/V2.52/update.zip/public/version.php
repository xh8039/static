<?php
define('VERSION', 2.52);