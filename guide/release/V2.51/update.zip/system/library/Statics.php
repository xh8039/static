<?php

namespace system\library;

class Statics
{
	public static function load($file, $attr = [])
	{
		$file_url = explode('?', $file, 2)[0];
		$extension = pathinfo($file_url)['extension'];
		$html = null;
		$attr['referrer'] = 'no-referrer';
		if ($extension == 'css') {
			$link = element('link');
			$attr['rel'] = isset($attr['rel']) ? $attr['rel'] : 'stylesheet';
			$attr['href'] = $file_url;
			$link->attr($attr);
			$html = $link->get(false);
		}
		if ($extension == 'js') {
			$script = element('script');
			$attr['src'] = $file_url;
			$script->attr($attr);
			$html = $script->get();
		}
		// print_r($html);exit;
		return $html . PHP_EOL;
	}

	public static function version($url, $version = VERSION)
	{
		if ($version && (strstr($url, 'version=') !== false)) {
			return $url .= '?version=' . $version;
		}
		return $url;
	}

	public static function backgroundImage()
	{
		$image = function ($devices) {
			$background_path = ROOT . 'content/static/images/background/' . $devices . '/';
			$background_list = scan_dir($background_path)->files();
			$url = '/content/static/images/background/' . $devices . '/';
			$background = $url .  $background_list[array_rand($background_list)];
			return $background;
		};
		return is_pc() ? $image('pc') : $image('mobile');
	}

	public static function LightYear(int $v, $path, $version = VERSION)
	{
		$url = '/content/static/frame/light-year/v' . $v . '/' . $path;
		return self::version($url, $version);
	}

	public static function plugin($path, $version = VERSION)
	{
		$url = '/content/static/plugins/' . $path;
		return self::version($url, $version);
	}

	public static function image($url, $attr = [])
	{
		$attr['referrer'] = 'no-referrer';
		$attr['src'] = $url;
		return element('img')->attr($attr);
	}

	public static function alert($content, $location = false)
	{
		$script = element('script');
		$content = 'alert("' . $content . '")' . ($location ? ';window.location.href="' . $location . '"' : null);
		echo $script->get($content);
	}
}
