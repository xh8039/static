<div class="tishi">
	<p>将本站收藏至浏览器书签，永不迷路</p>
	<button id="gb-ts">×</button>
</div>
<!--<div class="footer">-->
<!--    <p class="text-white text-center">友情链接</p>-->
<!--</div>-->
<script src="<?= $this->themeUrl('assets/js/public.js') ?>" type="text/javascript"></script>
<?= $this->footer() ?>