<?php
/*
 * @Author        : 易航
 * @Url           : guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-18 20:09:30
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址引导系统
 * @Description   : 一款极其优雅的易航网址引导系统
 * @Read me       : 感谢您使用易航网址引导系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 goto wwDQk; wwDQk: session_start(); goto BDmGh; wDJvL: $xS1U9 = new system\library\Captcha(); goto n1i1K; n1i1K: $xS1U9->doimg(); goto MPyPT; BDmGh: require $_SERVER["\104\117\x43\125\x4d\x45\x4e\124\x5f\122\117\x4f\x54"] . "\57\163\x79\x73\x74\145\155\x2f\x6c\x69\142\162\141\x72\171\x2f\103\141\160\x74\143\150\141\x2e\x70\x68\160"; goto wDJvL; MPyPT: $_SESSION["\x61\144\x6d\x69\x6e\137\x63\141\160\164\x63\150\x61"] = $xS1U9->getCode();
