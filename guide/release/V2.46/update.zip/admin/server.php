<?php
/*
 * @Author        : 易航
 * @Url           : guide.bri6.cn
 * @Date          : 2023-09-29 13:18:36
 * @LastEditTime  : 2024-07-18 20:09:30
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址引导系统
 * @Description   : 一款极其优雅的易航网址引导系统
 * @Read me       : 感谢您使用易航网址引导系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/
 use system\library\Json; goto ACJcp; EFkoQ: if (!(is_array($B6a9n) || is_object($B6a9n))) { goto mBql6; } goto Fe564; jwLNV: if (!empty($B6a9n)) { goto XcK5Y; } goto MI2pb; MI2pb: http_response_code(404); goto e3xY7; yjvhv: $B6a9n = system\admin\Server::$oLGPd(); goto EFkoQ; RUEzA: $oLGPd = trim($_GET["\x61\143\164\x69\157\x6e"] ?? "\x69\156\144\x65\x78"); goto yjvhv; gATHN: mBql6: goto jwLNV; ACJcp: require $_SERVER["\104\117\x43\x55\x4d\105\116\124\137\122\117\117\124"] . "\57\160\165\142\x6c\x69\143\57\143\157\x6d\155\x6f\156\x2e\x70\x68\x70"; goto RUEzA; UAFFn: echo $B6a9n; goto QZ25X; Fe564: $B6a9n = Json::encode($B6a9n); goto gATHN; mq1PW: XcK5Y: goto UAFFn; e3xY7: goto C46qB; goto mq1PW; QZ25X: C46qB:
