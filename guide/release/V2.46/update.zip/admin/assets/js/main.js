$(document).ready(function () {
	$('header .clear-cache').click(function () {
		$.get('server.php?action=clearAll');
		$.notify({
			message: '清空缓存成功'
		}, {
			type: 'success',
			allow_dismiss: true,
			newest_on_top: false,
			placement: {
				from: 'top',
				align: 'center'
			},
			delay: 10,
			animate: {
				enter: 'animate__animated animate__fadeInDown',
				exit: 'animate__animated animate__fadeOutUp'
			}
		});
	});

	$('.layer_iframe').click(function (event) {
		event.preventDefault();
		let url = $(this).attr('data-url') ? $(this).attr('data-url') : $(this).attr('href');
		let title = $(this).attr('data-title') ? $(this).attr('data-title') : $(this).text();
		// console.log(url);
		YiHang.iframe(url, title);
		return false;
	});
});