<?php

use system\admin\View;
use system\theme\Manager;

$title = '主题设置';
include 'modules/header.php';
$theme = Manager::getInfo();
View::card($theme['title'] . $title, function () {
	if (Manager::needFile('theme/functions') && function_exists('themeConfig')) {
		define('THEME_SET', true);
?>
		<form action="api.php?action=themeSet" method="post" class="themeSet">
			<?php themeConfig(new \system\theme\Form) ?>
			<div class="d-grid">
				<button type="submit" class="btn btn-primary">保存主题设置</button>
			</div>
		</form>
<?php
	} else {
		echo '本主题暂无自定义设置';
	}
});
include 'modules/footer.php';
echo system\admin\Form::script('themeSet', '保存主题设置');