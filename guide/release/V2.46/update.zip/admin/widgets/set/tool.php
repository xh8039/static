<?php

/*
 * @Author        : 易航
 * @Url           : guide.bri6.cn
 * @Date          : 2020-09-29 13:18:36
 * @LastEditTime  : 2022-10-26 21:46:06
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址引导系统
 * @Description   : 一款极其优雅的易航网址引导系统
 * @Read me       : 感谢您使用易航网址引导系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
 */

use system\library\System;

if (isset($_GET['tool'])) {
	require $_SERVER['DOCUMENT_ROOT'] . '/public/common.php';
	if ($_GET['tool'] == 'restore') {
		// 调用函数将文件夹复制到另一个目录
		copyFolder('./JsonDb', CONTENT_ROOT . 'JsonDb');
		System::alert('恢复出厂设置成功！', '?mod=tool');
		// System::alert('恢复出厂设置失败，无法复制数据文件！', '?mod=tool');
	}
	if ($_GET['tool'] == 'clear') {
		\system\admin\Server::clearAll();
		System::alert('服务端缓存已成功清除！', '?mod=tool');
	}
	if ($_GET['tool'] == 'import') {
		System::alert('功能正在拼命开发中...', '?mod=tool');
	}
}

$title = '自助工具';
include 'modules/header.php';
\system\admin\View::card($title, function () {
	?>
	<a href="?mod=tool&tool=import" class="btn btn-primary"><i class="mdi mdi-import"></i> 导入浏览器书签</a>
	<a href="?mod=tool&tool=restore" class="btn btn-danger"><i class="mdi mdi-wrench"></i> 恢复出厂设置</a>
	<a href="?mod=tool&tool=clear" class="btn btn-warning"><i class="mdi mdi-delete-empty"></i> 清空服务端缓存</a>
	<?php
});
include 'modules/footer.php';


function copyFolder($src, $dest)
{
	// 如果目标目录不存在，则创建目标目录
	if (!is_dir($dest)) {
		mkdir($dest);
	}

	// 获取原始目录中的文件和目录
	$files = scandir($src);

	// 遍历文件和目录
	foreach ($files as $file) {
		if ($file !== '.' && $file !== '..') {
			// 如果该文件是一个目录，则递归调用该函数复制子目录
			if (is_dir($src . DIRECTORY_SEPARATOR . $file)) {
				copyFolder($src . DIRECTORY_SEPARATOR . $file, $dest . DIRECTORY_SEPARATOR . $file);
			} else {
				// 如果该文件是一个文件，则复制文件到目标目录中
				copy($src . DIRECTORY_SEPARATOR . $file, $dest . DIRECTORY_SEPARATOR . $file);
			}
		}
	}
}



?>