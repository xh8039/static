<?php

/*
 * @Author        : 易航
 * @Url           : guide.bri6.cn
 * @Date          : 2020-09-29 13:18:36
 * @LastEditTime  : 2022-10-26 21:46:06
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址引导系统
 * @Description   : 一款极其优雅的易航网址引导系统
 * @Read me       : 感谢您使用易航网址引导系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/

use system\admin\Form;
use system\admin\View;

$title = '系统设置';
include 'modules/header.php';
View::card($title, function () {
	$options = options();
	$site = options('site');
?>
	<ul class="nav nav-tabs">
		<li class="nav-item">
			<button class="nav-link active" id="basic-site" data-bs-toggle="tab" data-bs-target="#site" type="button">网站</button>
		</li>
		<li class="nav-item">
			<button class="nav-link" id="basic-system" data-bs-toggle="tab" data-bs-target="#system" type="button">系统</button>
		</li>
		<li class="nav-item">
			<button class="nav-link" id="basic-admin" data-bs-toggle="tab" data-bs-target="#admin" type="button">后台</button>
		</li>
		<li class="nav-item">
			<button class="nav-link" data-bs-toggle="tab" data-bs-target="#pane-theme" type="button">主题</button>
		</li>
		<li class="nav-item">
			<button class="nav-link" id="basic-email" data-bs-toggle="tab" data-bs-target="#email" type="button">邮箱与提醒</button>
		</li>
	</ul>
	<form action="api.php?action=set" method="post" class="set">
		<div class="tab-content">
			<div class="tab-pane fade show active" id="site">
				<?php
				echo Form::input('网站标题', 'site[title]', $site['title']);
				echo Form::input('网站关键词', 'site[keywords]', $site['keywords']);
				echo Form::input('网站描述', 'site[description]', $site['description']);
				echo Form::input('站长QQ号', 'site[qq]', $site['qq'], 'number');
				echo Form::input('网站Favicon', 'site[favicon]', $site['favicon'], 'text', '介绍：用于设置网站Favicon，一个好的Favicon可以给用户一种很专业的观感<br>格式：图片URL地址或Base64代码<br>转换方法：将png图片后缀改为ico即可');
				echo Form::input('网站LOGO', 'site[logo]', $site['logo'], 'text', '介绍：用于设置网站Logo，一个好的Logo能为网站带来有效的流量
					<br>格式：图片URL地址或 Base64代码
					<br>其他：免费制作Logo网站 <a target="_blank" href="//www.uugai.com" rel="noopener noreferrer">www.uugai.com</a>');
				echo Form::input('ICP备案号', 'site[icp]', $site['icp']);
				echo Form::input('版权信息', 'site[copyright]', htmlentities($site['copyright']));
				echo Form::input('网站创建日期', 'site[create_date]', $site['create_date'], 'text', null, ['data-provide' => 'datepicker', 'data-date-highlight' => 'true']);
				?>
			</div>
			<div class="tab-pane fade" id="system">
				<?php
				echo Form::select('网站伪静态', 'rewrite', [
					'1' => '开启',
					'0' => '关闭'
				], $options['rewrite'], '推荐开启，开启后前台URL展示更加有助于搜索引擎收录，开启前需要设置站点伪静态为ThinkPHP')
				?>
			</div>
			<div class="tab-pane fade" id="admin">
				<?php
				echo Form::input('登录页面背景', 'admin[background]', $options['admin']['background'], 'url', '不填写则随机使用系统自带壁纸，请使用图片AIP或者直链');
				echo Form::select('Loading动画', 'admin[loading]', [
					'1' => '开启',
					'0' => '关闭'
				], $options['admin']['loading'], '是否开启后台Loading动画 开启后可有效防止使用谷歌内核的浏览器出现页面闪动问题');
				?>
			</div>
			<div class="tab-pane fade" id="pane-theme">
				<?php
				if (!is_array($options['theme'])) $options['theme'] = [];
				echo Form::input('背景图链接', 'theme[background]', $options['theme']['background'], 'url', '不填写则随机使用系统自带壁纸，请使用图片AIP或者直链，需要看目前所使用的主题是否支持');
				echo Form::select('底部系统版权信息', 'theme[copyright]', [
					'1' => '开启',
					'0' => '关闭'
				], $options['theme']['copyright']);
				?>
			</div>
			<div class="tab-pane fade" id="email">
				<?php
				echo Form::input('SMTP服务器', 'mail[smtp]', $options['mail']['smtp'], 'text', '例如：smtp.qq.com', ['required' => true]);
				echo Form::select('加密方式', 'mail[secure]', [
					'ssl' => 'SSL（默认）',
					'tsl' => 'TSL'
				], $options['mail']['secure'], '介绍：用于选择登录鉴权加密方式');
				echo Form::input('SMTP端口', 'mail[port]', $options['mail']['port'], 'number', '例如：465', ['required' => true]);
				echo Form::input('发信邮箱', 'mail[name]', $options['mail']['name'], 'email', '例如：123456@qq.com', ['required' => true]);
				echo Form::input('邮箱密码', 'mail[pwd]', $options['mail']['pwd'], 'text', '部分平台密码无效，需要邮箱授权码', ['required' => true]);
				echo Form::input('收信邮箱', 'mail[recv]', $options['mail']['recv'], 'email', '不填默认为发信邮箱');
				?>
				<svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
					<symbol id="check-circle-fill" fill="currentColor" viewBox="0 0 16 16">
						<path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z" />
					</symbol>
					<symbol id="info-fill" fill="currentColor" viewBox="0 0 16 16">
						<path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16zm.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2z" />
					</symbol>
					<symbol id="exclamation-triangle-fill" fill="currentColor" viewBox="0 0 16 16">
						<path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767L8.982 1.566zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5zm.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2z" />
					</symbol>
				</svg>
				<div class="alert alert-primary d-flex align-items-center" role="alert">
					<svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Info:">
						<use xlink:href="#info-fill" />
					</svg>
					<div>
						此功能为用户与站点交互时给自己发邮件提醒以及发送给用户的邮件。建议使用QQ邮箱，SMTP服务器，端口465或587，密码不是QQ密码也不是邮箱独立密码，是QQ邮箱设置界面生成的<a href="https://service.mail.qq.com/cgi-bin/help?subtype=1&&no=1001256&&id=28" class="alert-link">授权码</a>
					</div>
				</div>
			</div>
			<div class="d-grid">
				<button type="submit" class="btn btn-primary">保存配置</button>
			</div>
		</div>
	</form>
<?php
});
include_once 'modules/footer.php';
?>
<script type="text/javascript">
	YiHang.form('.set', '保存配置')
</script>