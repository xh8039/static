<?php

namespace content\plugins\FloatSnow;

/**
 * @package 凛冬已至
 * @description 站点前端雪花飘落特效
 * @author 易航
 * @version 1.0
 * @link http://bri6.cn
 */
class Plugin
{
	public static function footer()
	{
		echo '<script src="https://cdn.jsdelivr.net/gh/xh8039/static/public/js/snow-falling.min.js"></script>';
	}
}