<?php

namespace content\plugins\InsertCode;

/**
 * 前台页面头部和底部插入自定义代码，可放入统计平台的代码等
 *
 * @package 插入代码
 * @author 易航
 * @version 1.0
 * @link http://bri6.cn
 */
class Plugin
{

    public static $options;

    public static function config(\system\plugin\Form $form)
    {
        $header = $form->textarea('头部代码', 'header');
        $form->create($header);

        $footer = $form->textarea('底部代码', 'footer');
        $form->create($footer);

        return $form;
    }

    public static function header()
    {
        echo isset(self::$options->header) ? self::$options->header : null;
    }

    public static function footer()
    {
        echo isset(self::$options->footer) ? self::$options->footer : null;
    }

}