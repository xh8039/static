<?php

namespace content\plugins\ReportPrevent;

/**
 * @package QQ防举报
 * @description QQ内打开本站后举报将自动跳转百度
 * @author 易航
 * @version 1.0
 * @link http://bri6.cn
 */
class Plugin
{

	public static $options;

	public static function footer()
	{
		$script = <<<HTML
		<script>
			document.getElementsByTagName = function(a) {
				if (a == 'meta') {
					window.location.href = 'http://www.baidu.com';
				}
			}
		</script>
		HTML;
		if (strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/') !== false) {
			echo PHP_EOL . $script;
		}
	}
}