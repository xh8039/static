<?php

namespace content\plugins\MusicPlayer;


/**
 * 支持播放各大平台音乐
 *
 * @package 音乐播放器
 * @author 易航
 * @version 1.0
 * @link http://bri6.cn
 */
class Plugin
{

	public static $options;

	public static function config(\system\plugin\Form $form)
	{
		$server = $form->select('音乐平台', 'server', [
			'netease' => '网易云音乐（默认）',
			'tencent' => 'QQ音乐',
			'kugou' => '酷狗音乐',
			'xiami' => '虾米音乐',
			'baidu' => '百度音乐'
		], 'netease');
		$form->create($server);

		$type = $form->select('音乐类型', 'type', [
			'playlist' => '歌单（默认）',
			'song' => '单曲',
			'album' => '专辑',
			'search' => '搜索结果',
			'artist' => '艺术家'
		], 'playlist');
		$form->create($type);

		$id = $form->input('ID', 'id', '7757541927', 'text', '类型指向的ID，一般可以在网页版地址栏中找到', ['required' => true]);
		$form->create($id);

		$volume = $form->input('默认音量', 'volume', '0.3', 'text', '单位为1-0，例如：0.3', ['required' => true]);
		$form->create($volume);

		$autoplay = $form->select('自动播放', 'autoplay', [
			'1' => '开启（默认）',
			'0' => '关闭'
		], '1', '音乐数据加载完毕后自动播放，部分浏览器已禁用自动播放声音策略');
		$form->create($autoplay);

		$order = $form->select('播放顺序', 'order', [
			'random' => '随机播放（默认）',
			'list' => '默认排序'
		], 'random');
		$form->create($order);

		return $form;
	}

	public static function footer()
	{
		$meting = element('meting-js');
		$meting->attr([
			'fixed' => 'true',
			'preload' => 'metadata',
			'mutex' => 'true',
			'volume' => self::$options->volume,
			'autotheme' => 'true',
			'storage' => 'true',
			'order' => self::$options->order,
			'server' => self::$options->server,
			'type' => self::$options->type,
			'id' => self::$options->id
		]);
		self::$options->autoplay ? $meting->attr('autoplay', 'autoplay') : null;
		echo $meting->get();
?>
		<style>
			.aplayer>.aplayer-body>.aplayer-info>.aplayer-music>.aplayer-title,
			.aplayer>.aplayer-list>ol>li>.aplayer-list-title {
				color: #000;
			}
			.aplayer.aplayer-fixed {
				z-index: 9999 !important;
			}
		</style>
		<link href="//cdn.bootcdn.net/ajax/libs/aplayer/1.10.1/APlayer.min.css" rel="stylesheet">
		<script src="//cdn.bootcdn.net/ajax/libs/color-thief/2.3.2/color-thief.min.js"></script>
		<script src="//cdn.bootcdn.net/ajax/libs/aplayer/1.10.1/APlayer.min.js"></script>
		<script src="https://cdn.jsdelivr.net/gh/xh8039/static/public/js/MusicPlayer.js"></script>
		<script src="https://cdn.jsdelivr.net/gh/xh8039/static/public/js/Meting.js"></script>
<?php
	}
}
