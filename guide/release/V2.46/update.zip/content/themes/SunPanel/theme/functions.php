<?php
if (!defined('ROOT')) exit;

function themeConfig(\system\theme\Form $form)
{
	$Notice = $form->textarea('顶部公告', 'notice', '欢迎使用易航网址导航系统', '为空则不展示公告');
	$form->create($Notice);
}

function linkConfig(\system\theme\Fields $form)
{
	$form->text('链接简介', 'description', null, '为空则不显示');
	$form->text('链接背景颜色', 'background_color', 'rgba(42, 42, 42, 0.42)', '黑色半透明：rgba(42, 42, 42, 0.42)<br>透明背景：rgba(0, 0, 0, 0)<br>');
	$form->text('链接文字颜色', 'text_color', 'white', '例如：white | #FFFFFF | rgba(255, 255, 255, 1)');
	$form->text('链接图标大小', 'icon_px', '35px', '例如：35px');
	$form->text('链接图片图标', 'img', null, '请输入图片直链或base64文本图片，如果使用SVG直链，推荐图标大小填写50px');
	$form->text('链接SVG图标', 'svg', null, htmlentities('SVG代码，<svg>开始</svg>结束，小白不推荐使用'));
	$form->text('链接文本图标', 'text_icon', null);
}
