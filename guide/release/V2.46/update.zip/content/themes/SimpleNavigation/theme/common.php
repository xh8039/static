<?php
function embody()
{
}