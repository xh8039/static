<?php
$link_file = CONTENT_ROOT . 'JsonDb' . DIRECTORY_SEPARATOR . 'link.json';
$content = file_get_contents($link_file);
$content = str_replace('"cid"', '"sort_id"', $content);
file_put_contents($link_file, $content);