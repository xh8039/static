<?php
define('VERSION', 2.46);