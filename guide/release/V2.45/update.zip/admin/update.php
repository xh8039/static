<?php

/*
 * @Author        : 易航
 * @Url           : blog.bri6.cn
 * @Date          : 2020-09-29 13:18:36
 * @LastEditTime  : 2022-10-26 21:46:06
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址引导系统
 * @Description   : 一款极其优雅的易航网址引导系统
 * @Read me       : 感谢您使用易航网址引导系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/

use system\admin\Server;

$title = '检查版本更新';
include_once $_SERVER['DOCUMENT_ROOT'] . '/public/common.php';
Server::clear('update');
include 'modules/header.php';
$res = Server::update();
$act = isset($_GET['act']) ? $_GET['act'] : null;
if ($act == 'do' && $res['update'] && $res['file']) {
	$RemoteFile = $res['file'];
	$ZipFile = "Archive.zip";
	if (copy($RemoteFile, $ZipFile)) {
		if (zipExtract($ZipFile, ROOT)) {
			$scriptpath = str_replace('\\', '/', $_SERVER['SCRIPT_NAME']);
			$scriptpath = substr($scriptpath, 0, strrpos($scriptpath, '/'));
			$admin_path = substr($scriptpath, strrpos($scriptpath, '/') + 1);
			if ($admin_path != 'admin' && is_dir(ROOT . 'admin')) { //修改后台地址
				deldir(ROOT . $admin_path);
				rename(ROOT . 'admin', ROOT . $admin_path);
			}
			if (function_exists("opcache_reset")) @opcache_reset();
			$content = alert('程序更新成功！', 'success', '返回首页', './');
			unlink($ZipFile);
		} else {
			$content = alert('无法解压文件！', 'danger', '返回上级', 'update.php');
			if (file_exists($ZipFile)) unlink($ZipFile);
		}
	} else {
		$content = alert('无法下载更新包文件！', 'warning', '返回上级', 'update.php');
	}
} else {
	if ($res['update']) {
		if (!class_exists('ZipArchive', false) || defined("SAE_ACCESSKEY") || defined("BAE_ENV_APPID")) {
			$content = alert('您的空间不支持自动更新，请手动下载更新包并覆盖到程序根目录！', 'warning', '下载更新包', $res['file']);
		} else {
			$content = alert($res['message'], 'warning', '立即更新到最新版本', '?act=do');
		}
		$content .= uplog($res['content']);
	} else {
		$content = alert($res['message'], 'primary');
	}
}
echo system\admin\View::card($title, $content);

//函数
function alert($msg, $type, $button = null, $url = '#')
{
	$button = $button ? '
	<div class="d-grid">
		<a href="' . $url . '" class="btn btn-primary btn-round">' . $button . '</a>
	</div>
	' : null;
	$html = <<<HTML
	<div class="alert alert-{$type}" role="alert">{$msg}</div>
	{$button}
	HTML;
	return $html;
}
function uplog($data)
{
	$button = '';
	foreach ($data as $key => $value) {
		$button .= '<button type="button" class="list-group-item list-group-item-action">' . $value . '</button>';
	}
	$html = <<<HTML
	<hr />
	<div class="list-group">
		{$button}
	</div>
	HTML;
	return $html;
}
include 'modules/footer.php';