<?php

use system\admin\Form;
use system\admin\View;

$title = '修改密码';
include 'modules/header.php';
$form = [
    Form::input('旧密码', 'oldpwd', null, 'password', null, ['required' => true, 'class' => 'form-control']),
    Form::input('新密码', 'newpwd', null, 'password', null, ['required' => true, 'class' => 'form-control']),
    Form::input('确认新密码', 'confirmpwd', null, 'password', null, ['required' => true, 'class' => 'form-control'])
];
View::form($title, 'editPWD', null, $form);
include 'modules/footer.php';