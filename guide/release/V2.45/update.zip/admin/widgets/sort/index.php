<?php
$title = '导航分类管理';
include 'modules/header.php';
system\admin\View::table();
?>
<script>
	BootstrapTable.table = 'sort';
	BootstrapTable.columns = [{
			field: 'title',
			align: 'center',
			title: '分类',
			sortable: true,
			titleTooltip: '分类标题'
		},
		{
			field: 'order',
			align: 'center',
			sortable: true, // 是否作为排序列
			title: '排序',
		},
		{
			field: 'create_time',
			align: 'center',
			title: '创建时间',
			sortable: true
		}
	]
	BootstrapTable.init();
</script>