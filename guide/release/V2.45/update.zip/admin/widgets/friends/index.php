<?php
$title = '友链管理';
include 'modules/header.php';
system\admin\View::table();
?>
<script>
	BootstrapTable.table = 'friends';
	BootstrapTable.columns = [{
			field: 'title',
			align: 'center',
			title: '站点标题',
			sortable: true
		},
		{
			field: 'description',
			align: 'center',
			title: '站点简介',
			visible: false,
			width: '5',
			widthUnit: 'rem',
		},
		{
			field: 'keywords',
			align: 'center',
			title: '站点关键词',
			sortable: true,
			visible: false
		},
		{
			field: 'url',
			align: 'center',
			title: '链接',
			sortable: true,
			formatter: function(value) {
				return `<a href="${value}" target="_blank">${value}</a>`;
			}
		},
		{
			field: 'create_time',
			align: 'center',
			title: '创建时间',
			sortable: true
		}
	]
	BootstrapTable.init();
</script>