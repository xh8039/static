<?php

use JsonDb\JsonDb\Db;
use system\library\FormBuilder;

$title = '导航链接管理';
include 'modules/header.php';
$sort = Db::name('sort')->selectAll();
$list = [
	'all' => '所有类别'
];
foreach ($sort as $key => $value) {
	$list[$value['id']] = $value['title'];
}
$sort_select = FormBuilder::select('sort_select', $list, 'all', [
	'class' => 'form-control selectpicker',
	'style' => 'width: 100%;padding:6px 0px;',
	'onchange' => 'sort_select(this)'
]);
$sort_select = element('div')->attr(['class' => 'float-right mb-1 ms-1'])->get($sort_select);
system\admin\View::table($sort_select);
?>
<script>
	BootstrapTable.table = 'link';
	BootstrapTable.act = 'getLink';
	BootstrapTable.table_options.queryParams = (params) => {
		params.class = $('[name=sort_select]').val();
		return params;
	}
	BootstrapTable.columns = [{
			field: 'title',
			align: 'center',
			title: '标题',
			sortable: true,
			titleTooltip: '链接标题'
		},
		{
			field: 'url',
			align: 'center',
			title: '链接',
			titleTooltip: '链接内容',
			sortable: true,
			formatter: function(value) {
				return `<div class="hide" style="max-width:48vw"><a href="${value}" target="_blank">${value}</a></div>`;
			}
		},
		{
			field: "sort",
			title: '类别',
			titleTooltip: '所属分类',
			align: "center",
		},
		{
			field: 'order',
			align: 'center',
			sortable: true, // 是否作为排序列
			title: '排序',
		},
		{
			field: 'create_time',
			align: 'center',
			title: '创建时间',
			visible: false,
			sortable: true
		}
	]
	BootstrapTable.init();

	function sort_select(self) {
		var value = self.value;
		$('table').bootstrapTable('refresh', {
			query: {
				class: value
			}
		});
	}
</script>