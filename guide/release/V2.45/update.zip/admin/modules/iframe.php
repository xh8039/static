<?php
include_once $_SERVER['DOCUMENT_ROOT'] . '/public/common.php';
system\admin\Admin::check();
?>
<!DOCTYPE html>
<html lang="zh">

<head>
	<?php include_once 'head.php' ?>
</head>

<body style="background-color: #fff;height:auto">
	<div class="lyear-layout-web">
		<div class="lyear-layout-container">
			<!--页面主要内容-->
			<main>
				<div style="padding:0.5rem 1.5rem 1.5rem 1.5rem;">