<script>
    const Base64 = {
        encode(str) {
            return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g,
                function toSolidBytes(match, p1) {
                    return String.fromCharCode('0x' + p1);
                }));
        },
        decode(str) {
            return decodeURIComponent(atob(str).split('').map(function(c) {
                return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
            }).join(''));
        }
    }
    window.SERVER = {
        DEMO_MODE: <?= DEMO_MODE ? 'true' : 'false' ?>,
        API: Base64.decode('Ly9hdXRoLmJyaTYuY24vc2VydmVyL2d1aWRlLw==')
    }
</script>