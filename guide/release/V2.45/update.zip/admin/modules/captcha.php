<?php
session_start();
require $_SERVER['DOCUMENT_ROOT'] . '/system/library/Captcha.php';
$_vc = new system\library\Captcha();
$_vc->doimg();
$_SESSION['admin_captcha'] = $_vc->getCode();