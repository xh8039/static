<?php

/*
 * @Author        : 易航
 * @Url           : blog.bri6.cn
 * @Date          : 2020-09-29 13:18:36
 * @LastEditTime  : 2022-10-26 21:46:06
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址引导系统
 * @Description   : 一款极其优雅的易航网址引导系统
 * @Read me       : 感谢您使用易航网址引导系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/

use JsonDb\JsonDb\Db;

include_once $_SERVER['DOCUMENT_ROOT'] . '/public/common.php';
system\admin\Server::clearAll();
$title = '后台首页';
include_once 'modules/header.php';
?>
<div class="row" id="auth">
	<div class="col-md-12">
		<div class="card">
			<header class="card-header d-flex justify-content-between">
				<div class="card-title"><i class="mdi mdi-cart-variant"></i> <?= base64_decode('6LWe5Yqp6K+05piO') ?></div>
				<ul class="card-actions">
					<li><a href="javascript:void(0)" class="card-btn-close"><i class="mdi mdi-close"></i></a></li>
					<li><a href="javascript:void(0)" class="card-btn-slide"><i class="mdi mdi-chevron-up"></i></a></li>
					<li><a href="javascript:void(0)" class="card-btn-fullscreen"><i class="mdi mdi-fullscreen"></i></a></li>
				</ul>
			</header>
			<div class="card-body" id="sponsor"><?= base64_decode('4p2k77iP5oSf6LCi5oKo5L2/55So5piT6Iiq572R5Z2A5a+86Iiq57O757uf77yB5pys5Lq65byA5Y+R5q2k6aG555uu55qE5Yid6KG35piv5Li65LqG5L6/5o235bm/5aSn55So5oi3566h55CG572R5Z2A5a+86Iiq6aG177yM5L2G5piv5LiA5Liq5Lq65byA5Y+R6ZyA6KaB6ICX6LS55b6I5aSa55qE57K+5Yqb5ZKM5pe26Ze077yM5Lya5Y2g55So5b6I5aSa5pel5bi45pe26Ze05bm25LiU5peg5pS25YWl77yM6L+Z5qC35a+86Ie05oiR546w5Zyo5ZCD6aWt6YO95piv5LiA5Liq6Zeu6aKY44CC5oiR5b2T5Yid5Lmf5pu+6Lqr5Li655So5oi35p2l6LSt5Lmw5LuW5Lq65byA5Y+R55qE57O757uf77yM5Lmf5piO55m955m95auW55qE5aW95aSE77yM5YW25a6e6LS15Yiw5aSn5Yeg55m+55qE57O757uf6Z2e5bi45pyJ5b+F6KaB55m95auW77yM6ICM5pys57O757uf5bm26Z2e5by65Yi25pS26LS577yM5Y+q6K+35rGC5oKo6LWe5YqpNTguODjlhYPnmoTkuIDlpKnppa3pkrHvvIzkuZ/mmK/luIzmnJvmgqjlj6/ku6Xlr7nmiJHov5vooYzkuIDngrnngrnnmoTmjZDmrL7vvIzlr7nmnKzns7vnu5/mj5Dkvpvnu7TmiqTlkozlvIDlj5HnmoTliqjlipvjgII=') ?></div>
		</div>
	</div>
</div>
<div class="row">

	<div class="col-md-6 col-xl-3">
		<div class="card bg-primary text-white">
			<div class="card-body">
				<div class="d-flex justify-content-between">
					<span class="avatar-md rounded-circle bg-white bg-opacity-25 avatar-box">
						<i class="mdi mdi-currency-cny fs-4"></i>
					</span>
					<span class="fs-4"><?= Db::name('link')->count() ?></span>
				</div>
				<div class="text-end">链接总数</div>
			</div>
		</div>
	</div>

	<div class="col-md-6 col-xl-3">
		<div class="card bg-danger text-white">
			<div class="card-body">
				<div class="d-flex justify-content-between">
					<span class="avatar-md rounded-circle bg-white bg-opacity-25 avatar-box">
						<i class="mdi mdi-account fs-4"></i>
					</span>
					<span class="fs-4"><?= Db::name('friends')->count() ?></span>
				</div>
				<div class="text-end">友链总数</div>
			</div>
		</div>
	</div>

	<div class="col-md-6 col-xl-3">
		<div class="card bg-success text-white">
			<div class="card-body">
				<div class="d-flex justify-content-between">
					<span class="avatar-md rounded-circle bg-white bg-opacity-25 avatar-box">
						<i class="mdi mdi-arrow-down-bold fs-4"></i>
					</span>
					<span class="fs-4"><?= count(system\theme\Manager::getList()) ?></span>
				</div>
				<div class="text-end">主题总数</div>
			</div>
		</div>
	</div>

	<div class="col-md-6 col-xl-3">
		<div class="card bg-purple text-white">
			<div class="card-body">
				<div class="d-flex justify-content-between">
					<span class="avatar-md rounded-circle bg-white bg-opacity-25 avatar-box">
						<i class="mdi mdi-comment-outline fs-4"></i>
					</span>
					<span class="fs-4"><?= count(system\plugin\Manager::getList()) ?></span>
				</div>
				<div class="text-end">插件总数</div>
			</div>
		</div>
	</div>

</div>

<div class="row">
	<div class="col-md-6">
		<div class="card">
			<header class="card-header d-flex justify-content-between">
				<div class="card-title"><i class="mdi mdi-link-plus"></i> 每周友链</div>
				<ul class="card-actions">
					<li><a href="javascript:void(0)" class="card-btn-close"><i class="mdi mdi-close"></i></a></li>
					<li><a href="javascript:void(0)" class="card-btn-slide"><i class="mdi mdi-chevron-up"></i></a></li>
					<li><a href="javascript:void(0)" class="card-btn-fullscreen"><i class="mdi mdi-fullscreen"></i></a></li>
				</ul>
			</header>
			<div class="card-body">
				<canvas class="js-chartjs-bars"></canvas>
			</div>
		</div>
	</div>
	<div class="col-md-6">
		<div class="card">
			<header class="card-header d-flex justify-content-between">
				<div class="card-title"><i class="mdi mdi-information-outline"></i> 环境信息</div>
				<ul class="card-actions">
					<li><a href="javascript:void(0)" class="card-btn-close"><i class="mdi mdi-close"></i></a></li>
					<li><a href="javascript:void(0)" class="card-btn-slide"><i class="mdi mdi-chevron-up"></i></a></li>
					<li><a href="javascript:void(0)" class="card-btn-fullscreen"><i class="mdi mdi-fullscreen"></i></a></li>
				</ul>
			</header>
			<div class="card-body">
				<style>
					.card-body>.nav>li:hover {
						background-color: #f5f5f5;
						transition: 0.2s;
					}

					.card-body>.nav {
						display: block;
					}

					.card-body>.nav>li {
						padding: 0.35rem;
						border-radius: 0.3rem;
						margin-top: 0.45vw;
						margin-bottom: 0.45vw;
					}
				</style>
				<ul class="nav">
					<li><b>服务器时间：</b><?= date_time() ?></li>
					<li><b>PHP 版本：</b><?= phpversion() ?></li>
					<li><b><a href="https://gitee.com/yh_IT/json-db" target="_blank">JsonDb</a> 版本：</b>2.5</li>
					<li><b>服务器软件：</b><?= $_SERVER['SERVER_SOFTWARE'] ?></li>
					<li><b><?= base64_decode('56iL5bqP5ZCN56ew77ya') ?></b><a href="https://gitee.com/yh_IT/guide" target="_blank"><?= base64_decode('5piT6Iiq572R5Z2A5byV5a+857O757uf') ?></a> </li>
					<li><b><?= base64_decode('5b2T5YmN54mI5pys77ya') ?></b><?= strval(VERSION) ?></li>
					<li><b><?= base64_decode('6aG555uu5L2c6ICF77ya') ?></b> <a href="tencent://message/?uin=2136118039" target="_blank"><?= base64_decode('5piT6Iiq') ?></a></li>
				</ul>
			</div>
		</div>
	</div>
</div>

<div class="row">
	<div class="col-md-6">
		<div class="card">
			<header class="card-header d-flex justify-content-between">
				<div class="card-title"><i class="mdi mdi-update"></i> <?= base64_decode('5qOA5rWL5pu05paw') ?></div>
				<ul class="card-actions">
					<li><a href="javascript:void(0)" class="card-btn-close"><i class="mdi mdi-close"></i></a></li>
					<li><a href="javascript:void(0)" class="card-btn-slide"><i class="mdi mdi-chevron-up"></i></a></li>
					<li><a href="javascript:void(0)" class="card-btn-fullscreen"><i class="mdi mdi-fullscreen"></i></a></li>
				</ul>
			</header>
			<div class="card-body" id="update">暂无更新</div>
		</div>
	</div>
	<div class="col-md-6">
		<div class="card">
			<header class="card-header d-flex justify-content-between">
				<div class="card-title"><i class="mdi mdi-message-outline"></i> <?= base64_decode('5a6Y5pa55YWs5ZGK') ?></div>
				<ul class="card-actions">
					<?= base64_decode('PGEgaHJlZj0iaHR0cDovL2d1aWRlLmJyaTYuY24iIHJlbD0iY29weXJpZ2h0IiB0YXJnZXQ9Il9ibGFuayI+5a6Y5pa5572R56uZPC9hPg==') ?>
				</ul>
			</header>
			<div class="card-body" id="notice"><span style="color: red;display:none;" id="incomplete-prompt"><?= base64_decode('5qOA5rWL5Yiw5oKo55uu5YmN5L2/55So55qE57O757uf5a2Y5Zyo5q6L57y65oOF5Ya177yM5pWw5o2u5rOE6Zyy44CB5o2f5aSx44CB5ZKMQlVH5ryP5rSe562J5Lil6YeN6Zeu6aKY5Lya6auY5qaC546H5oyB57ut5a2Y5Zyo77yM5bm25LiU5p6B5piT6KKr5LiN5rOV6buR5a6i5YWl5L615pyN5Yqh5Zmo6YCg5oiQ5oKo55qE6LSi5Lqn5o2f5aSx77yM6K+35bC95b+rIDxhIGhyZWY9Imh0dHA6Ly9ndWlkZS5icmk2LmNuIiB0YXJnZXQ9Il9ibGFuayI+5YmN5b6A5a6Y572RPC9hPiDkuIvovb3mmJPoiKrnvZHlnYDlvJXlr7zns7vnu5/lrpjmlrnmraPniYjnqIvluo8=') ?></span></div>
		</div>
	</div>
</div>

<div class="row">
	<div class="col-md-12">
		<div class="card">
			<header class="card-header d-flex justify-content-between">
				<div class="card-title"><i class="mdi mdi-security"></i> 安全中心</div>
				<ul class="card-actions">
					<li><a href="javascript:void(0)" class="card-btn-close"><i class="mdi mdi-close"></i></a></li>
					<li><a href="javascript:void(0)" class="card-btn-slide"><i class="mdi mdi-chevron-up"></i></a></li>
					<li><a href="javascript:void(0)" class="card-btn-fullscreen"><i class="mdi mdi-fullscreen"></i></a></li>
				</ul>
			</header>
			<div class="card-body">
				<ul class="list-group">
					<?= implode(PHP_EOL, system\admin\View::safeCheck()) ?>
				</ul>
			</div>
		</div>
	</div>
</div>

<?php include 'modules/footer.php' ?>
<!--引入chart插件js-->
<script type="text/javascript" src="<?= cdn('Chart.js/3.9.1/chart.min.js') ?>"></script>
<script type="text/javascript">
	(function(SERVER) {
		$.get('server.php?action=getUpdate', function(data) {
			if (data.update) {
				update.innerHTML = `发现新版本${data.version}，旧版本将停止维护，请尽快前往更新页面更新`
				return
			}
			update.innerHTML = data.message
		}, 'json');
		$.get(SERVER.API + 'homeInfo', function(data) {
			sponsor.innerHTML = data.sponsor
			if (SERVER.DEMO_MODE) {
				notice.innerHTML = '暂无公告'
			} else {
				notice.innerHTML = data.notice
			}
		});
	}(SERVER))
	$(document).ready(function(e) {
		var dashChartBarsCnt = jQuery('.js-chartjs-bars')[0].getContext('2d')
		var dashChartBarsData = {
			labels: ['周一', '周二', '周三', '周四', '周五', '周六', '周日'],
			datasets: [{
				label: '新增友链',
				borderWidth: 1,
				borderColor: 'rgba(0, 0, 0, 0)',
				backgroundColor: 'rgba(0, 123, 255,0.5)',
				hoverBackgroundColor: "rgba(0, 123, 255, 0.7)",
				hoverBorderColor: "rgba(0, 0, 0, 0)",
				data: [2500, 1500, 1200, 3200, 4800, 3500, 1500]
			}]
		};
		new Chart(dashChartBarsCnt, {
			type: 'bar',
			data: dashChartBarsData
		});
		setTimeout(() => {
			if ($('#incomplete-prompt')) {
				$('#incomplete-prompt').show()
			}
		}, 3000);
	});
</script>