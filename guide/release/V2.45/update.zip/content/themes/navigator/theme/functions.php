<?php

if (!defined('ROOT')) exit;

function sortConfig(\system\theme\Fields $form)
{
	$form->input('分类图标', 'logo', null, 'url', '图像文件URL直链');
}

function linkConfig(\system\theme\Fields $form)
{
	$form->input('链接图标', 'logo', null, 'url', '图像文件URL直链');
}