<?php

function themeConfig(\system\theme\Form $form)
{
	$weixin = $form->input('微信二维码图片链接', 'weixin', null, 'text');
	$form->create($weixin);

	$email = $form->input('底部联系邮箱账号', 'email', null, 'email');
	$form->create($email);
}

// function sortConfig(\system\theme\Fields $form)
// {
//     $form->input('分类图标', 'icon', null, 'text', '说明：请输入阿里巴巴图标库创建的项目的Symbol类型的icon代码<br>例如：icon-gonggao<br>阿里巴巴图标库：<a href="https://www.iconfont.cn" target="_blank">www.iconfont.cn</a>');
// }

// function linkConfig(\system\theme\Fields $form)
// {
//     $form->input('链接图标', 'icon', null, 'text', '说明：请输入阿里巴巴图标库创建的项目的Symbol类型的icon代码<br>例如：icon-gonggao<br>阿里巴巴图标库：<a href="https://www.iconfont.cn" target="_blank">www.iconfont.cn</a>');
// }