<?php
if (!defined('ROOT')) exit;
?>
<style>
    html body {
        background: url(<?= $this->site->background_PC ?>) no-repeat;
        background-attachment: fixed;
        background-size: cover;
        background-position: center center;
    }
</style>