<?php
define('VERSION', 2.45);