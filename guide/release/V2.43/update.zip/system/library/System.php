<?php

namespace system\library;

use JsonDb\JsonDb\Db;

class System
{
	public static function version()
	{
		return VERSION;
	}

	public static function alert($content, $location = false)
	{
		$script = element('script');
		$content = 'alert("' . $content . '")' . ($location ? ';window.location.href="' . $location . '"' : null);
		echo $script->get($content);
	}

	// /**
	//  * 判断是否首页
	//  */
	// public static function isIndex()
	// {
	// 	$pathInfo = Route::getPathInfo();
	// 	if ($_SERVER['DOCUMENT_URI'] == '/index.php' && $pathInfo == 'index') {
	// 		return true;
	// 	}
	// 	return false;
	// }

	public static function scandir($dir)
	{
		// 扫描$con目录下的所有文件
		$filename = scandir($dir);
		// 定义一个数组接收文件名
		$conname = array();
		foreach ($filename as $v) {
			// 跳过两个特殊目录   continue跳出循环
			if ($v == "." || $v == "..") {
				continue;
			}
			//截取文件名，我只需要文件名不需要后缀;然后存入数组。如果你是需要后缀直接$v即可
			$conname[] = $v;
		}
		return $conname;
	}

	public static function response404()
	{
		http_response_code(404);
		if (\system\theme\Manager::needFile('404') === false) {
			$suffix = ['php', 'html'];
			foreach ($suffix as $value) {
				$file_404 = ROOT . '404.' . $value;
				if (is_file($file_404)) {
					include_once $file_404;
					exit;
				}
			}
		}
		exit;
	}

	/**
	 * 解析注释信息
	 */
	public static function parseAnnotate($annotate)
	{
		$annotate = str_replace('/**' . PHP_EOL, '', $annotate);
		$annotate = str_replace('/**', '', $annotate);
		$annotate = str_replace(PHP_EOL . '*/', '', $annotate);
		$annotate = str_replace(PHP_EOL . ' */', '', $annotate);
		$annotate = explode('*', $annotate);
		$annotate = array_filter($annotate, 'trim');
		foreach ($annotate as $key => $value) {
			unset($annotate[$key]);
			preg_match('/@(\w+)(.*)/', $value, $match);
			$name = isset($match[1]) ? $match[1] : $key;
			$value = isset($match[2]) ? $match[2] : $value;
			$annotate[$name] = trim($value);
		}
		return $annotate;
	}

	public static function getFileAnnotate($file_name)
	{
		if (file_exists($file_name)) {
			$docComments = array_filter(
				token_get_all(file_get_contents($file_name)),
				function ($entry) {
					return $entry[0] == T_DOC_COMMENT;
				}
			);
			$fileDocComment = array_shift($docComments);
			return $fileDocComment[1];
		}
	}

	public static function getSort($id = null)
	{
		$select = isset($id) ? Db::name('sort')->where(['id' => $id, 'status' => 1])->find() : Db::name('sort')->where('status', 1)->order('order')->select();
		return $select;
	}

	public static function getLink($cid = null)
	{
		$select = is_null($cid) ? Db::name('link')->where('status', 1)->order('order')->select() : Db::name('link')->where(['cid' => $cid, 'status' => 1])->order('order')->select();
		return $select;
	}

	public static function getFriend()
	{
		return Db::name('friends')->where('status', 1)->order('referer_count')->select();
	}

	/**
	 * 多维对象转数组
	 */
	static public function objectToArray($d)
	{
		if (is_object($d)) {
			$d = get_object_vars($d); // 获取给定对象的属性
		}
		if (is_array($d)) {
			$function = __FUNCTION__;
			return array_map("self::$function", $d);
		} else {
			return $d;
		}
	}

	/**
	 * 多维数组转对象
	 */
	static public function arrayToObject(array $d)
	{
		if (is_array($d)) {
			$json = json_encode($d);
			return json_decode($json);
		} else {
			return $d;
		}
	}

	/**
	 * 发送电子邮件
	 * @access public
	 * @param string $title 邮件标题
	 * @param string $subtitle 邮件副标题
	 * @param string $content 邮件内容
	 * @param string $email 不填写则默认发送系统配置中的邮箱，优先程度：配置收件人>发信邮箱
	 * @return bool
	 */
	public static function sendEmail($title, $subtitle, $content, $email = null)
	{
		global $options;
		global $site;
		$mail = $options['mail'];
		$mail_config = [
			'SMTPSecure' => $mail['secure'], // 允许 TLS 或者ssl协议
			'Host' => $mail['smtp'], // SMTP服务器
			'Port' => $mail['port'], // 服务器端口 25 或者465
			'FromName' => $site['title'], //发件人昵称
			'Username' => $mail['name'], //邮箱账号
			'Password' => $mail['pwd'] //邮箱密码
		];
		if (empty($email)) {
			$email = empty($mail['recv']) ? $mail['name'] : $mail['recv'];
		}
		$mail = new \PHPMailer\PHPMailer\PHPMailer();
		$language = $mail->setLanguage('zh_cn');
		if (!$language) {
			echo '语言文件加载失败';
		}
		$mail->isSMTP();
		$mail->SMTPAuth = true;
		$mail->CharSet = 'UTF-8';
		$mail->SMTPSecure = $mail_config['SMTPSecure'];
		$mail->Host = $mail_config['Host'];
		$mail->Port = $mail_config['Port'];
		$mail->FromName = $mail_config['FromName'];
		$mail->Username = $mail_config['Username'];
		$mail->From = $mail_config['Username'];
		$mail->Password = $mail_config['Password'];
		$mail->isHTML(true);
		$html = '<style>.container{width:550px;margin:0 auto;border-radius:8px;overflow:hidden;font-family:"Helvetica Neue",Helvetica,"PingFang SC","Hiragino Sans GB","Microsoft YaHei","微软雅黑",Arial,sans-serif;box-shadow:0 2px 12px 0 rgba(0,0,0,0.1);word-break:break-all}.title{color:#fff;background:linear-gradient(-45deg,rgba(9,69,138,0.2),rgba(68,155,255,0.7),rgba(117,113,251,0.7),rgba(68,155,255,0.7),rgba(9,69,138,0.2));background-size:400% 400%;background-position:50% 100%;padding:15px;font-size:15px;line-height:1.5}</style><div class="container"><div class="title">{title}</div><div style="background: #fff;padding: 20px;font-size: 13px;color: #666;"><div style="margin-bottom: 20px;line-height: 1.5;">{subtitle}</div><div style="padding: 15px;margin-bottom: 20px;line-height: 1.5;background: repeating-linear-gradient(145deg, #f2f6fc, #f2f6fc 15px, #fff 0, #fff 25px);">{content}</div><div style="line-height: 2">请注意：此邮件由系统自动发送，请勿直接回复。<br>若此邮件不是您请求的，请忽略并删除！</div></div></div>';
		$mail->Body = strtr(
			$html,
			[
				"{title}" => $title . ' - ' . $mail_config['FromName'],
				"{subtitle}" => $subtitle,
				"{content}" => $content,
			]
		);
		$mail->addAddress($email);
		$mail->Subject = $title . ' - ' . $mail_config['FromName'];
		if ($mail->send()) {
			return true;
		} else {
			print_r('Mailer 错误：' . $mail->ErrorInfo);
			return false;
		}
	}
}
