<?php

use system\library\Options;
use system\library\Statics;

/**
 * 获取配置信息
 */
function options($name = false, $value = false)
{
	if ($name === false) {
		return Options::all();
	}
	if ($value !== false) {
		return Options::save($name, $value);
	}
	return Options::get($name);
}

function date_time()
{
	return date('Y-m-d H:i:s');
}

/**
 * 动态创建Element元素
 *
 * @param string $element
 * @return system\library\ElementBuilder
 */
function element($element)
{
	return new system\library\ElementBuilder($element);
}

/**
 * 生成站点URl
 * @param $path URL路径
 * @param $param URL参数
 */
function url($path, $param = null)
{
	$url = 'http://' . DOMAIN . '/' . $path;
	if ($param) {
		$param = http_build_query($param);
		$url = strstr($url, '?') ? trim($url, '&') . '&' .  $param : $url . '?' .  $param;
	}
	return $url;
}

/**
 * 输出CDN链接
 *
 * @param string|null $path 子路径
 * @param string|null $type 调用函数
 * @return string
 */
function cdn($path)
{
	$cdnpublic = '//cdn.bootcdn.net/ajax/libs/';
	$url = $cdnpublic . $path;
	return $url;
}

function LightYearV5($path, $version = VERSION)
{
	return Statics::LightYear(5, $path, $version);
}

// function jsdelivr($path, $version = VERSION)
// {
// 	return Statics::github()->guide($path, $version);
// }

// function gitee($path, $version = VERSION)
// {
// 	return Statics::gitee($path, $version);
// }

function zipExtract($src, $dest)
{
	// 通过ZipArchive的对象处理zip文件
	$zip = new ZipArchive(); //新建一个ZipArchive的对象
	/*
	$zip->open这个方法的参数表示处理的zip文件名。
	如果对zip文件对象操作成功，$zip->open这个方法会返回TRUE
	*/
	if ($zip->open($src) === true) {
		$zip->extractTo($dest); //假设解压缩到$dest路径文件夹的子文件夹php
		$zip->close(); //关闭处理的zip文件
		return true;
	}
	return false;
}

function deldir($dir)
{
	if (!is_dir($dir)) return false;
	$dh = opendir($dir);
	while ($file = readdir($dh)) {
		if ($file != "." && $file != "..") {
			$fullpath = $dir . "/" . $file;
			if (!is_dir($fullpath)) {
				unlink($fullpath);
			} else {
				deldir($fullpath);
			}
		}
	}
	closedir($dh);
	if (rmdir($dir)) {
		return true;
	} else {
		return false;
	}
}

function halt($var)
{
	print_r($var);
	exit;
}

function is_image()
{
	if (
		function_exists('imagecolorallocate') &&
		function_exists('imagecreatetruecolor') &&
		function_exists('imagefilledrectangle') &&
		function_exists('imagestring') &&
		function_exists('imagettftext') &&
		function_exists('imageline') &&
		function_exists('imagepng') &&
		function_exists('imagedestroy')
	) return true;
	return false;
}

function function_check()
{
	if (PHP_VERSION < 7.3) {
		sysmsg(base64_decode('5oKo55qEUEhQ54mI5pys6L+H5L2O77yM6K+35L2/55SoVjcuNOWPiuS7peS4iueJiOacrOi/kOihjCA8YSBocmVmPSJodHRwOi8vZ3VpZGUuYnJpNi5jbiIgdGFyZ2V0PSJfYmxhbmsiPuaYk+iIque9keWdgOW8leWvvOezu+e7nzwvYT4='));
	}

	if (extension_loaded('curl') !== true) {
		sysmsg(base64_decode('5oKo55qEUEhQ5rKh5pyJ5byA5ZCvQ3VybOaLk+Wxle+8jOivt+W8gOWQr0N1cmzmi5PlsZXlkI7ov5DooYwgPGEgaHJlZj0iaHR0cDovL2d1aWRlLmJyaTYuY24iIHRhcmdldD0iX2JsYW5rIj7mmJPoiKrnvZHlnYDlvJXlr7zns7vnu588L2E+'));
	}
	$json_db_root = CONTENT_ROOT . 'JsonDb';
	if (!is_readable($json_db_root) || !is_writable($json_db_root)) sysmsg('您的站点目录下content/JsonDb文件夹没有读或写权限，请开放该文件夹及子目录的读写权限或 设置755或0755权限 后运行 ' . base64_decode('PGEgaHJlZj0iaHR0cDovL2d1aWRlLmJyaTYuY24iIHRhcmdldD0iX2JsYW5rIj7mmJPoiKrnvZHlnYDlvJXlr7zns7vnu588L2E+'));
}

function is_mobile()
{
	$user_agent = $_SERVER['HTTP_USER_AGENT'];
	return preg_match("/(Android|webOS|iPhone|iPod|BlackBerry|IEMobile|Opera Mini)/i", $user_agent);
}

function is_pc()
{
	return (is_mobile() ? false : true);
}

/**
 * 获取指定目录下的文件和目录列表
 *
 * @param string $directory 要扫描的目录
 * @return system\library\DirScanner
 */
function scan_dir(string $directory): system\library\DirScanner
{
	return new system\library\DirScanner($directory);
}






function sysmsg($msg = '未知的异常', $title = '站点提示信息')
{
?>
	<!DOCTYPE html>
	<html xmlns="http://www.w3.org/1999/xhtml" lang="zh-CN">

	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title><?php echo $title ?></title>
		<style type="text/css">
			html {
				background: #eee
			}

			body {
				background: #fff;
				color: #333;
				font-family: "微软雅黑", "Microsoft YaHei", sans-serif;
				margin: 2em auto;
				padding: 1em 2em;
				max-width: 700px;
				-webkit-box-shadow: 10px 10px 10px rgba(0, 0, 0, .13);
				box-shadow: 10px 10px 10px rgba(0, 0, 0, .13);
				opacity: .8
			}

			h1 {
				border-bottom: 1px solid #dadada;
				clear: both;
				color: #666;
				font: 24px "微软雅黑", "Microsoft YaHei", sans-serif;
				margin: 30px 0 0 0;
				padding: 0;
				padding-bottom: 7px
			}

			#error-page {
				margin-top: 50px
			}

			h3 {
				text-align: center
			}

			#error-page p {
				font-size: 9px;
				line-height: 1.5;
				margin: 25px 0 20px
			}

			#error-page code {
				font-family: Consolas, Monaco, monospace
			}

			ul li {
				margin-bottom: 10px;
				font-size: 9px
			}

			a {
				color: #21759B;
				text-decoration: none;
				margin-top: -10px
			}

			a:hover {
				color: #D54E21
			}

			.button {
				background: #f7f7f7;
				border: 1px solid #ccc;
				color: #555;
				display: inline-block;
				text-decoration: none;
				font-size: 9px;
				line-height: 26px;
				height: 28px;
				margin: 0;
				padding: 0 10px 1px;
				cursor: pointer;
				-webkit-border-radius: 3px;
				border-radius: 3px;
				white-space: nowrap;
				-webkit-box-sizing: border-box;
				-moz-box-sizing: border-box;
				box-sizing: border-box;
				-webkit-box-shadow: inset 0 1px 0 #fff, 0 1px 0 rgba(0, 0, 0, .08);
				box-shadow: inset 0 1px 0 #fff, 0 1px 0 rgba(0, 0, 0, .08);
				vertical-align: top
			}

			.button.button-large {
				height: 29px;
				line-height: 28px;
				padding: 0 12px
			}

			.button:focus,
			.button:hover {
				background: #fafafa;
				border-color: #999;
				color: #222
			}

			.button:focus {
				-webkit-box-shadow: 1px 1px 1px rgba(0, 0, 0, .2);
				box-shadow: 1px 1px 1px rgba(0, 0, 0, .2)
			}

			.button:active {
				background: #eee;
				border-color: #999;
				color: #333;
				-webkit-box-shadow: inset 0 2px 5px -3px rgba(0, 0, 0, .5);
				box-shadow: inset 0 2px 5px -3px rgba(0, 0, 0, .5)
			}

			table {
				table-layout: auto;
				border: 1px solid #333;
				empty-cells: show;
				border-collapse: collapse
			}

			th {
				padding: 4px;
				border: 1px solid #333;
				overflow: hidden;
				color: #333;
				background: #eee
			}

			td {
				padding: 4px;
				border: 1px solid #333;
				overflow: hidden;
				color: #333
			}
		</style>
	</head>

	<body id="error-page">
		<?php echo '<h3>' . $title . '</h3>';
		echo $msg; ?>
	</body>

	</html>
<?php
	exit;
}
