<?php

/**
 *                        _oo0oo_
 *                       o8888888o
 *                       88" . "88
 *                       (| -_- |)
 *                       0\  =  /0
 *                     ___/`---'\___
 *                   .' \\|     |// '.
 *                  / \\|||  :  |||// \
 *                 / _||||| -:- |||||- \
 *                |   | \\\  - /// |   |
 *                | \_|  ''\---/''  |_/ |
 *                \  .-\__  '-'  ___/-. /
 *              ___'. .'  /--.--\  `. .'___
 *           ."" '<  `.___\_<|>_/___.' >' "".
 *          | | :  `- \`.;`\ _ /`;.`/ - ` : | |
 *          \  \ `_.   \_ __\ /__ _/   .-` /  /
 *      =====`-.____`.___ \_____/___.-`___.-'=====
 *                        `=---='
 *
 *
 *      ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 *            佛祖保佑       永不宕机     永无BUG
 *
 */
header('Generator: YiHang');
header('Author: YiHang');
session_start();
date_default_timezone_set('PRC');
define('ROOT', (empty($_SERVER['DOCUMENT_ROOT']) ? dirname(dirname(__FILE__)) : $_SERVER['DOCUMENT_ROOT']) . DIRECTORY_SEPARATOR);
define('CONTENT_ROOT', ROOT . 'content' . DIRECTORY_SEPARATOR);
define('PLUGINS_ROOT', CONTENT_ROOT . 'plugins' . DIRECTORY_SEPARATOR);
define('THEME_PATH', CONTENT_ROOT . 'themes' . DIRECTORY_SEPARATOR);
define('PUBLIC_ROOT', ROOT . 'public' . DIRECTORY_SEPARATOR);
define('SYSTEM_ROOT', ROOT . 'system' . DIRECTORY_SEPARATOR);
define('DOMAIN', addslashes($_SERVER['HTTP_HOST']));
define('YH_SERVER', base64_decode('aHR0cDovL2F1dGguYnJpNi5jbi9zZXJ2ZXIvZ3VpZGUv'));
define('DATE', date('Y-m-d'));

require PUBLIC_ROOT . 'version.php';

(function () {
	if (file_exists(PUBLIC_ROOT . 'config.php')) {
		require_once PUBLIC_ROOT . 'config.php';
	}
	$config = ['APP_DEBUG' => false, 'DEMO_MODE' => false,'ADMIN_DIR'=>'/admin'];
	foreach ($config as $key => $value) {
		if (!defined($key)) define($key, $value);
	}
})();

if (APP_DEBUG === false) error_reporting(E_ERROR);

include_once PUBLIC_ROOT . 'functions.php'; // 引入公共函数库

function_check();

include_once PUBLIC_ROOT . 'autoload.php';

JsonDb\JsonDb\Db::setConfig([
	'path' => CONTENT_ROOT . 'JsonDb',
	'debug' => APP_DEBUG
]);

$options = options();
$site = options('site');

define('THEME', empty($options['current_theme']) ? 'SimpleNavigation' : $options['current_theme']);
define('THEME_ROOT', THEME_PATH . THEME . DIRECTORY_SEPARATOR);
(function () {
	if (APP_DEBUG === true) return;
	$options_name = ('files_md5:' . VERSION);
	if (is_array(options($options_name)) && !empty(options($options_name))) return;
	$admin_dir = $_SERVER['DOCUMENT_ROOT'] . ADMIN_DIR . DIRECTORY_SEPARATOR;
	$file_list = [
		$admin_dir . 'update.php', $admin_dir . 'server.php',
		SYSTEM_ROOT . 'admin' . DIRECTORY_SEPARATOR . 'Server.php'
	];
	$files_md5 = [];
	foreach ($file_list as $file) {
		if (empty($options[$options_name][$file])) {
			$files_md5[$file] = md5_file($file);
		}
	}
	options($options_name, $files_md5);
})();