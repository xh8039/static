<?php



namespace content\plugins\Demo;

/**
 * 这只是易航写个一个默认插件演示
 *
 * @package 插件演示
 * @author 易航
 * @version 1.0
 * @link http://blog.bri6.cn
 */
class Plugin
{

	/** 插件配置信息 */
	public static $options;

	/** 插件自定义配置 */
	public static function config(\system\plugin\Form $form)
	{
		$input = $form->input('输入框标题', 'demo', '这只是易航写个一个默认插件演示', 'input_type', '一个提示', ['input_option' => '111']);
		$form->create($input);

		return $form; // 必须返回实例化的form对象
	}

	/**
	 * 默认触发方法
	 */
	public static function render()
	{
		// echo self::$options->demo;
	}

	/**
	 * 前台页面脚页触发方法
	 */
	public static function footer()
	{
		// echo '已经到达页面底部喽';
	}
}
