				</div>
				<div role="contentinfo" class="copyright">
					<span><?= base64_decode('5pys57O757uf55SxIDxhIHRhcmdldD0iX2JsYW5rIiBocmVmPSJodHRwOi8vZ3VpZGUuYnJpNi5jbiI+5piT6Iiq572R5Z2A5byV5a+857O757ufPC9hPiDlvLrlipvpqbHliqgsIOeJiOacrCA=') ?><?= VERSION ?></span>
					<div class="resource">
						<?= base64_decode('PGEgaHJlZj0iaHR0cHM6Ly95ZXB5ZHZtcHhvLmsudG9wdGhpbmsuY29tL0BndWlkZS8iIHRhcmdldD0iX2JsYW5rIj7luK7liqnmlofmoaM8L2E+IOKAogo8YSBocmVmPSJodHRwOi8vYnJpNi5jbi9hcmNoaXZlcy8zMzUuaHRtbCIgdGFyZ2V0PSJfYmxhbmsiPuaUr+aMgeiuuuWdmzwvYT4g4oCiCjxhIGhyZWY9Imh0dHBzOi8vZ2l0ZWUuY29tL3loX0lUL2d1aWRlL2lzc3VlcyIgdGFyZ2V0PSJfYmxhbmsiPuaKpeWRiumUmeivrzwvYT4g4oCiCjxhIGhyZWY9Imh0dHBzOi8vZ2l0ZWUuY29tL3loX0lUL2d1aWRlIiB0YXJnZXQ9Il9ibGFuayI+6LWE5rqQ5LiL6L29PC9hPg==') ?>
					</div>
				</div>
				<script>
					if (self.frameElement && self.frameElement.tagName == "IFRAME") {
  						$('.copyright').hide();
					}
				</script>
			</main>
			<!--End 页面主要内容-->
		</div>
	</div>
	<!-- <script type="text/javascript" src="<?= cdn('mouse0270-bootstrap-notify/3.1.3/bootstrap-notify.min.js') ?>"></script> -->
	<!--时间日期选择器js-->
	<!-- <script type="text/javascript" src="assets/js/momentjs/moment.min.js"></script> -->
	<!-- <script type="text/javascript" src="assets/js/bootstrap-datetimepicker/bootstrap-datetimepicker.min.js"></script> -->
	<!-- <script type="text/javascript" src="assets/js/momentjs/locale/zh-cn.min.js"></script> -->
	<script type="text/javascript" src="<?= LightYearV5('js/main.min.js') ?>"></script>
	<script type="text/javascript" src="assets/js/server.min.js?version<?= VERSION ?>"></script>
	<script>
		setTimeout(function () {
			$("#loading-animation").fadeOut(500);
		}, 15000);
	</script>
</body>

</html>
<?php system\admin\Server::autoUpdate() ?>