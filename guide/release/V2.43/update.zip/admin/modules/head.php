<meta name="referrer" content="no-referrer" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<meta name="keywords" content="<?= $site['keywords'] ?>">
<meta name="description" content="<?= $site['description'] ?>">
<meta name="author" content="易航">
<title><?= $title ?> - <?= $site['title'] ?></title>
<link rel="shortcut icon" type="image/x-icon" href="<?= $site['favicon'] ?>">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-touch-fullscreen" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<link rel="stylesheet" type="text/css" href="<?= LightYearV5('css/materialdesignicons.min.css') ?>">
<!-- bootstrap框架 -->
<link rel="stylesheet" type="text/css" href="<?= cdn('twitter-bootstrap/5.1.3/css/bootstrap.min.css') ?>">
<!-- animate动画插件 -->
<link rel="stylesheet" type="text/css" href="<?= cdn('animate.css/4.1.1/animate.min.css') ?>">
<!--表格插件css-->
<link rel="stylesheet" href="<?= cdn('bootstrap-table/1.20.0/bootstrap-table.min.css') ?>">
<!--引入下拉插件css-->
<link rel="stylesheet" type="text/css" href="<?= LightYearV5('js/bootstrap-select/bootstrap-select.min.css') ?>">
<!--对话框插件css-->
<link rel="stylesheet" type="text/css" href="<?= cdn('jquery-confirm/3.3.4/jquery-confirm.min.css') ?>">
<!--日期选择器css-->
<link rel="stylesheet" type="text/css" href="<?= cdn('bootstrap-datepicker/1.9.0/css/bootstrap-datepicker3.min.css') ?>">
<!--时间日期选择器css-->
<!-- <link rel="stylesheet" type="text/css" href="assets/js/bootstrap-datetimepicker/bootstrap-datetimepicker.min.css"> 4.17.47 -->
<link rel="stylesheet" type="text/css" href="<?= LightYearV5('css/style.min.css') ?>">
<link rel="stylesheet" type="text/css" href="assets/css/common.css?version=<?= VERSION ?>">
<?php include_once ROOT . 'admin/modules/config.php' ?>
<script src="//at.alicdn.com/t/c/font_3997710_4w7m9gv4fc3.js"></script>
<script type="text/javascript" src="<?= cdn('jquery/3.6.1/jquery.min.js') ?>"></script>
<script type="text/javascript" src="<?= cdn('popper.js/2.11.2/umd/popper.min.js') ?>"></script>
<script type="text/javascript" src="<?= cdn('twitter-bootstrap/5.1.3/js/bootstrap.min.js') ?>"></script>
<script type="text/javascript" src="<?= LightYearV5('js/lyear-loading.js') ?>"></script>
<script type="text/javascript" src="<?= LightYearV5('js/bootstrap-notify.min.js') ?>"></script>
<script type="text/javascript" src="<?= cdn('perfect-scrollbar/1.5.3/perfect-scrollbar.min.js') ?>"></script>
<script type="text/javascript" src="<?= cdn('jquery-cookie/1.4.1/jquery.cookie.min.js') ?>"></script>
<!--表格插件js-->
<script src="<?= LightYearV5('js/bootstrap-table/bootstrap-table.js') ?>"></script>
<script src="<?= cdn('bootstrap-table/1.20.0/locale/bootstrap-table-zh-CN.min.js') ?>"></script>
<!--引入下拉插件js-->
<script type="text/javascript" src="<?= LightYearV5('js/bootstrap-select/bootstrap-select.min.js') ?>"></script>
<script type="text/javascript" src="<?= LightYearV5('js/bootstrap-select/i18n/defaults-zh_CN.min.js') ?>"></script>
<!--对话框插件js-->
<script type="text/javascript" src="<?= cdn('jquery-confirm/3.3.4/jquery-confirm.min.js') ?>"></script>
<!--日期选择器js-->
<script type="text/javascript" src="<?= cdn('bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js') ?>"></script>
<script type="text/javascript" src="<?= cdn('bootstrap-datepicker/1.9.0/locales/bootstrap-datepicker.zh-CN.min.js') ?>"></script>
<script type="text/javascript" src="assets/js/PublicAjax.js?version=<?= VERSION ?>"></script>