<?php

use system\admin\Server;

include_once $_SERVER['DOCUMENT_ROOT'] . '/public/common.php';
system\admin\Admin::check();
?>
<!DOCTYPE html>
<html lang="zh">

<head>
	<?php include_once 'head.php' ?>
</head>

<body data-theme="default">
	<?php (function () use ($options) {if (APP_DEBUG) return;$loading_css = 'assets/css/loading.css?version=' . VERSION;$html = '<link rel="stylesheet" href="' . $loading_css . '"><div id="loading-animation"><div id="Loadanimation-center"><div id="Loadanimation-center-absolute"><div class="xccx_object" id="xccx_four"></div><div class="xccx_object" id="xccx_three"></div><div class="xccx_object" id="xccx_two"></div><div class="xccx_object" id="xccx_one"></div></div></div></div>';echo (system\admin\Server::auth() ? ($options['admin']['loading'] ? $html : null) : $html);if (!Server::auth()) echo base64_decode('PGRpdiBjbGFzcz0ic2hhZGUiPjxzcGFuIHN0eWxlPSJjb2xvcjogcmVkOyI+5qOA5rWL5Yiw5oKo55uu5YmN5L2/55So55qE57O757uf5a2Y5Zyo5q6L57y65oOF5Ya177yM5pWw5o2u5rOE6Zyy44CB5o2f5aSx44CB5ZKMQlVH5ryP5rSe562J5Lil6YeN6Zeu6aKY5Lya6auY5qaC546H5oyB57ut5a2Y5Zyo77yM5bm25LiU5p6B5piT6KKr5LiN5rOV6buR5a6i5YWl5L615pyN5Yqh5Zmo6YCg5oiQ5oKo55qE6LSi5Lqn5o2f5aSx77yM6K+35bC95b+rIDxhIGhyZWY9Imh0dHA6Ly9ndWlkZS5icmk2LmNuIiB0YXJnZXQ9Il9ibGFuayI+5YmN5b6A5a6Y572RPC9hPiDkuIvovb3mmJPoiKrnvZHlnYDlvJXlr7zns7vnu5/lrpjmlrnmraPniYjnqIvluo88L3NwYW4+PC9kaXY+');})();?>
	<div class="lyear-layout-web">
		<div class="lyear-layout-container">
			<!--左侧导航-->
			<?php include_once 'modules/aside.php' ?>
			<!--End 左侧导航-->

			<!--头部信息-->
			<header class="lyear-layout-header">

				<nav class="navbar">

					<div class="navbar-left">
						<div class="lyear-aside-toggler">
							<span class="lyear-toggler-bar"></span>
							<span class="lyear-toggler-bar"></span>
							<span class="lyear-toggler-bar"></span>
						</div>
					</div>

					<ul class="navbar-right d-flex align-items-center">
						<!--顶部消息部分-->
						<li class="dropdown dropdown-notice" id="server_msg" style="display: none;">
							<span data-bs-toggle="dropdown" class="position-relative icon-item">
								<i class="mdi mdi-bell-outline fs-5"></i>
								<span class="position-absolute translate-middle badge bg-danger">{$num}</span>
							</span>
							<div class="dropdown-menu dropdown-menu-end">
								<div class="lyear-notifications">
									<div class="lyear-notifications-title d-flex justify-content-between" data-stopPropagation="true">
										<span>你有 <span>0</span> 条未读消息</span>
										<a href="#">查看全部</a>
									</div>
									<div class="lyear-notifications-info lyear-scroll">
									</div>
								</div>
							</div>
						</li>
						<!--End 顶部消息部分-->
						<!--切换主题配色-->
						<li class="dropdown dropdown-skin">
							<span data-bs-toggle="dropdown" class="icon-item">
								<i class="mdi mdi-palette fs-5"></i>
							</span>
							<ul class="dropdown-menu dropdown-menu-end" data-stopPropagation="true">
								<li class="lyear-skin-title">
									<p>主题</p>
								</li>
								<li class="lyear-skin-li clearfix">
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="site_theme" id="site_theme_1" value="default" checked="checked">
										<label class="form-check-label" for="site_theme_1"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="site_theme" id="site_theme_2" value="translucent-green">
										<label class="form-check-label" for="site_theme_2"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="site_theme" id="site_theme_3" value="translucent-blue">
										<label class="form-check-label" for="site_theme_3"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="site_theme" id="site_theme_4" value="translucent-yellow">
										<label class="form-check-label" for="site_theme_4"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="site_theme" id="site_theme_5" value="translucent-red">
										<label class="form-check-label" for="site_theme_5"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="site_theme" id="site_theme_6" value="translucent-pink">
										<label class="form-check-label" for="site_theme_6"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="site_theme" id="site_theme_7" value="translucent-cyan">
										<label class="form-check-label" for="site_theme_7"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="site_theme" id="site_theme_8" value="dark">
										<label class="form-check-label" for="site_theme_8"></label>
									</div>
								</li>
								<li class="lyear-skin-title">
									<p>LOGO</p>
								</li>
								<li class="lyear-skin-li clearfix">
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="logo_bg" id="logo_bg_1" value="default" checked="checked">
										<label class="form-check-label" for="logo_bg_1"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="logo_bg" id="logo_bg_2" value="color_2">
										<label class="form-check-label" for="logo_bg_2"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="logo_bg" id="logo_bg_3" value="color_3">
										<label class="form-check-label" for="logo_bg_3"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="logo_bg" id="logo_bg_4" value="color_4">
										<label class="form-check-label" for="logo_bg_4"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="logo_bg" id="logo_bg_5" value="color_5">
										<label class="form-check-label" for="logo_bg_5"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="logo_bg" id="logo_bg_6" value="color_6">
										<label class="form-check-label" for="logo_bg_6"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="logo_bg" id="logo_bg_7" value="color_7">
										<label class="form-check-label" for="logo_bg_7"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="logo_bg" id="logo_bg_8" value="color_8">
										<label class="form-check-label" for="logo_bg_8"></label>
									</div>
								</li>
								<li class="lyear-skin-title">
									<p>头部</p>
								</li>
								<li class="lyear-skin-li clearfix">
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="header_bg" id="header_bg_1" value="default" checked="checked">
										<label class="form-check-label" for="header_bg_1"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="header_bg" id="header_bg_2" value="color_2">
										<label class="form-check-label" for="header_bg_2"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="header_bg" id="header_bg_3" value="color_3">
										<label class="form-check-label" for="header_bg_3"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="header_bg" id="header_bg_4" value="color_4">
										<label class="form-check-label" for="header_bg_4"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="header_bg" id="header_bg_5" value="color_5">
										<label class="form-check-label" for="header_bg_5"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="header_bg" id="header_bg_6" value="color_6">
										<label class="form-check-label" for="header_bg_6"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="header_bg" id="header_bg_7" value="color_7">
										<label class="form-check-label" for="header_bg_7"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="header_bg" id="header_bg_8" value="color_8">
										<label class="form-check-label" for="header_bg_8"></label>
									</div>
								</li>
								<li class="lyear-skin-title">
									<p>侧边栏</p>
								</li>
								<li class="lyear-skin-li clearfix">
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="sidebar_bg" id="sidebar_bg_1" value="default" checked="checked">
										<label class="form-check-label" for="sidebar_bg_1"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="sidebar_bg" id="sidebar_bg_2" value="color_2">
										<label class="form-check-label" for="sidebar_bg_2"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="sidebar_bg" id="sidebar_bg_3" value="color_3">
										<label class="form-check-label" for="sidebar_bg_3"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="sidebar_bg" id="sidebar_bg_4" value="color_4">
										<label class="form-check-label" for="sidebar_bg_4"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="sidebar_bg" id="sidebar_bg_5" value="color_5">
										<label class="form-check-label" for="sidebar_bg_5"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="sidebar_bg" id="sidebar_bg_6" value="color_6">
										<label class="form-check-label" for="sidebar_bg_6"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="sidebar_bg" id="sidebar_bg_7" value="color_7">
										<label class="form-check-label" for="sidebar_bg_7"></label>
									</div>
									<div class="form-check form-check-inline">
										<input class="form-check-input" type="radio" name="sidebar_bg" id="sidebar_bg_8" value="color_8">
										<label class="form-check-label" for="sidebar_bg_8"></label>
									</div>
								</li>
							</ul>
						</li>
						<!--End 切换主题配色-->
						<!--个人头像内容-->
						<li class="dropdown">
							<a href="javascript:void(0)" data-bs-toggle="dropdown" class="dropdown-toggle">
								<?php $admin_info = \system\admin\Admin::info() ?>
								<img class="avatar-md rounded-circle" src="http://q4.qlogo.cn/headimg_dl?dst_uin=<?= $admin_info['qq'] ?>&spec=640" alt="<?= $admin_info['name'] ?>" />
								<span style="margin-left: 10px;"><?= $admin_info['name'] ?></span>
							</a>
							<ul class="dropdown-menu dropdown-menu-end">
								<li>
									<a class="dropdown-item" href="/" target="_blank">
										<i class="mdi mdi-home"></i>
										<span>网站首页</span>
									</a>
								</li>
								<li>
									<a class="dropdown-item" href="admin.php?mod=update" href="javascript:void(0)">
										<i class="mdi mdi-account"></i>
										<span>个人信息</span>
									</a>
								</li>
								<li>
									<a class="dropdown-item" href="admin.php?mod=pwd" href="javascript:void(0)">
										<i class="mdi mdi-lock-outline"></i>
										<span>修改密码</span>
									</a>
								</li>
								<li>
									<a class="dropdown-item" href="javascript:void(0)" onclick="$.get('server.php?action=clearAll');$.notify({message: '清空缓存成功'},{type: 'success',allow_dismiss: true,newest_on_top: false,placement: {from: 'top',align: 'center'},delay: 10,animate: {enter: 'animate__animated animate__fadeInDown',exit: 'animate__animated animate__fadeOutUp'}});">
										<i class="mdi mdi-delete"></i>
										<span>清空缓存</span>
									</a>
								</li>
								<li class="dropdown-divider"></li>
								<li>
									<a class="dropdown-item" href="login.php?logout=1">
										<i class="mdi mdi-logout-variant"></i>
										<span>退出登录</span>
									</a>
								</li>
							</ul>
						</li>
						<!--End 个人头像内容-->
					</ul>

				</nav>

			</header>
			<!--End 头部信息-->

			<!--页面主要内容-->
			<main class="lyear-layout-content">
				<div class="container-fluid">