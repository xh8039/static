<?php

use system\library\Statics;
use system\theme\Manager;

?>
<aside class="lyear-layout-sidebar">
	<!-- logo -->
	<div id="logo" class="sidebar-header">
		<a href="http://guide.bri6.cn" target="_blank"><img referrer="no-referrer" src="<?= LightYearV5('images/logo-sidebar.png') ?>" title="易航后台管理系统" alt="易航后台管理系统" /></a>
	</div>
	<div class="lyear-layout-sidebar-info lyear-scroll">
		<nav class="sidebar-main">
			<ul class="nav-drawer">
				<li class="nav-item">
					<a href="index.php">
						<svg class="icon" aria-hidden="true">
							<use xlink:href="#icon--"></use>
						</svg>
						<span>后台首页</span>
					</a>
				</li>
				<li class="nav-item nav-item-has-subnav">
					<a href="javascript:void(0)">
						<svg class="icon" aria-hidden="true">
							<use xlink:href="#icon-peizhi"></use>
						</svg>
						<span>系统管理</span>
					</a>
					<ul class="nav nav-subnav">
						<li class="nav-item"><a href="set.php?mod=options">系统配置</a></li>
						<li class="nav-item"><a href="set.php?mod=tool">自助工具</a></li>
					</ul>
				</li>
				<li class="nav-item nav-item-has-subnav">
					<a href="javascript:void(0)">
						<svg class="icon" aria-hidden="true">
							<use xlink:href="#icon-biaoqianA01_fenlei-52"></use>
						</svg>
						<span>分类管理</span>
					</a>
					<ul class="nav nav-subnav">
						<li class="nav-item"><a href="sort.php">分类列表</a></li>
						<li class="nav-item"><a href="sort.php?mod=create">新增分类</a></li>
					</ul>
				</li>
				<li class="nav-item nav-item-has-subnav">
					<a href="javascript:void(0)">
						<svg class="icon" aria-hidden="true">
							<use xlink:href="#icon-daohang"></use>
						</svg>
						<span>链接管理</span>
					</a>
					<ul class="nav nav-subnav">
						<li class="nav-item"><a href="link.php">链接列表</a></li>
						<li class="nav-item"><a href="link.php?mod=create">新增链接</a></li>
					</ul>
				</li>
				<li class="nav-item nav-item-has-subnav">
					<a href="javascript:void(0)">
						<svg class="icon" aria-hidden="true">
							<use xlink:href="#icon-changyonglianjie"></use>
						</svg>
						<span>友链管理</span>
					</a>
					<ul class="nav nav-subnav">
						<li class="nav-item"><a href="friends.php">友链列表</a></li>
						<li class="nav-item"><a href="friends.php?mod=create">新增友链</a></li>
					</ul>
				</li>
				<li class="nav-item nav-item-has-subnav">
					<a href="javascript:void(0)">
						<svg class="icon" aria-hidden="true">
							<use xlink:href="#icon-43_zhuti"></use>
						</svg>
						<span>主题管理</span>
					</a>
					<ul class="nav nav-subnav">
						<li class="nav-item"><a href="themes.php">选择主题</a></li>
						<?= Manager::getInfo(THEME, false)['options'] ? '<li class="nav-item"><a href="themes.php?mod=options">主题设置</a></li>' : null ?>
					</ul>
				</li>
				<li class="nav-item">
					<a href="plugins.php">
						<svg class="icon" aria-hidden="true">
							<use xlink:href="#icon-qitachajianqu"></use>
						</svg>
						<span>插件管理</span>
					</a>
				</li>
				<li class="nav-item">
					<a href="update.php">
						<svg class="icon" aria-hidden="true">
							<use xlink:href="#icon-xitonggengxin"></use>
						</svg>
						<span>检查更新</span>
					</a>
				</li>
			</ul>
			<script>
				(function() {
					var pathname = window.location.pathname;
					var search = window.location.search;
					var path = search ? pathname + search : pathname;
					$('.nav-drawer').find('a').each(function() {
						temp_path = '/admin/' + $(this).attr('href');
						if (path == temp_path) {
							$('.nav-drawer').find('.nav-item').removeClass('active').removeClass('open');
							$('.nav-drawer').find('.nav-subnav:visible').slideUp(500);
							$(this).parent('li').addClass('active');
							$(this).parents('.nav-subnav').slideDown(500);
							$(this).parents('.nav-item').addClass('open');
							$(this).parents('.nav-item').last().addClass('active');
						}
					});
				}())
			</script>
		</nav>
		<div class="sidebar-footer">
			<div class="copyright">
				<span role="contentinfo"><?= base64_decode('55SxIDxhIHRhcmdldD0iX2JsYW5rIiBocmVmPSJodHRwOi8vZ3VpZGUuYnJpNi5jbiI+5piT6Iiq572R5Z2A5byV5a+857O757ufPC9hPiDlvLrlipvpqbHliqg=') ?></span>
				<div class="resource">
					<?= base64_decode('PGEgaHJlZj0iaHR0cHM6Ly95ZXB5ZHZtcHhvLmsudG9wdGhpbmsuY29tL0BndWlkZS8iIHRhcmdldD0iX2JsYW5rIj7luK7liqnmlofmoaM8L2E+IOKAoiA8YSBocmVmPSJodHRwOi8vYnJpNi5jbi9hcmNoaXZlcy8zMzUuaHRtbCIgdGFyZ2V0PSJfYmxhbmsiPuaUr+aMgeiuuuWdmzwvYT4KPGJyIC8+CjxhIGhyZWY9Imh0dHBzOi8vZ2l0ZWUuY29tL3loX0lUL2d1aWRlL2lzc3VlcyIgdGFyZ2V0PSJfYmxhbmsiPuaKpeWRiumUmeivrzwvYT4g4oCiIDxhIGhyZWY9Imh0dHBzOi8vZ2l0ZWUuY29tL3loX0lUL2d1aWRlIiB0YXJnZXQ9Il9ibGFuayI+6LWE5rqQ5LiL6L29PC9hPg==') ?>
				</div>
			</div>
		</div>
	</div>
</aside>