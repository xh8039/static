<?php

/*
 * @Author        : 易航
 * @Url           : blog.bri6.cn
 * @Date          : 2020-09-29 13:18:36
 * @LastEditTime  : 2022-10-26 21:46:06
 * @Email         : 2136118039@qq.com
 * @Project       : 易航网址引导系统
 * @Description   : 一款极其优雅的易航网址引导系统
 * @Read me       : 感谢您使用易航网址引导系统，系统源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版系统会存在各种未知风险。支持正版，从我做起！
*/

use system\library\System;

if (isset($_GET['tool'])) {
	require  $_SERVER['DOCUMENT_ROOT'] . '/public/common.php';
	if ($_GET['tool'] == 'restore') {
		$RemoteFile = YH_SERVER . 'backup/version/' . VERSION;
		$ZipFile = "Archive.zip";
		if (copy($RemoteFile, $ZipFile)) {
			if (zipExtract($ZipFile, CONTENT_ROOT . 'JsonDb/')) {
				if (function_exists("opcache_reset")) opcache_reset();
				unlink($ZipFile);
				System::alert('恢复出厂设置成功！', '?mod=tool');
			} else {
				if (file_exists($ZipFile)) unlink($ZipFile);
				System::alert('恢复出厂设置失败，无法解压数据文件！', '?mod=tool');
			}
		} else {
			System::alert('恢复出厂设置失败，无法下载数据文件！', '?mod=tool');
		}
	}
	if ($_GET['tool'] == 'clear') {
		\system\admin\Server::clearAll();
		System::alert('服务端缓存已成功清除！', '?mod=tool');
	}
}

$title = '自助工具';
include 'modules/header.php';
\system\admin\View::card($title, function () {
?>
	<a href="?mod=tool&tool=restore" class="btn btn-danger"><i class="mdi mdi-wrench"></i> 恢复出厂设置</a>
	<a href="?mod=tool&tool=clear" class="btn btn-warning"><i class="mdi mdi-delete-empty"></i> 清空服务端缓存</a>
<?php
});
include 'modules/footer.php';
