<?php

use JsonDb\JsonDb\Db;
use system\admin\Form;

$title = '更新友情链接';
include 'modules/iframe.php';
$table = 'friends';
$friend = Db::name($table)->where('id', $_GET['id'])->find();
$form = [
	Form::input('站点标题', 'title', $friend['title'], 'text', null, ['required' => true]),
	Form::input('站点链接', 'url', $friend['url'], 'url', null, ['required' => true]),
	Form::textarea('站点简介', 'description', $friend['description']),
	Form::input('站点关键词', 'keywords', $friend['keywords'], 'text', '关键词以 | 分割'),
	Form::input('站点Favicon', 'favicon', $friend['favicon'], 'url', '站点Favicon图标链接'),
	Form::input('rel属性', 'rel', $friend['rel'], 'text', '例如：nofollow（注释：不传递搜索引擎权重）'),
	Form::select('友链状态', 'status', ['1' => '正常', '0' => '禁用'], $friend['status'])
];
$form = implode(PHP_EOL, $form);
echo Form::form(
	'updateTable',
	['table' => $table, 'id' => $friend['id']],
	$form
);
// View::form($title, 'updateTable', ['table' => $table, 'id' => $friend['id']], $form, $title);
include 'modules/footer.php';