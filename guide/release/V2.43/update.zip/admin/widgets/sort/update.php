<?php

use JsonDb\JsonDb\Db;
use system\admin\Form;
use system\admin\View;
use system\theme\Manager;

$title = '更新导航分类';
include 'modules/iframe.php';
$table = 'sort';
$sort = Db::name($table)->where('id', $_GET['id'])->find();
$title = '更新导航分类 ' . $sort['title'];
$sort_config = false;
$sort_config_file = Manager::getFile('theme/functions');
if ($sort_config_file) {
	include_once $sort_config_file;
	if (function_exists('sortConfig')) {
		$sort_config = true;
	}
}
// View::card($title, function () use ($table, $sort, $sort_config) {
?>
	<ul class="nav nav-tabs">
		<li class="nav-item">
			<button class="nav-link active" data-bs-toggle="tab" data-bs-target="#pane-basic" type="button">基本信息</button>
		</li>
		<?php
		if ($sort_config) {
			$theme_info = Manager::getInfo();
		?>
			<li class="nav-item">
				<button class="nav-link" data-bs-toggle="tab" data-bs-target="#pane-theme" type="button"><?= $theme_info['title'] ?>主题设置</button>
			</li>
		<?php
		}
		?>
	</ul>
	<form action="api.php?action=updateTable&table=<?= $table ?>&id=<?= $sort['id'] ?>" method="post" class="updateTable">
		<div class="tab-content">
			<div class="tab-pane fade show active" id="pane-basic" aria-labelledby="basic-site">
				<?php
				echo Form::input('分类标题', 'title', $sort['title']);
				echo Form::input('分类排序', 'order', $sort['order'], 'number', '排序越高优先级越高', ['required' => true]);
				echo Form::select('分类状态', 'status', ['1' => '正常', '0' => '禁用'], $sort['status'])
				?>
			</div>
			<?php
			if ($sort_config) {
			?>
				<div class="tab-pane fade" id="pane-theme" aria-labelledby="basic-site">
					<?php sortConfig(new \system\theme\Fields([]), new \system\theme\Method) ?>
				</div>
			<?php
			}
			?>
		</div>
		<div class="d-grid">
			<button type="submit" class="btn btn-primary">更新分类</button>
		</div>
	</form>
<?php
// });
include 'modules/footer.php';
?>
<script type="text/javascript">
	new PublicAjax('.updateTable', '更新分类')
</script>